$py = "C:\Users\ARQAM\AppData\Local\Programs\Python\Python312\python.exe"
$log = "d:\PBA\backend\pip_check.txt"
$r = & $py -m pip list --format=columns 2>&1
$r | Out-File $log -Encoding UTF8
"DONE" | Out-File $log -Append
