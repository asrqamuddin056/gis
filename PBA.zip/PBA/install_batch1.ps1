$py = "C:\Users\ARQAM\AppData\Local\Programs\Python\Python312\python.exe"
$log = "d:\PBA\backend\pip_batch1.log"
"=== Batch 1: Web framework ===" | Out-File $log
$pkgs = @("fastapi","uvicorn","python-multipart","pydantic","pydantic-settings","python-dotenv","SQLAlchemy","aiosqlite")
foreach($p in $pkgs) {
    "Installing $p ..." | Out-File $log -Append
    & $py -m pip install $p --timeout 120 --retries 10 2>&1 | Out-File $log -Append
}
"BATCH1_DONE" | Out-File $log -Append
