import { Outlet, NavLink, useLocation } from 'react-router-dom'
import {
  LayoutDashboard, Map, Database, Satellite, Mountain,
  CloudRain, Trees, Waves, AlertTriangle, Brain, GitCompare,
  MapPin, FileText, Settings, Activity,
} from 'lucide-react'

const navItems = [
  { to: '/', label: 'Overview', icon: LayoutDashboard },
  { to: '/study-areas', label: 'Study Areas', icon: Map },
  { to: '/datasets', label: 'Datasets', icon: Database },
  { to: '/satellite', label: 'Satellite Analysis', icon: Satellite },
  { to: '/terrain', label: 'Terrain Analysis', icon: Mountain },
  { to: '/rainfall', label: 'Rainfall Analysis', icon: CloudRain },
  { to: '/lulc', label: 'LULC Classification', icon: Trees },
  { to: '/drainage', label: 'Drainage Analysis', icon: Waves },
  { to: '/flood-risk', label: 'Flood Risk Assessment', icon: AlertTriangle },
  { to: '/machine-learning', label: 'Machine Learning', icon: Brain },
  { to: '/scenarios', label: 'Scenario Analysis', icon: GitCompare },
  { to: '/gis-map', label: 'GIS Map Explorer', icon: MapPin },
  { to: '/reports', label: 'Reports', icon: FileText },
  { to: '/settings', label: 'Settings', icon: Settings },
]

export default function MainLayout() {
  const location = useLocation()

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-navy-900 text-white flex-shrink-0 flex flex-col">
        <div className="px-5 py-5 border-b border-navy-700">
          <div className="flex items-center gap-2">
            <Activity className="w-6 h-6 text-cyan-400" />
            <div>
              <h1 className="text-sm font-semibold">Flood Risk System</h1>
              <p className="text-xs text-navy-300">Intelligent Assessment</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.to
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={`flex items-center gap-3 px-5 py-2.5 text-sm transition-colors ${
                  isActive
                    ? 'bg-navy-700 text-cyan-400 border-r-2 border-cyan-400'
                    : 'text-navy-200 hover:bg-navy-800 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            )
          })}
        </nav>

        <div className="px-5 py-3 border-t border-navy-700">
          <p className="text-xs text-navy-400">v1.0.0 — Academic Project</p>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto bg-gray-50">
        <Outlet />
      </main>
    </div>
  )
}
