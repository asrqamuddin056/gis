import { useState, useEffect } from 'react'
import { MapPin, Plus, Search, Trash2, Download } from 'lucide-react'
import { studyAreaApi } from '../services/api'
import type { StudyArea, CitySearchResult } from '../types'

export default function StudyAreas() {
  const [areas, setAreas] = useState<StudyArea[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<CitySearchResult[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [newArea, setNewArea] = useState({ name: '', description: '', location_label: '' })

  useEffect(() => {
    loadAreas()
  }, [])

  const loadAreas = async () => {
    setLoading(true)
    try {
      const res = await studyAreaApi.list()
      setAreas(res.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = async () => {
    if (!searchQuery.trim()) return
    try {
      const res = await studyAreaApi.searchCity(searchQuery)
      setSearchResults(res.data)
    } catch (err) {
      console.error(err)
    }
  }

  const handleCreateFromCity = async (city: CitySearchResult) => {
    try {
      await studyAreaApi.create({
        name: city.name,
        description: `Study area for ${city.name}, ${city.country}`,
        location_label: `${city.name}, ${city.country}`,
        bbox_min_lon: city.bbox?.[0] ?? 0,
        bbox_min_lat: city.bbox?.[1] ?? 0,
        bbox_max_lon: city.bbox?.[2] ?? 0,
        bbox_max_lat: city.bbox?.[3] ?? 0,
      })
      setShowCreate(false)
      setSearchResults([])
      loadAreas()
    } catch (err) {
      console.error(err)
    }
  }

  const handleCreateHyderabad = async () => {
    try {
      await studyAreaApi.createHyderabadSample()
      loadAreas()
    } catch (err) {
      console.error(err)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this study area and its datasets?')) return
    try {
      await studyAreaApi.delete(id)
      loadAreas()
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Study Areas</h1>
          <p className="text-sm text-gray-500 mt-1">Define and manage geographical study areas</p>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-secondary" onClick={handleCreateHyderabad}>
            <Plus className="w-4 h-4 inline mr-1" /> Hyderabad Sample
          </button>
          <button className="btn btn-primary" onClick={() => setShowCreate(!showCreate)}>
            <Plus className="w-4 h-4 inline mr-1" /> New Study Area
          </button>
        </div>
      </div>

      {/* Search city */}
      {showCreate && (
        <div className="card mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Search for a City</h3>
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              className="input"
              placeholder="Search city name (e.g. Hyderabad, Mumbai, Chennai)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
            <button className="btn btn-primary" onClick={handleSearch}>
              <Search className="w-4 h-4" />
            </button>
          </div>
          {searchResults.length > 0 && (
            <div className="space-y-2">
              {searchResults.map((city) => (
                <div key={city.name} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-blue-500" />
                    <div>
                      <p className="text-sm font-medium">{city.name}, {city.country}</p>
                      <p className="text-xs text-gray-500">{city.lat.toFixed(4)}, {city.lon.toFixed(4)}</p>
                    </div>
                  </div>
                  <button className="btn btn-primary text-xs" onClick={() => handleCreateFromCity(city)}>
                    Create
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Study area list */}
      {loading ? (
        <div className="text-center py-12 text-gray-400">Loading...</div>
      ) : areas.length === 0 ? (
        <div className="card text-center py-12">
          <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No study areas yet. Create one or use the Hyderabad sample.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {areas.map((area) => (
            <div key={area.id} className="card">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-gray-900">{area.name}</h3>
                  <p className="text-xs text-gray-500">{area.location_label || 'No location label'}</p>
                </div>
                <button onClick={() => handleDelete(area.id)} className="text-red-400 hover:text-red-600">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-gray-600 mb-3">{area.description || 'No description'}</p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-gray-400">Area:</span>{' '}
                  <span className="font-medium">{area.area_km2.toFixed(2)} km²</span>
                </div>
                <div>
                  <span className="text-gray-400">CRS:</span>{' '}
                  <span className="font-medium">EPSG:{area.analysis_crs}</span>
                </div>
                <div>
                  <span className="text-gray-400">BBox:</span>{' '}
                  <span className="font-medium text-[10px]">
                    {area.bbox_min_lon.toFixed(2)},{area.bbox_min_lat.toFixed(2)} - {area.bbox_max_lon.toFixed(2)},{area.bbox_max_lat.toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400">Created:</span>{' '}
                  <span className="font-medium">{new Date(area.created_at).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
