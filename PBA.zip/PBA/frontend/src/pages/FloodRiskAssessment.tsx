import { useState, useEffect } from 'react'
import { Play, AlertTriangle, Download, Settings2 } from 'lucide-react'
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { studyAreaApi, overlayApi, reportApi, datasetApi } from '../services/api'
import type { StudyArea, Dataset, RiskAssessment } from '../types'

const RISK_COLORS = {
  Low: '#22c55e',
  Medium: '#eab308',
  High: '#f97316',
  'Very High': '#ef4444',
  'No Data': '#94a3b8',
}

export default function FloodRiskAssessment() {
  const [studyAreas, setStudyAreas] = useState<StudyArea[]>([])
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [assessments, setAssessments] = useState<RiskAssessment[]>([])
  const [selectedArea, setSelectedArea] = useState('')
  const [running, setRunning] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [weights, setWeights] = useState<Record<string, number>>({
    rainfall: 0.25, elevation: 0.20, drainage_proximity: 0.20,
    slope: 0.15, lulc: 0.15, built_up: 0.05,
  })
  const [assessmentName, setAssessmentName] = useState('Flood Risk Assessment')

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const saRes = await studyAreaApi.list()
      setStudyAreas(saRes.data)
      const dsRes = await datasetApi.list()
      setDatasets(dsRes.data)
      const aRes = await overlayApi.listAssessments()
      setAssessments(aRes.data)
    } catch (err) {
      console.error(err)
    }
  }

  const handleRun = async () => {
    if (!selectedArea) return
    setRunning(true)
    try {
      const res = await overlayApi.run({
        study_area_id: selectedArea,
        name: assessmentName,
        weights,
        thresholds: { low: 2.0, medium: 3.0, high: 4.0, very_high: 5.0 },
      })
      setResult(res.data.result)
      loadData()
    } catch (err: any) {
      console.error(err)
      alert(err.response?.data?.detail || 'Assessment failed')
    } finally {
      setRunning(false)
    }
  }

  const handleDownloadPdf = async (assessmentId: string) => {
    try {
      const res = await reportApi.generatePdf(assessmentId, false)
      const url = window.URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `flood_risk_report_${assessmentId}.pdf`
      a.click()
      window.URL.revokeObjectURL(url)
    } catch (err) {
      console.error(err)
    }
  }

  const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0)
  const availableDatasets = datasets.filter(d => d.study_area_id === selectedArea)

  const riskData = result?.risk_distribution
    ? Object.entries(result.risk_distribution)
        .filter(([k]) => k !== 'No Data')
        .map(([name, value]) => ({ name, value: value as number }))
    : []

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Flood Risk Assessment</h1>
        <p className="text-sm text-gray-500 mt-1">Weighted Overlay Analysis — FRI = Σ(Wi × Ri)</p>
      </div>

      {/* Configuration */}
      <div className="card mb-6">
        <div className="flex gap-3 items-end mb-4">
          <div className="flex-1">
            <label className="text-xs text-gray-500">Study Area</label>
            <select className="input" value={selectedArea} onChange={(e) => setSelectedArea(e.target.value)}>
              <option value="">Select study area...</option>
              {studyAreas.map((a) => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <label className="text-xs text-gray-500">Assessment Name</label>
            <input className="input" value={assessmentName} onChange={(e) => setAssessmentName(e.target.value)} />
          </div>
          <button className="btn btn-primary" onClick={handleRun} disabled={!selectedArea || running}>
            {running ? 'Running...' : <><Play className="w-4 h-4 inline mr-1" /> Run Analysis</>}
          </button>
        </div>

        {/* Weight configuration */}
        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-gray-700">Factor Weights</h3>
            <span className={`text-xs ${Math.abs(totalWeight - 1.0) < 0.01 ? 'text-green-600' : 'text-red-600'}`}>
              Total: {(totalWeight * 100).toFixed(0)}%
            </span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {Object.entries(weights).map(([factor, weight]) => (
              <div key={factor}>
                <label className="text-xs text-gray-500 capitalize">{factor.replace(/_/g, ' ')}</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    className="input"
                    value={weight}
                    min={0}
                    max={1}
                    step={0.05}
                    onChange={(e) => setWeights({ ...weights, [factor]: parseFloat(e.target.value) || 0 })}
                  />
                  <span className="text-xs text-gray-400">{(weight * 100).toFixed(0)}%</span>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-2">
            Note: Weights are illustrative initial values, not scientifically established universal constants. Adjust based on local conditions.
          </p>
        </div>

        {/* Available layers info */}
        {selectedArea && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs text-gray-500 mb-2">Available datasets for this study area: {availableDatasets.length}</p>
            <div className="flex flex-wrap gap-2">
              {availableDatasets.map((d) => (
                <span key={d.id} className={`badge ${d.validation_status === 'valid' ? 'badge-green' : 'badge-red'}`}>
                  {d.name} ({d.data_type})
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="stat-card">
              <p className="text-xs text-gray-500">High Risk %</p>
              <p className="text-2xl font-bold text-orange-600">{result.high_risk_percentage}%</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">Layers Used</p>
              <p className="text-2xl font-bold text-navy-700">{result.layers_used?.length}</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">High Risk Zones</p>
              <p className="text-2xl font-bold text-orange-600">{result.risk_distribution?.High || 0}</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">Very High Risk</p>
              <p className="text-2xl font-bold text-red-600">{result.risk_distribution?.['Very High'] || 0}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {riskData.length > 0 && (
              <div className="card">
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Risk Distribution</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie data={riskData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                      {riskData.map((entry, i) => (
                        <Cell key={i} fill={RISK_COLORS[entry.name as keyof typeof RISK_COLORS] || '#94a3b8'} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            {result.area_by_category && Object.values(result.area_by_category).some((v: any) => v > 0) && (
              <div className="card">
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Area by Risk Category (km²)</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={Object.entries(result.area_by_category).filter(([k]) => k !== 'No Data').map(([name, val]) => ({ name, value: val as number }))}>
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip />
                    <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* Layers used */}
          <div className="card">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Analysis Details</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><span className="text-gray-500">Method:</span> Weighted Overlay</div>
              <div><span className="text-gray-500">FRI Range:</span> {result.fri_stats?.min?.toFixed(2)} – {result.fri_stats?.max?.toFixed(2)}</div>
              <div><span className="text-gray-500">Mean FRI:</span> {result.fri_stats?.mean?.toFixed(2)}</div>
              <div><span className="text-gray-500">Layers Used:</span> {result.layers_used?.join(', ')}</div>
            </div>
          </div>
        </div>
      )}

      {/* Assessment history */}
      {assessments.length > 0 && (
        <div className="card mt-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Assessment History</h3>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-xs text-gray-500 uppercase">Name</th>
                <th className="text-left py-2 text-xs text-gray-500 uppercase">Status</th>
                <th className="text-left py-2 text-xs text-gray-500 uppercase">Date</th>
                <th className="text-right py-2 text-xs text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {assessments.map((a) => (
                <tr key={a.id} className="border-b border-gray-100">
                  <td className="py-2">{a.name}</td>
                  <td className="py-2"><span className={`badge ${a.status === 'completed' ? 'badge-green' : 'badge-yellow'}`}>{a.status}</span></td>
                  <td className="py-2 text-gray-500">{new Date(a.created_at).toLocaleString()}</td>
                  <td className="py-2 text-right">
                    <button onClick={() => handleDownloadPdf(a.id)} className="text-blue-500 hover:text-blue-700">
                      <Download className="w-4 h-4 inline" /> PDF
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
