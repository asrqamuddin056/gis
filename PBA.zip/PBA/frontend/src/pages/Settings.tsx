import { useEffect, useState } from 'react'
import { Settings as SettingsIcon, Server, Database, Cloud } from 'lucide-react'
import { dashboardApi, satelliteApi } from '../services/api'

export default function Settings() {
  const [health, setHealth] = useState<any>(null)
  const [satInfo, setSatInfo] = useState<any>(null)

  useEffect(() => {
    dashboardApi.health().then(res => setHealth(res.data)).catch(console.error)
    satelliteApi.info().then(res => setSatInfo(res.data)).catch(console.error)
  }, [])

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-sm text-gray-500 mt-1">System configuration and status</p>
      </div>

      {/* System status */}
      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Server className="w-4 h-4" /> System Status
        </h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">Backend API:</span>
            <span className="badge badge-green">{health?.status || 'Checking...'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Service:</span>
            <span className="text-gray-700">{health?.service || '—'}</span>
          </div>
        </div>
      </div>

      {/* Database */}
      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Database className="w-4 h-4" /> Database Configuration
        </h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">Engine:</span>
            <span className="text-gray-700">SQLite (local development)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Production:</span>
            <span className="text-gray-700">PostgreSQL + PostGIS (documented)</span>
          </div>
          <p className="text-xs text-gray-400 mt-2">
            The system uses SQLite for local development. For production spatial database
            operations (geometry storage, spatial indexing), configure PostgreSQL with the
            PostGIS extension.
          </p>
        </div>
      </div>

      {/* Satellite */}
      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Cloud className="w-4 h-4" /> Satellite Imagery Source
        </h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">Source:</span>
            <span className="text-gray-700">{satInfo?.source || '—'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Status:</span>
            <span className={`badge ${satInfo?.status === 'configured' ? 'badge-green' : 'badge-blue'}`}>{satInfo?.status || '—'}</span>
          </div>
          {satInfo?.note && <p className="text-xs text-gray-400 mt-2">{satInfo.note}</p>}
        </div>
      </div>

      {/* About */}
      <div className="card">
        <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <SettingsIcon className="w-4 h-4" /> About
        </h3>
        <div className="text-sm text-gray-600 space-y-2">
          <p><strong>Intelligent Urban Flood Risk Assessment and Prediction System</strong></p>
          <p>Version 1.0.0 — Academic Project</p>
          <p className="text-xs text-gray-400 mt-3">
            This system provides GIS-based flood susceptibility assessment using Weighted Overlay Analysis,
            integrating elevation, slope, rainfall, LULC, drainage proximity, and built-up density factors.
            The ML module supports Random Forest, XGBoost, and Logistic Regression for data-driven susceptibility
            modelling when labelled historical flood data is available.
          </p>
        </div>
      </div>
    </div>
  )
}
