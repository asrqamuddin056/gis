import { useState, useEffect } from 'react'
import { FileText, Download, FileSpreadsheet, FileJson } from 'lucide-react'
import { overlayApi, reportApi } from '../services/api'
import type { RiskAssessment } from '../types'

export default function Reports() {
  const [assessments, setAssessments] = useState<RiskAssessment[]>([])
  const [selectedId, setSelectedId] = useState('')
  const [downloading, setDownloading] = useState(false)

  useEffect(() => { loadAssessments() }, [])

  const loadAssessments = async () => {
    try {
      const res = await overlayApi.listAssessments()
      setAssessments(res.data)
    } catch (err) { console.error(err) }
  }

  const handleDownloadPdf = async () => {
    if (!selectedId) return
    setDownloading(true)
    try {
      const res = await reportApi.generatePdf(selectedId, false)
      downloadBlob(res.data, `flood_risk_report_${selectedId}.pdf`)
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Report generation failed')
    } finally { setDownloading(false) }
  }

  const handleDownloadCsv = async () => {
    if (!selectedId) return
    try {
      const res = await reportApi.exportCsv(selectedId)
      downloadBlob(res.data, `flood_risk_export_${selectedId}.csv`)
    } catch (err) { console.error(err) }
  }

  const handleDownloadJson = async () => {
    if (!selectedId) return
    try {
      const res = await reportApi.exportJson(selectedId)
      downloadBlob(res.data, `analysis_summary_${selectedId}.json`)
    } catch (err) { console.error(err) }
  }

  const downloadBlob = (data: any, filename: string) => {
    const url = window.URL.createObjectURL(new Blob([data]))
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Reports & Export</h1>
        <p className="text-sm text-gray-500 mt-1">Generate professional flood risk assessment reports</p>
      </div>

      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Select Assessment</h3>
        <select className="input mb-4" value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
          <option value="">Select an assessment...</option>
          {assessments.filter(a => a.status === 'completed').map(a => (
            <option key={a.id} value={a.id}>{a.name} ({new Date(a.created_at).toLocaleDateString()})</option>
          ))}
        </select>

        {selectedId && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="card hover:bg-blue-50 transition-colors text-left" onClick={handleDownloadPdf} disabled={downloading}>
              <FileText className="w-8 h-8 text-red-500 mb-2" />
              <h4 className="text-sm font-semibold">PDF Report</h4>
              <p className="text-xs text-gray-500 mt-1">Professional formatted report with all analysis results, methodology, and recommendations.</p>
              {downloading && <p className="text-xs text-blue-500 mt-2">Generating...</p>}
            </button>

            <button className="card hover:bg-green-50 transition-colors text-left" onClick={handleDownloadCsv}>
              <FileSpreadsheet className="w-8 h-8 text-green-500 mb-2" />
              <h4 className="text-sm font-semibold">CSV Export</h4>
              <p className="text-xs text-gray-500 mt-1">Tabular export of statistics, area calculations, and risk distribution data.</p>
            </button>

            <button className="card hover:bg-orange-50 transition-colors text-left" onClick={handleDownloadJson}>
              <FileJson className="w-8 h-8 text-orange-500 mb-2" />
              <h4 className="text-sm font-semibold">JSON Summary</h4>
              <p className="text-xs text-gray-500 mt-1">Complete analysis summary in machine-readable JSON format.</p>
            </button>
          </div>
        )}
      </div>

      {/* Report contents preview */}
      {selectedId && (() => {
        const assessment = assessments.find(a => a.id === selectedId)
        return assessment ? (
          <div className="card">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Report Contents Preview</h3>
            <ol className="text-sm space-y-1 list-decimal list-inside text-gray-600">
              <li>Project title and study area description</li>
              <li>Dataset sources and data preparation methodology</li>
              <li>Spatial analysis methodology (Weighted Overlay)</li>
              <li>Weight assignment and FRI formula</li>
              <li>Risk classification thresholds</li>
              <li>Statistical results: <span className="text-gray-400">{assessment.statistics?.risk_distribution && 'risk distribution, area calculations'}</span></li>
              <li>ML evaluation (if available)</li>
              <li>Limitations and recommendations</li>
              <li>Conclusion</li>
            </ol>
            <div className="mt-4 pt-4 border-t border-gray-100 text-xs text-gray-500">
              <p>High Risk Percentage: {assessment.statistics?.high_risk_percentage || 0}%</p>
              <p>Method: {assessment.method}</p>
              <p>Created: {new Date(assessment.created_at).toLocaleString()}</p>
            </div>
          </div>
        ) : null
      })()}
    </div>
  )
}
