import { useState, useEffect } from 'react'
import { Upload, Database, CheckCircle, XCircle, Trash2, FileText, RefreshCw } from 'lucide-react'
import { datasetApi, studyAreaApi } from '../services/api'
import type { Dataset, StudyArea } from '../types'

const TYPE_LABELS: Record<string, string> = {
  raster: 'Raster',
  vector: 'Vector',
  csv: 'CSV',
  rainfall: 'Rainfall',
  flood_record: 'Flood Record',
  satellite: 'Satellite',
}

export default function Datasets() {
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [studyAreas, setStudyAreas] = useState<StudyArea[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedArea, setSelectedArea] = useState<string>('')
  const [uploading, setUploading] = useState(false)

  // Upload form
  const [uploadName, setUploadName] = useState('')
  const [uploadType, setUploadType] = useState('raster')
  const [uploadFile, setUploadFile] = useState<File | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      const [dsRes, saRes] = await Promise.all([
        datasetApi.list(),
        studyAreaApi.list(),
      ])
      setDatasets(dsRes.data)
      setStudyAreas(saRes.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleUpload = async () => {
    if (!uploadFile || !uploadName) return
    setUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', uploadFile)
      formData.append('name', uploadName)
      formData.append('description', '')
      formData.append('data_type', uploadType)
      formData.append('source', 'User Upload')
      if (selectedArea) formData.append('study_area_id', selectedArea)

      await datasetApi.upload(formData)
      setUploadFile(null)
      setUploadName('')
      loadData()
    } catch (err) {
      console.error('Upload failed:', err)
      alert('Upload failed. Check console for details.')
    } finally {
      setUploading(false)
    }
  }

  const handleGenerateSample = async () => {
    try {
      await datasetApi.generateSampleData(selectedArea || undefined)
      loadData()
    } catch (err) {
      console.error(err)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this dataset?')) return
    try {
      await datasetApi.delete(id)
      loadData()
    } catch (err) {
      console.error(err)
    }
  }

  const handleValidate = async (id: string) => {
    try {
      await datasetApi.validate(id)
      loadData()
    } catch (err) {
      console.error(err)
    }
  }

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / 1048576).toFixed(1)} MB`
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dataset Management</h1>
          <p className="text-sm text-gray-500 mt-1">Upload, validate, and manage geospatial datasets</p>
        </div>
        <button className="btn btn-secondary" onClick={handleGenerateSample}>
          <Database className="w-4 h-4 inline mr-1" /> Generate Sample Data
        </button>
      </div>

      {/* Upload form */}
      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Upload Dataset</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="text-xs text-gray-500">Name</label>
            <input className="input" value={uploadName} onChange={(e) => setUploadName(e.target.value)} placeholder="Dataset name" />
          </div>
          <div>
            <label className="text-xs text-gray-500">Type</label>
            <select className="input" value={uploadType} onChange={(e) => setUploadType(e.target.value)}>
              <option value="raster">Raster (GeoTIFF)</option>
              <option value="vector">Vector (GeoJSON/Shapefile)</option>
              <option value="rainfall">Rainfall</option>
              <option value="flood_record">Flood Record</option>
              <option value="satellite">Satellite</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-500">Study Area</label>
            <select className="input" value={selectedArea} onChange={(e) => setSelectedArea(e.target.value)}>
              <option value="">None</option>
              {studyAreas.map((a) => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-500">File</label>
            <input
              type="file"
              className="input"
              onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
            />
          </div>
        </div>
        <button className="btn btn-primary mt-3" onClick={handleUpload} disabled={!uploadFile || !uploadName || uploading}>
          {uploading ? 'Uploading...' : 'Upload'}
        </button>
      </div>

      {/* Dataset list */}
      {loading ? (
        <div className="text-center py-12 text-gray-400">Loading...</div>
      ) : datasets.length === 0 ? (
        <div className="card text-center py-12">
          <Upload className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No datasets yet. Upload files or generate sample data.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 px-3 text-xs text-gray-500 uppercase">Name</th>
                <th className="text-left py-2 px-3 text-xs text-gray-500 uppercase">Type</th>
                <th className="text-left py-2 px-3 text-xs text-gray-500 uppercase">Size</th>
                <th className="text-left py-2 px-3 text-xs text-gray-500 uppercase">CRS</th>
                <th className="text-left py-2 px-3 text-xs text-gray-500 uppercase">Validation</th>
                <th className="text-left py-2 px-3 text-xs text-gray-500 uppercase">Status</th>
                <th className="text-left py-2 px-3 text-xs text-gray-500 uppercase">Sample</th>
                <th className="text-right py-2 px-3 text-xs text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {datasets.map((ds) => (
                <tr key={ds.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-2 px-3">
                    <div className="font-medium text-gray-900">{ds.name}</div>
                    {ds.original_filename && <div className="text-xs text-gray-400">{ds.original_filename}</div>}
                  </td>
                  <td className="py-2 px-3">
                    <span className="badge badge-blue">{TYPE_LABELS[ds.data_type] || ds.data_type}</span>
                  </td>
                  <td className="py-2 px-3 text-gray-600">{formatSize(ds.file_size_bytes)}</td>
                  <td className="py-2 px-3 text-gray-600 text-xs">{ds.crs || '—'}</td>
                  <td className="py-2 px-3">
                    {ds.validation_status === 'valid' ? (
                      <span className="badge badge-green"><CheckCircle className="w-3 h-3 inline mr-1" />Valid</span>
                    ) : ds.validation_status === 'invalid' ? (
                      <span className="badge badge-red"><XCircle className="w-3 h-3 inline mr-1" />Invalid</span>
                    ) : (
                      <span className="badge badge-gray">Pending</span>
                    )}
                  </td>
                  <td className="py-2 px-3">
                    <span className={`badge ${ds.processing_status === 'completed' ? 'badge-green' : 'badge-yellow'}`}>
                      {ds.processing_status}
                    </span>
                  </td>
                  <td className="py-2 px-3">{ds.is_sample_data ? <span className="badge badge-gray">Sample</span> : '—'}</td>
                  <td className="py-2 px-3 text-right">
                    <button onClick={() => handleValidate(ds.id)} className="text-blue-500 hover:text-blue-700 mr-2" title="Re-validate">
                      <RefreshCw className="w-4 h-4 inline" />
                    </button>
                    <button onClick={() => handleDelete(ds.id)} className="text-red-400 hover:text-red-600" title="Delete">
                      <Trash2 className="w-4 h-4 inline" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
