import { useState, useEffect, useRef } from 'react'
import { MapContainer, TileLayer, GeoJSON, LayersControl, useMapEvents, Marker, Popup } from 'react-leaflet'
import L from 'leaflet'
import { MapPin, Layers, Search } from 'lucide-react'
import { studyAreaApi, overlayApi, terrainApi, datasetApi } from '../services/api'
import type { StudyArea, RiskAssessment, Dataset } from '../types'

export default function GISMapExplorer() {
  const [studyAreas, setStudyAreas] = useState<StudyArea[]>([])
  const [selectedArea, setSelectedArea] = useState<StudyArea | null>(null)
  const [assessments, setAssessments] = useState<RiskAssessment[]>([])
  const [selectedAssessment, setSelectedAssessment] = useState<RiskAssessment | null>(null)
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [clickPoint, setClickPoint] = useState<{lat: number, lon: number} | null>(null)
  const [pointInfo, setPointInfo] = useState<any>(null)
  const [showBoundary, setShowBoundary] = useState(true)
  const mapRef = useRef<L.Map | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [saRes, aRes, dsRes] = await Promise.all([
        studyAreaApi.list(), overlayApi.listAssessments(), datasetApi.list(),
      ])
      setStudyAreas(saRes.data)
      setAssessments(aRes.data.filter((a: RiskAssessment) => a.status === 'completed'))
      setDatasets(dsRes.data)
    } catch (err) { console.error(err) }
  }

  const handleAreaSelect = (area: StudyArea) => {
    setSelectedArea(area)
    if (mapRef.current) {
      const center = [(area.bbox_min_lat + area.bbox_max_lat) / 2, (area.bbox_min_lon + area.bbox_max_lon) / 2]
      mapRef.current.setView(center as L.LatLngExpression, 10)
    }
  }

  const handleMapClick = async (e: L.LeafletMouseEvent) => {
    setClickPoint({ lat: e.latlng.lat, lon: e.latlng.lng })
    setPointInfo({ loading: true })

    try {
      // Query elevation if we have a DEM dataset
      const demDs = datasets.find(d => d.name.toLowerCase().includes('dem'))
      const slopeDs = datasets.find(d => d.name.toLowerCase().includes('slope'))
      let elev: number | null = null
      let slope: number | null = null

      if (demDs) {
        try {
          const r = await terrainApi.pointQuery(e.latlng.lng, e.latlng.lat, demDs.file_path, slopeDs?.file_path)
          elev = r.data.elevation
          slope = r.data.slope
        } catch {}
      }

      setPointInfo({
        loading: false,
        lat: e.latlng.lat,
        lon: e.latlng.lng,
        elevation: elev,
        slope: slope,
        note: "Values sampled from raster data at nearest pixel. Unavailable attributes are shown as '—'.",
      })
    } catch {
      setPointInfo({ loading: false, lat: e.latlng.lat, lon: e.latlng.lng, elevation: null, slope: null })
    }
  }

  const boundaryGeoJSON = selectedArea?.boundary_geojson
    ? (typeof selectedArea.boundary_geojson === 'string'
        ? JSON.parse(selectedArea.boundary_geojson)
        : selectedArea.boundary_geojson)
    : null

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <div className="w-72 bg-white border-r border-gray-200 p-4 overflow-y-auto flex-shrink-0">
        <h2 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Layers className="w-4 h-4" /> Map Controls
        </h2>

        {/* Study area selector */}
        <div className="mb-4">
          <label className="text-xs text-gray-500">Study Area</label>
          <select className="input" onChange={(e) => {
            const area = studyAreas.find(a => a.id === e.target.value)
            if (area) handleAreaSelect(area)
          }}>
            <option value="">Select study area...</option>
            {studyAreas.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>

        {/* Assessment selector */}
        <div className="mb-4">
          <label className="text-xs text-gray-500">Risk Assessment</label>
          <select className="input" onChange={(e) => {
            const a = assessments.find(a => a.id === e.target.value)
            setSelectedAssessment(a || null)
          }}>
            <option value="">None</option>
            {assessments.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>

        {/* Layer toggles */}
        <div className="mb-4">
          <h3 className="text-xs font-medium text-gray-500 uppercase mb-2">Layers</h3>
          <label className="flex items-center gap-2 text-sm mb-1">
            <input type="checkbox" checked={showBoundary} onChange={(e) => setShowBoundary(e.target.checked)} />
            Study Area Boundary
          </label>
          <label className="flex items-center gap-2 text-sm mb-1">
            <input type="checkbox" defaultChecked />
            OpenStreetMap Base
          </label>
        </div>

        {/* Point info */}
        {clickPoint && pointInfo && (
          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <h3 className="text-xs font-medium text-gray-500 uppercase mb-2 flex items-center gap-1">
              <MapPin className="w-3 h-3" /> Location Info
            </h3>
            {pointInfo.loading ? (
              <p className="text-xs text-gray-400">Querying...</p>
            ) : (
              <div className="space-y-1 text-xs">
                <div><span className="text-gray-500">Lat:</span> {pointInfo.lat?.toFixed(6)}</div>
                <div><span className="text-gray-500">Lon:</span> {pointInfo.lon?.toFixed(6)}</div>
                <div><span className="text-gray-500">Elevation:</span> {pointInfo.elevation !== null ? `${pointInfo.elevation?.toFixed(1)} m` : '—'}</div>
                <div><span className="text-gray-500">Slope:</span> {pointInfo.slope !== null ? `${pointInfo.slope?.toFixed(1)}°` : '—'}</div>
                <div className="text-gray-400 mt-1 italic">{pointInfo.note}</div>
              </div>
            )}
          </div>
        )}

        {/* Assessment stats */}
        {selectedAssessment && selectedAssessment.statistics && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <h3 className="text-xs font-medium text-blue-600 uppercase mb-2">Risk Distribution</h3>
            <div className="space-y-1 text-xs">
              {Object.entries(selectedAssessment.statistics.risk_distribution || {}).map(([cat, count]) => (
                <div key={cat} className="flex justify-between">
                  <span>{cat}:</span>
                  <span className="font-medium">{count as number}</span>
                </div>
              ))}
              <div className="flex justify-between pt-1 border-t border-blue-200">
                <span>High Risk %:</span>
                <span className="font-bold">{selectedAssessment.statistics.high_risk_percentage}%</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Map */}
      <div className="flex-1 relative">
        <MapContainer
          center={[17.385, 78.487]}
          zoom={10}
          style={{ height: '100%', width: '100%' }}
          ref={mapRef as any}
        >
          <LayersControl position="topright">
            <LayersControl.BaseLayer checked name="OpenStreetMap">
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; OpenStreetMap' />
            </LayersControl.BaseLayer>
            <LayersControl.BaseLayer name="Satellite">
              <TileLayer url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}" attribution='&copy; Esri' />
            </LayersControl.BaseLayer>
          </LayersControl>

          <ClickHandler onClick={handleMapClick} />

          {showBoundary && boundaryGeoJSON && (
            <GeoJSON data={boundaryGeoJSON} style={{ color: '#3b82f6', weight: 2, fillOpacity: 0.1 }} />
          )}

          {clickPoint && (
            <Marker position={[clickPoint.lat, clickPoint.lon]}>
              <Popup>
                <div className="text-xs">
                  <p><b>Lat:</b> {clickPoint.lat.toFixed(6)}</p>
                  <p><b>Lon:</b> {clickPoint.lon.toFixed(6)}</p>
                </div>
              </Popup>
            </Marker>
          )}
        </MapContainer>
      </div>
    </div>
  )
}

function ClickHandler({ onClick }: { onClick: (e: L.LeafletMouseEvent) => void }) {
  useMapEvents({ click: onClick })
  return null
}
