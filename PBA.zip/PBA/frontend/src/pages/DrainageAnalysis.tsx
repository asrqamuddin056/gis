import { useState, useEffect } from 'react'
import { Waves, Play } from 'lucide-react'
import { datasetApi, drainageApi } from '../services/api'
import type { Dataset } from '../types'

export default function DrainageAnalysis() {
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [rasterDatasets, setRasterDatasets] = useState<Dataset[]>([])
  const [selectedId, setSelectedId] = useState('')
  const [refRasterId, setRefRasterId] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<any>(null)

  useEffect(() => { loadDatasets() }, [])

  const loadDatasets = async () => {
    try {
      const res = await datasetApi.list()
      const all = res.data
      setDatasets(all.filter((d: Dataset) => d.data_type === 'vector'))
      setRasterDatasets(all.filter((d: Dataset) => d.data_type === 'raster'))
    } catch (err) { console.error(err) }
  }

  const handleAnalyze = async () => {
    if (!selectedId) return
    setAnalyzing(true)
    try {
      const res = await drainageApi.analyze(selectedId, refRasterId || undefined)
      setResult(res.data.result)
    } catch (err) { console.error(err) }
    finally { setAnalyzing(false) }
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Drainage Analysis</h1>
        <p className="text-sm text-gray-500 mt-1">Drainage networks, proximity analysis, and buffer zones</p>
      </div>

      <div className="card mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
          <div>
            <label className="text-xs text-gray-500">Drainage Vector</label>
            <select className="input" value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
              <option value="">Select drainage dataset...</option>
              {datasets.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-500">Reference Raster (for distance grid)</label>
            <select className="input" value={refRasterId} onChange={(e) => setRefRasterId(e.target.value)}>
              <option value="">None</option>
              {rasterDatasets.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <button className="btn btn-primary" onClick={handleAnalyze} disabled={!selectedId || analyzing}>
            {analyzing ? 'Analyzing...' : <><Play className="w-4 h-4 inline mr-1" /> Analyze</>}
          </button>
        </div>
      </div>

      {result && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="stat-card"><p className="text-xs text-gray-500">Features</p><p className="text-xl font-bold text-navy-700">{result.feature_count}</p></div>
            <div className="stat-card"><p className="text-xs text-gray-500">Rivers</p><p className="text-xl font-bold text-blue-600">{result.rivers?.length || 0}</p></div>
            <div className="stat-card"><p className="text-xs text-gray-500">Lakes</p><p className="text-xl font-bold text-blue-600">{result.lakes?.length || 0}</p></div>
            <div className="stat-card"><p className="text-xs text-gray-500">Water Bodies</p><p className="text-xl font-bold text-blue-600">{result.water_bodies?.length || 0}</p></div>
          </div>

          {result.distance_stats && Object.keys(result.distance_stats).length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Distance to Nearest Drainage (m)</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div><span className="text-xs text-gray-500">Min:</span> <span className="font-medium">{result.distance_stats.min?.toFixed(1)} m</span></div>
                <div><span className="text-xs text-gray-500">Max:</span> <span className="font-medium">{result.distance_stats.max?.toFixed(1)} m</span></div>
                <div><span className="text-xs text-gray-500">Mean:</span> <span className="font-medium">{result.distance_stats.mean?.toFixed(1)} m</span></div>
                <div><span className="text-xs text-gray-500">Std:</span> <span className="font-medium">{result.distance_stats.std?.toFixed(1)} m</span></div>
              </div>
            </div>
          )}

          {result.buffers && Object.keys(result.buffers).length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Buffer Zones Generated</h3>
              <div className="space-y-2">
                {Object.entries(result.buffers).map(([key, path]) => (
                  <div key={key} className="flex items-center gap-2 text-sm">
                    <Waves className="w-4 h-4 text-blue-500" />
                    <span>{key} buffer</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {result.note && (
            <div className="card bg-yellow-50 border-yellow-200">
              <p className="text-xs text-yellow-700">{result.note}</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
