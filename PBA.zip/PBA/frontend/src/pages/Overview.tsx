import { useState, useEffect } from 'react'
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { AlertTriangle, Database, Map, Activity, TrendingUp, Calendar } from 'lucide-react'
import { dashboardApi, datasetApi } from '../services/api'
import type { DashboardStats } from '../types'

const RISK_COLORS = {
  Low: '#22c55e',
  Medium: '#eab308',
  High: '#f97316',
  'Very High': '#ef4444',
  'No Data': '#94a3b8',
}

export default function Overview() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [datasetStats, setDatasetStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      const [statsRes, dsRes] = await Promise.all([
        dashboardApi.getStats(),
        datasetApi.stats(),
      ])
      setStats(statsRes.data)
      setDatasetStats(dsRes.data)
    } catch (err) {
      console.error('Failed to load dashboard stats:', err)
    } finally {
      setLoading(false)
    }
  }

  const riskData = stats?.risk_distribution
    ? Object.entries(stats.risk_distribution)
        .filter(([k]) => k !== 'No Data')
        .map(([name, value]) => ({ name, value: value as number }))
    : []

  const datasetTypeData = datasetStats?.by_type
    ? Object.entries(datasetStats.by_type).map(([name, value]) => ({ name, value: value as number }))
    : []

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
        <p className="text-sm text-gray-500 mt-1">Real-time flood risk assessment system statistics</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Activity className="w-8 h-8 text-blue-500 animate-pulse" />
        </div>
      ) : (
        <>
          {/* Stat cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard icon={Map} label="Study Areas" value={stats?.total_study_areas ?? 0} color="blue" />
            <StatCard icon={Database} label="Datasets Processed" value={stats?.datasets_processed ?? 0} color="cyan" />
            <StatCard icon={AlertTriangle} label="High Risk Zones" value={stats?.high_risk_zones ?? 0} color="orange" />
            <StatCard icon={TrendingUp} label="High Risk %" value={`${stats?.high_risk_percentage ?? 0}%`} color="red" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard icon={Activity} label="Total Assessments" value={stats?.total_assessments ?? 0} color="blue" />
            <StatCard icon={AlertTriangle} label="Very High Risk Zones" value={stats?.very_high_risk_zones ?? 0} color="red" />
            <StatCard icon={Map} label="Area Analysed (km²)" value={(stats?.area_analysed_km2 ?? 0).toFixed(2)} color="cyan" />
            <StatCard icon={Calendar} label="ML Models Trained" value={stats?.ml_models_trained ?? 0} color="green" />
          </div>

          {/* Latest assessment info */}
          {stats?.latest_assessment_date && (
            <div className="card mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>Latest Assessment: {new Date(stats.latest_assessment_date).toLocaleString()}</span>
              </div>
            </div>
          )}

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {riskData.length > 0 && (
              <div className="card">
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Flood Risk Distribution</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie data={riskData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                      {riskData.map((entry, i) => (
                        <Cell key={i} fill={RISK_COLORS[entry.name as keyof typeof RISK_COLORS] || '#94a3b8'} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            {datasetTypeData.length > 0 && (
              <div className="card">
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Dataset Types</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={datasetTypeData}>
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* ML Metrics */}
          {stats?.model_metrics && Object.keys(stats.model_metrics).length > 0 && (
            <div className="card mt-6">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Model Evaluation Metrics</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {(['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc'] as const).map((m) => (
                  <div key={m} className="text-center">
                    <p className="text-xs text-gray-500 uppercase">{m.replace('_', ' ')}</p>
                    <p className="text-lg font-bold text-navy-700">
                      {typeof stats.model_metrics[m] === 'number'
                        ? (stats.model_metrics[m] as number).toFixed(4)
                        : stats.model_metrics[m] || 'N/A'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {stats?.total_assessments === 0 && (
            <div className="card mt-6 text-center py-8">
              <p className="text-gray-500">No assessments yet. Go to Study Areas to create one, then run the Flood Risk Assessment.</p>
            </div>
          )}
        </>
      )}
    </div>
  )
}

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: any; color: string }) {
  const colors: Record<string, string> = {
    blue: 'text-blue-600 bg-blue-50',
    cyan: 'text-cyan-600 bg-cyan-50',
    orange: 'text-orange-600 bg-orange-50',
    red: 'text-red-600 bg-red-50',
    green: 'text-green-600 bg-green-50',
  }
  return (
    <div className="stat-card">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-gray-500 uppercase">{label}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
        </div>
        <div className={`p-2 rounded-lg ${colors[color]}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  )
}
