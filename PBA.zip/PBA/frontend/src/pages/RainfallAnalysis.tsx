import { useState, useEffect } from 'react'
import { CloudRain, Play } from 'lucide-react'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { datasetApi, rainfallApi } from '../services/api'
import type { Dataset } from '../types'

const INTENSITY_COLORS: Record<string, string> = {
  very_light: '#a3d977', light: '#66c2a5', moderate: '#fdae61', heavy: '#f46d43', very_heavy: '#a50026',
}

export default function RainfallAnalysis() {
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [selectedId, setSelectedId] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<any>(null)

  useEffect(() => { loadDatasets() }, [])

  const loadDatasets = async () => {
    try {
      const res = await datasetApi.list()
      setDatasets(res.data.filter((d: Dataset) => d.data_type === 'rainfall'))
    } catch (err) { console.error(err) }
  }

  const handleAnalyze = async () => {
    if (!selectedId) return
    setAnalyzing(true)
    try {
      const res = await rainfallApi.analyze(selectedId)
      setResult(res.data.result)
    } catch (err) { console.error(err) }
    finally { setAnalyzing(false) }
  }

  const monthlyData = result?.temporal?.monthly_average
    ? Object.entries(result.temporal.monthly_average).map(([month, mm]) => ({ month, mm: mm as number }))
    : []

  const intensityData = result?.intensity_distribution
    ? Object.entries(result.intensity_distribution).map(([name, value]) => ({ name, value: value as number }))
    : []

  const stationData = result?.stations || []

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Rainfall Analysis</h1>
        <p className="text-sm text-gray-500 mt-1">Rainfall distribution, intensity classification, and temporal analysis</p>
      </div>

      <div className="card mb-6">
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <label className="text-xs text-gray-500">Rainfall Dataset</label>
            <select className="input" value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
              <option value="">Select a rainfall dataset...</option>
              {datasets.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <button className="btn btn-primary" onClick={handleAnalyze} disabled={!selectedId || analyzing}>
            {analyzing ? 'Analyzing...' : <><Play className="w-4 h-4 inline mr-1" /> Analyze</>}
          </button>
        </div>
      </div>

      {result && (
        <div className="space-y-6">
          {result.stats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="stat-card"><p className="text-xs text-gray-500">Min Rainfall</p><p className="text-xl font-bold text-blue-600">{result.stats.min_rainfall?.toFixed(1)} mm</p></div>
              <div className="stat-card"><p className="text-xs text-gray-500">Max Rainfall</p><p className="text-xl font-bold text-blue-600">{result.stats.max_rainfall?.toFixed(1)} mm</p></div>
              <div className="stat-card"><p className="text-xs text-gray-500">Mean Rainfall</p><p className="text-xl font-bold text-blue-600">{result.stats.mean_rainfall?.toFixed(1)} mm</p></div>
              <div className="stat-card"><p className="text-xs text-gray-500">Records</p><p className="text-xl font-bold text-navy-700">{result.stats.total_records}</p></div>
            </div>
          )}

          {monthlyData.length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Monthly Average Rainfall</h3>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={monthlyData}>
                  <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="mm" stroke="#3b82f6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {intensityData.length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Rainfall Intensity Distribution</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={intensityData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                    {intensityData.map((entry, i) => (
                      <Cell key={i} fill={INTENSITY_COLORS[entry.name] || '#94a3b8'} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}

          {result.anomalies && result.anomalies.length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Anomalies (Unusually High Rainfall)</h3>
              <table className="w-full text-sm">
                <thead><tr className="border-b border-gray-200">
                  <th className="text-left py-2 text-xs text-gray-500">Rainfall (mm)</th>
                  <th className="text-left py-2 text-xs text-gray-500">Station</th>
                  <th className="text-left py-2 text-xs text-gray-500">Month</th>
                  <th className="text-left py-2 text-xs text-gray-500">Year</th>
                </tr></thead>
                <tbody>
                  {result.anomalies.slice(0, 10).map((a: any, i: number) => (
                    <tr key={i} className="border-b border-gray-100">
                      <td className="py-2 font-medium text-orange-600">{a.rainfall_mm?.toFixed(1)}</td>
                      <td className="py-2">{a.station || '—'}</td>
                      <td className="py-2">{a.month || '—'}</td>
                      <td className="py-2">{a.year || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {result.note && (
            <div className="card bg-yellow-50 border-yellow-200">
              <p className="text-xs text-yellow-700">{result.note}</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
