import { useState, useEffect } from 'react'
import { Trees, Play } from 'lucide-react'
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { datasetApi, lulcApi } from '../services/api'
import type { Dataset } from '../types'

const CLASS_COLORS: Record<string, string> = {
  'Water bodies': '#3b82f6', Vegetation: '#22c55e', 'Built-up areas': '#f97316',
  'Agricultural land': '#eab308', 'Bare soil': '#a78bfa',
}

export default function LULCClassification() {
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [selectedId, setSelectedId] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [classes, setClasses] = useState<Record<string, string>>({})

  useEffect(() => {
    loadDatasets()
    loadClasses()
  }, [])

  const loadDatasets = async () => {
    try {
      const res = await datasetApi.list()
      setDatasets(res.data.filter((d: Dataset) => d.data_type === 'raster' && (d.name.toLowerCase().includes('lulc') || d.name.toLowerCase().includes('land'))))
    } catch (err) { console.error(err) }
  }

  const loadClasses = async () => {
    try {
      const res = await lulcApi.classes()
      setClasses(res.data.classes)
    } catch (err) { console.error(err) }
  }

  const handleAnalyze = async () => {
    if (!selectedId) return
    setAnalyzing(true)
    try {
      const res = await lulcApi.analyze(selectedId)
      setResult(res.data.result)
    } catch (err) { console.error(err) }
    finally { setAnalyzing(false) }
  }

  const distributionData = result?.class_distribution
    ? Object.entries(result.class_distribution).map(([name, pct]) => ({ name, value: pct as number }))
    : []

  const areaData = result?.class_areas_km2
    ? Object.entries(result.class_areas_km2).map(([name, area]) => ({ name, area: area as number }))
    : []

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">LULC Classification</h1>
        <p className="text-sm text-gray-500 mt-1">Land Use / Land Cover analysis and classification</p>
      </div>

      <div className="card mb-6">
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <label className="text-xs text-gray-500">LULC Raster</label>
            <select className="input" value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
              <option value="">Select a LULC dataset...</option>
              {datasets.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <button className="btn btn-primary" onClick={handleAnalyze} disabled={!selectedId || analyzing}>
            {analyzing ? 'Analyzing...' : <><Play className="w-4 h-4 inline mr-1" /> Analyze</>}
          </button>
        </div>
      </div>

      {result && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="stat-card"><p className="text-xs text-gray-500">Total Area</p><p className="text-xl font-bold text-navy-700">{result.total_area_km2?.toFixed(2)} km²</p></div>
            <div className="stat-card"><p className="text-xs text-gray-500">Pixel Size</p><p className="text-xl font-bold text-navy-700">{result.pixel_size_deg?.toFixed(4)}°</p></div>
            <div className="stat-card"><p className="text-xs text-gray-500">CRS</p><p className="text-xl font-bold text-navy-700 text-sm">{result.crs}</p></div>
          </div>

          {distributionData.length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Class Distribution (%)</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={distributionData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                    {distributionData.map((entry, i) => (
                      <Cell key={i} fill={CLASS_COLORS[entry.name] || '#94a3b8'} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}

          {areaData.length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Area by Class (km²)</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={areaData}>
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="area" fill="#22c55e" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          <div className="card">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">LULC Classes</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {Object.entries(classes).map(([code, name]) => (
                <div key={code} className="flex items-center gap-2 p-2 border border-gray-200 rounded">
                  <div className="w-3 h-3 rounded" style={{ background: CLASS_COLORS[name] || '#94a3b8' }} />
                  <span className="text-sm">{code}: {name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
