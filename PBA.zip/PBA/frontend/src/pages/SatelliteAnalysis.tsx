import { useState, useEffect } from 'react'
import { Satellite, Upload, Info } from 'lucide-react'
import { satelliteApi } from '../services/api'

export default function SatelliteAnalysis() {
  const [info, setInfo] = useState<any>(null)
  const [redFile, setRedFile] = useState<File | null>(null)
  const [nirFile, setNirFile] = useState<File | null>(null)
  const [greenFile, setGreenFile] = useState<File | null>(null)
  const [processing, setProcessing] = useState(false)
  const [result, setResult] = useState<any>(null)

  useEffect(() => {
    satelliteApi.info().then(res => setInfo(res.data)).catch(console.error)
  }, [])

  const handleProcess = async () => {
    setProcessing(true)
    try {
      const formData = new FormData()
      if (redFile) formData.append('red_file', redFile)
      if (nirFile) formData.append('nir_file', nirFile)
      if (greenFile) formData.append('green_file', greenFile)
      const res = await satelliteApi.process(formData)
      setResult(res.data.result)
    } catch (err: any) {
      console.error(err)
      alert(err.response?.data?.detail || 'Processing failed')
    } finally { setProcessing(false) }
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Satellite Analysis</h1>
        <p className="text-sm text-gray-500 mt-1">Satellite imagery processing and spectral index calculation</p>
      </div>

      {/* Info banner */}
      <div className={`card mb-6 ${info?.status === 'upload_mode' ? 'bg-blue-50 border-blue-200' : 'bg-green-50 border-green-200'}`}>
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium">{info?.source || 'Loading...'}</p>
            {info?.note && <p className="text-xs text-gray-600 mt-1">{info.note}</p>}
          </div>
        </div>
      </div>

      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Upload Satellite Bands</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <label className="text-xs text-gray-500">Red Band (GeoTIFF)</label>
            <input type="file" className="input" accept=".tif,.tiff" onChange={(e) => setRedFile(e.target.files?.[0] || null)} />
          </div>
          <div>
            <label className="text-xs text-gray-500">NIR Band (GeoTIFF)</label>
            <input type="file" className="input" accept=".tif,.tiff" onChange={(e) => setNirFile(e.target.files?.[0] || null)} />
          </div>
          <div>
            <label className="text-xs text-gray-500">Green Band (GeoTIFF)</label>
            <input type="file" className="input" accept=".tif,.tiff" onChange={(e) => setGreenFile(e.target.files?.[0] || null)} />
          </div>
        </div>
        <button className="btn btn-primary mt-3" onClick={handleProcess} disabled={!redFile && !nirFile && !greenFile || processing}>
          {processing ? 'Processing...' : <><Upload className="w-4 h-4 inline mr-1" /> Process Bands</>}
        </button>
      </div>

      {/* Spectral indices info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="card">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">NDVI</h3>
          <p className="text-xs text-gray-500">Normalised Difference Vegetation Index</p>
          <p className="text-sm font-mono mt-2 bg-gray-50 p-2 rounded">NDVI = (NIR - Red) / (NIR + Red)</p>
          <p className="text-xs text-gray-600 mt-2">Range: -1 to +1. Higher values indicate denser vegetation.</p>
        </div>
        <div className="card">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">NDWI</h3>
          <p className="text-xs text-gray-500">Normalised Difference Water Index</p>
          <p className="text-sm font-mono mt-2 bg-gray-50 p-2 rounded">NDWI = (Green - NIR) / (Green + NIR)</p>
          <p className="text-xs text-gray-600 mt-2">Used for identifying water-related features.</p>
        </div>
      </div>

      {result && (
        <div className="card">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Processing Results</h3>
          <pre className="text-xs bg-gray-50 p-3 rounded overflow-x-auto">{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  )
}
