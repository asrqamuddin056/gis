import { useState, useEffect } from 'react'
import { Mountain, BarChart3, Play } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { datasetApi, terrainApi } from '../services/api'
import type { Dataset } from '../types'

export default function TerrainAnalysis() {
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [selectedId, setSelectedId] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [distribution, setDistribution] = useState<any>(null)

  useEffect(() => {
    loadDatasets()
  }, [])

  const loadDatasets = async () => {
    try {
      const res = await datasetApi.list()
      const rasters = res.data.filter((d: Dataset) => d.data_type === 'raster' && d.name.toLowerCase().includes('dem'))
      setDatasets(rasters)
    } catch (err) {
      console.error(err)
    }
  }

  const handleAnalyze = async () => {
    if (!selectedId) return
    setAnalyzing(true)
    try {
      const res = await terrainApi.analyze(selectedId)
      setResult(res.data.result)

      const distRes = await terrainApi.elevationDistribution(selectedId)
      setDistribution(distRes.data.distribution)
    } catch (err) {
      console.error(err)
    } finally {
      setAnalyzing(false)
    }
  }

  const elevData = distribution?.bins?.map((b: number, i: number) => ({ elevation: b, count: distribution.counts[i] })) || []
  const slopeClasses = result?.slope_classification?.classes || {}

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Terrain Analysis (DEM)</h1>
        <p className="text-sm text-gray-500 mt-1">Digital Elevation Model processing — elevation and slope analysis</p>
      </div>

      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Select DEM Dataset</h3>
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <label className="text-xs text-gray-500">DEM Raster</label>
            <select className="input" value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
              <option value="">Select a DEM dataset...</option>
              {datasets.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>
          <button className="btn btn-primary" onClick={handleAnalyze} disabled={!selectedId || analyzing}>
            {analyzing ? 'Analyzing...' : <><Play className="w-4 h-4 inline mr-1" /> Analyze DEM</>}
          </button>
        </div>
      </div>

      {result && (
        <div className="space-y-6">
          {/* Elevation stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="stat-card">
              <p className="text-xs text-gray-500">Min Elevation</p>
              <p className="text-xl font-bold text-navy-700">{result.elevation.stats.min?.toFixed(1)} m</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">Max Elevation</p>
              <p className="text-xl font-bold text-navy-700">{result.elevation.stats.max?.toFixed(1)} m</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">Mean Elevation</p>
              <p className="text-xl font-bold text-navy-700">{result.elevation.stats.mean?.toFixed(1)} m</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">Low-Elev. Pixels</p>
              <p className="text-xl font-bold text-navy-700">{result.low_elevation_pixels}</p>
            </div>
          </div>

          {/* Slope stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="stat-card">
              <p className="text-xs text-gray-500">Min Slope</p>
              <p className="text-xl font-bold text-navy-700">{result.slope.stats.min?.toFixed(1)}°</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">Max Slope</p>
              <p className="text-xl font-bold text-navy-700">{result.slope.stats.max?.toFixed(1)}°</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">Mean Slope</p>
              <p className="text-xl font-bold text-navy-700">{result.slope.stats.mean?.toFixed(1)}°</p>
            </div>
            <div className="stat-card">
              <p className="text-xs text-gray-500">Pixel Size</p>
              <p className="text-xl font-bold text-navy-700">{result.slope.pixel_size_m?.toFixed(0)} m</p>
            </div>
          </div>

          {/* Elevation distribution chart */}
          {elevData.length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Elevation Distribution</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={elevData}>
                  <XAxis dataKey="elevation" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Slope classification */}
          {Object.keys(slopeClasses).length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Slope Classification</h3>
              <div className="grid grid-cols-4 gap-4">
                {Object.entries(slopeClasses).map(([name, count]) => (
                  <div key={name} className="text-center p-3 border border-gray-200 rounded-lg">
                    <p className="text-xs text-gray-500 capitalize">{name}</p>
                    <p className="text-lg font-bold text-navy-700">{count as number}</p>
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-400 mt-3">
                Note: Low-elevation and flat areas contribute to higher flood susceptibility, but low elevation alone
                does not guarantee flooding. Multiple factors interact.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
