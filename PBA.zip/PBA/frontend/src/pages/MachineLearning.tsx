import { useState, useEffect } from 'react'
import { Brain, Play, Download } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { studyAreaApi, datasetApi, mlApi } from '../services/api'
import type { StudyArea, Dataset, MLModel } from '../types'

export default function MachineLearning() {
  const [studyAreas, setStudyAreas] = useState<StudyArea[]>([])
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [models, setModels] = useState<MLModel[]>([])
  const [selectedArea, setSelectedArea] = useState('')
  const [selectedDataset, setSelectedDataset] = useState('')
  const [algorithm, setAlgorithm] = useState('random_forest')
  const [training, setTraining] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [evaluations, setEvaluations] = useState<Record<string, any>>({})

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    try {
      const [saRes, dsRes, mlRes] = await Promise.all([
        studyAreaApi.list(), datasetApi.list(), mlApi.listModels(),
      ])
      setStudyAreas(saRes.data)
      setDatasets(dsRes.data.filter((d: Dataset) => d.data_type === 'flood_record'))
      setModels(mlRes.data)
      // Load evaluations for trained models
      for (const m of mlRes.data) {
        if (m.status === 'trained') {
          try {
            const e = await mlApi.getEvaluation(m.id)
            setEvaluations(prev => ({ ...prev, [m.id]: e.data }))
          } catch {}
        }
      }
    } catch (err) { console.error(err) }
  }

  const handleTrain = async () => {
    if (!selectedDataset || !selectedArea) return
    setTraining(true)
    try {
      const res = await mlApi.train({
        study_area_id: selectedArea, dataset_id: selectedDataset,
        algorithm, test_size: 0.3, random_state: 42, hyperparameters: {},
      })
      setResult(res.data)
      loadData()
    } catch (err: any) {
      console.error(err)
      alert(err.response?.data?.detail || 'Training failed')
    } finally { setTraining(false) }
  }

  const fiData = result?.result?.feature_importance
    ? Object.entries(result.result.feature_importance).map(([name, imp]) => ({ name: name.replace(/_/g, ' '), importance: imp as number }))
    : []

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Machine Learning</h1>
        <p className="text-sm text-gray-500 mt-1">Flood susceptibility prediction using supervised learning</p>
      </div>

      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Train New Model</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
          <div>
            <label className="text-xs text-gray-500">Study Area</label>
            <select className="input" value={selectedArea} onChange={(e) => setSelectedArea(e.target.value)}>
              <option value="">Select...</option>
              {studyAreas.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-500">Flood Occurrence Dataset</label>
            <select className="input" value={selectedDataset} onChange={(e) => setSelectedDataset(e.target.value)}>
              <option value="">Select...</option>
              {datasets.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-500">Algorithm</label>
            <select className="input" value={algorithm} onChange={(e) => setAlgorithm(e.target.value)}>
              <option value="random_forest">Random Forest</option>
              <option value="xgboost">XGBoost</option>
              <option value="logistic_regression">Logistic Regression</option>
            </select>
          </div>
          <button className="btn btn-primary" onClick={handleTrain} disabled={!selectedDataset || !selectedArea || training}>
            {training ? 'Training...' : <><Play className="w-4 h-4 inline mr-1" /> Train</>}
          </button>
        </div>
        <p className="text-xs text-gray-400 mt-3">
          Note: ML training requires labelled historical flood data. Uses spatially separated validation to avoid data leakage.
        </p>
      </div>

      {result && result.status === 'trained' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {(['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc'] as const).map((m) => (
              <div key={m} className="stat-card">
                <p className="text-xs text-gray-500 uppercase">{m.replace('_', ' ')}</p>
                <p className="text-xl font-bold text-navy-700">{(result.result as any)[m]?.toFixed(4)}</p>
              </div>
            ))}
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Training Details</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div><span className="text-gray-500">Algorithm:</span> {result.result.algorithm}</div>
              <div><span className="text-gray-500">Samples:</span> {result.result.n_samples}</div>
              <div><span className="text-gray-500">Features:</span> {result.result.n_features}</div>
              <div><span className="text-gray-500">Validation:</span> {result.result.validation_strategy}</div>
              <div><span className="text-gray-500">Train set:</span> {result.result.n_train}</div>
              <div><span className="text-gray-500">Test set:</span> {result.result.n_test}</div>
              <div><span className="text-gray-500">Flood:</span> {result.result.class_distribution.flood}</div>
              <div><span className="text-gray-500">Non-flood:</span> {result.result.class_distribution.non_flood}</div>
            </div>
          </div>

          {fiData.length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Feature Importance</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={fiData} layout="vertical">
                  <XAxis type="number" tick={{ fontSize: 10 }} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={100} />
                  <Tooltip />
                  <Bar dataKey="importance" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {result.result.confusion_matrix && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Confusion Matrix</h3>
              <table className="text-sm">
                <thead><tr>
                  <th className="px-4 py-2"></th>
                  <th className="px-4 py-2 text-xs text-gray-500">Predicted Non-Flood</th>
                  <th className="px-4 py-2 text-xs text-gray-500">Predicted Flood</th>
                </tr></thead>
                <tbody>
                  <tr>
                    <td className="px-4 py-2 text-xs text-gray-500">Actual Non-Flood</td>
                    <td className="px-4 py-2 text-center">{result.result.confusion_matrix[0][0]}</td>
                    <td className="px-4 py-2 text-center">{result.result.confusion_matrix[0][1]}</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 text-xs text-gray-500">Actual Flood</td>
                    <td className="px-4 py-2 text-center">{result.result.confusion_matrix[1][0]}</td>
                    <td className="px-4 py-2 text-center bg-red-50">{result.result.confusion_matrix[1][1]}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Model history */}
      {models.length > 0 && (
        <div className="card mt-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Trained Models</h3>
          <table className="w-full text-sm">
            <thead><tr className="border-b border-gray-200">
              <th className="text-left py-2 text-xs text-gray-500 uppercase">Name</th>
              <th className="text-left py-2 text-xs text-gray-500 uppercase">Algorithm</th>
              <th className="text-left py-2 text-xs text-gray-500 uppercase">Status</th>
              <th className="text-left py-2 text-xs text-gray-500 uppercase">Accuracy</th>
              <th className="text-left py-2 text-xs text-gray-500 uppercase">F1</th>
              <th className="text-left py-2 text-xs text-gray-500 uppercase">Date</th>
            </tr></thead>
            <tbody>
              {models.map((m) => (
                <tr key={m.id} className="border-b border-gray-100">
                  <td className="py-2">{m.name}</td>
                  <td className="py-2">{m.algorithm}</td>
                  <td className="py-2"><span className={`badge ${m.status === 'trained' ? 'badge-green' : 'badge-yellow'}`}>{m.status}</span></td>
                  <td className="py-2">{evaluations[m.id]?.accuracy?.toFixed(4) || '—'}</td>
                  <td className="py-2">{evaluations[m.id]?.f1_score?.toFixed(4) || '—'}</td>
                  <td className="py-2 text-gray-500">{new Date(m.created_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
