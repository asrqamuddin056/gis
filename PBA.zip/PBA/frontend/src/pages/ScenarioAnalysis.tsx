import { useState, useEffect } from 'react'
import { GitCompare, Play } from 'lucide-react'
import { studyAreaApi, overlayApi, scenarioApi } from '../services/api'
import type { StudyArea, RiskAssessment, ScenarioAnalysis as ScenarioType } from '../types'

export default function ScenarioAnalysis() {
  const [studyAreas, setStudyAreas] = useState<StudyArea[]>([])
  const [assessments, setAssessments] = useState<RiskAssessment[]>([])
  const [scenarios, setScenarios] = useState<ScenarioType[]>([])
  const [selectedArea, setSelectedArea] = useState('')
  const [baselineId, setBaselineId] = useState('')
  const [rainfall, setRainfall] = useState(150)
  const [scenarioName, setScenarioName] = useState('Rainfall Scenario')
  const [running, setRunning] = useState(false)
  const [result, setResult] = useState<any>(null)

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    try {
      const [saRes, aRes, scRes] = await Promise.all([
        studyAreaApi.list(), overlayApi.listAssessments(), scenarioApi.list(),
      ])
      setStudyAreas(saRes.data)
      setAssessments(aRes.data.filter((a: RiskAssessment) => a.status === 'completed'))
      setScenarios(scRes.data)
    } catch (err) { console.error(err) }
  }

  const handleRun = async () => {
    if (!selectedArea) return
    setRunning(true)
    try {
      const res = await scenarioApi.run({
        study_area_id: selectedArea,
        name: scenarioName,
        scenario_rainfall_mm: rainfall,
        baseline_assessment_id: baselineId || null,
      })
      setResult(res.data)
      loadData()
    } catch (err: any) {
      console.error(err)
      alert(err.response?.data?.detail || 'Scenario failed')
    } finally { setRunning(false) }
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Scenario Analysis</h1>
        <p className="text-sm text-gray-500 mt-1">Hypothetical rainfall scenario assessment</p>
      </div>

      <div className="card bg-yellow-50 border-yellow-200 mb-6">
        <p className="text-xs text-yellow-700">
          This is a scenario-based susceptibility assessment, NOT validated future flood forecasting.
          The system recalculates the rainfall component using a hypothetical intensity value.
        </p>
      </div>

      <div className="card mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
          <div>
            <label className="text-xs text-gray-500">Study Area</label>
            <select className="input" value={selectedArea} onChange={(e) => setSelectedArea(e.target.value)}>
              <option value="">Select...</option>
              {studyAreas.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-500">Baseline Assessment</label>
            <select className="input" value={baselineId} onChange={(e) => setBaselineId(e.target.value)}>
              <option value="">None</option>
              {assessments.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-500">Scenario Rainfall (mm)</label>
            <input type="number" className="input" value={rainfall} onChange={(e) => setRainfall(parseFloat(e.target.value) || 0)} min={0} step={10} />
          </div>
          <button className="btn btn-primary" onClick={handleRun} disabled={!selectedArea || running}>
            {running ? 'Running...' : <><Play className="w-4 h-4 inline mr-1" /> Run Scenario</>}
          </button>
        </div>
        <div className="mt-3">
          <label className="text-xs text-gray-500">Scenario Name</label>
          <input className="input" value={scenarioName} onChange={(e) => setScenarioName(e.target.value)} />
        </div>
      </div>

      {result && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="stat-card"><p className="text-xs text-gray-500">Rainfall</p><p className="text-xl font-bold text-blue-600">{result.scenario_rainfall_mm} mm</p></div>
            <div className="stat-card"><p className="text-xs text-gray-500">Low</p><p className="text-xl font-bold text-green-600">{result.result?.risk_distribution?.Low || 0}</p></div>
            <div className="stat-card"><p className="text-xs text-gray-500">High</p><p className="text-xl font-bold text-orange-600">{result.result?.risk_distribution?.High || 0}</p></div>
            <div className="stat-card"><p className="text-xs text-gray-500">Very High</p><p className="text-xl font-bold text-red-600">{result.result?.risk_distribution?.['Very High'] || 0}</p></div>
          </div>

          {result.result?.changed_areas && Object.keys(result.result.changed_areas).length > 0 && (
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Risk Category Changes</h3>
              <table className="w-full text-sm">
                <thead><tr className="border-b border-gray-200">
                  <th className="text-left py-2 text-xs text-gray-500">Change</th>
                  <th className="text-left py-2 text-xs text-gray-500">Pixels Affected</th>
                </tr></thead>
                <tbody>
                  {Object.entries(result.result.changed_areas).filter(([k]) => k !== 'total_changed').map(([change, count]) => (
                    <tr key={change} className="border-b border-gray-100">
                      <td className="py-2">{change}</td>
                      <td className="py-2 font-medium">{count as number}</td>
                    </tr>
                  ))}
                  <tr className="bg-gray-50">
                    <td className="py-2 font-medium">Total Changed</td>
                    <td className="py-2 font-bold">{result.result.changed_areas.total_changed}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {scenarios.length > 0 && (
        <div className="card mt-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Scenario History</h3>
          <table className="w-full text-sm">
            <thead><tr className="border-b border-gray-200">
              <th className="text-left py-2 text-xs text-gray-500">Name</th>
              <th className="text-left py-2 text-xs text-gray-500">Rainfall</th>
              <th className="text-left py-2 text-xs text-gray-500">Status</th>
              <th className="text-left py-2 text-xs text-gray-500">Date</th>
            </tr></thead>
            <tbody>
              {scenarios.map((s) => (
                <tr key={s.id} className="border-b border-gray-100">
                  <td className="py-2">{s.name}</td>
                  <td className="py-2">{s.scenario_rainfall_mm} mm</td>
                  <td className="py-2"><span className={`badge ${s.status === 'completed' ? 'badge-green' : 'badge-yellow'}`}>{s.status}</span></td>
                  <td className="py-2 text-gray-500">{new Date(s.created_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
