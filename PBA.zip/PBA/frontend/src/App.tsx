import { BrowserRouter, Routes, Route } from 'react-router-dom'
import MainLayout from './layouts/MainLayout'
import Overview from './pages/Overview'
import StudyAreas from './pages/StudyAreas'
import Datasets from './pages/Datasets'
import SatelliteAnalysis from './pages/SatelliteAnalysis'
import TerrainAnalysis from './pages/TerrainAnalysis'
import RainfallAnalysis from './pages/RainfallAnalysis'
import LULCClassification from './pages/LULCClassification'
import DrainageAnalysis from './pages/DrainageAnalysis'
import FloodRiskAssessment from './pages/FloodRiskAssessment'
import MachineLearning from './pages/MachineLearning'
import ScenarioAnalysis from './pages/ScenarioAnalysis'
import GISMapExplorer from './pages/GISMapExplorer'
import Reports from './pages/Reports'
import Settings from './pages/Settings'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Overview />} />
          <Route path="study-areas" element={<StudyAreas />} />
          <Route path="datasets" element={<Datasets />} />
          <Route path="satellite" element={<SatelliteAnalysis />} />
          <Route path="terrain" element={<TerrainAnalysis />} />
          <Route path="rainfall" element={<RainfallAnalysis />} />
          <Route path="lulc" element={<LULCClassification />} />
          <Route path="drainage" element={<DrainageAnalysis />} />
          <Route path="flood-risk" element={<FloodRiskAssessment />} />
          <Route path="machine-learning" element={<MachineLearning />} />
          <Route path="scenarios" element={<ScenarioAnalysis />} />
          <Route path="gis-map" element={<GISMapExplorer />} />
          <Route path="reports" element={<Reports />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
