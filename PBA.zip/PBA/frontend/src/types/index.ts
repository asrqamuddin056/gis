// API Types

export interface StudyArea {
  id: string
  name: string
  description: string
  boundary_geojson: string
  bbox_min_lon: number
  bbox_min_lat: number
  bbox_max_lon: number
  bbox_max_lat: number
  area_km2: number
  analysis_crs: string
  location_label: string
  created_at: string
  updated_at: string
}

export interface Dataset {
  id: string
  name: string
  description: string
  data_type: string
  source: string
  file_path: string
  original_filename: string
  file_size_bytes: number
  crs: string
  spatial_resolution: number
  coverage_area: string
  processing_status: string
  validation_status: string
  validation_errors: string
  study_area_id: string | null
  is_sample_data: boolean
  uploaded_at: string
  processed_at: string | null
}

export interface DashboardStats {
  total_study_areas: number
  total_datasets: number
  total_assessments: number
  high_risk_zones: number
  very_high_risk_zones: number
  high_risk_percentage: number
  latest_assessment_date: string | null
  datasets_processed: number
  risk_distribution: Record<string, number>
  area_analysed_km2: number
  ml_models_trained: number
  model_metrics: Record<string, number | string>
}

export interface RiskAssessment {
  id: string
  study_area_id: string
  name: string
  description: string
  method: string
  weights: Record<string, number>
  thresholds: Record<string, number>
  risk_raster_path: string
  risk_vector_path: string
  statistics: Record<string, any>
  area_by_category: Record<string, number>
  status: string
  created_at: string
  completed_at: string | null
}

export interface MLModel {
  id: string
  study_area_id: string | null
  name: string
  algorithm: string
  hyperparameters: Record<string, any>
  features: Record<string, any>
  model_path: string
  n_samples: number
  n_features: number
  feature_importance: Record<string, number>
  status: string
  created_at: string
  trained_at: string | null
}

export interface ModelEvaluation {
  id: string
  model_id: string
  accuracy: number
  precision: number
  recall: number
  f1_score: number
  roc_auc: number
  confusion_matrix: Record<string, any>
  classification_report: Record<string, any>
  validation_strategy: string
  created_at: string
}

export interface ScenarioAnalysis {
  id: string
  study_area_id: string
  name: string
  description: string
  scenario_rainfall_mm: number
  baseline_assessment_id: string | null
  scenario_raster_path: string
  difference_raster_path: string
  statistics: Record<string, any>
  changed_areas: Record<string, any>
  status: string
  created_at: string
  completed_at: string | null
}

export interface CitySearchResult {
  name: string
  country: string
  lat: number
  lon: number
  bbox: number[] | null
}
