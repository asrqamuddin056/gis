import axios from 'axios'

const api = axios.create({
  baseURL: '/api/v1',
  timeout: 120000,
})

// ---- Dashboard ----
export const dashboardApi = {
  getStats: () => api.get('/stats'),
  health: () => api.get('/health'),
}

// ---- Study Areas ----
export const studyAreaApi = {
  list: () => api.get('/study-areas/'),
  get: (id: string) => api.get(`/study-areas/${id}`),
  create: (data: any) => api.post('/study-areas/', data),
  update: (id: string, data: any) => api.put(`/study-areas/${id}`, data),
  delete: (id: string) => api.delete(`/study-areas/${id}`),
  searchCity: (query: string) => api.post(`/study-areas/search-city?query=${encodeURIComponent(query)}`),
  createHyderabadSample: () => api.post('/study-areas/create-hyderabad-sample'),
}

// ---- Datasets ----
export const datasetApi = {
  list: (studyAreaId?: string, dataType?: string) =>
    api.get('/datasets/', { params: { study_area_id: studyAreaId, data_type: dataType } }),
  get: (id: string) => api.get(`/datasets/${id}`),
  upload: (formData: FormData) =>
    api.post('/datasets/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  validate: (id: string) => api.get(`/datasets/${id}/validate`),
  delete: (id: string) => api.delete(`/datasets/${id}`),
  stats: () => api.get('/datasets/stats'),
  generateSampleData: (studyAreaId?: string) =>
    api.post('/datasets/generate-sample-data', `study_area_id=${studyAreaId || ''}`, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    }),
  download: (id: string) => api.get(`/datasets/${id}/download`, { responseType: 'blob' }),
}

// ---- Terrain ----
export const terrainApi = {
  analyze: (datasetId: string) => api.post(`/terrain/${datasetId}/analyze`),
  elevationDistribution: (datasetId: string) => api.get(`/terrain/${datasetId}/elevation-distribution`),
  pointQuery: (lon: number, lat: number, demPath?: string, slopePath?: string) =>
    api.get('/terrain/point-query', { params: { lon, lat, dem_path: demPath, slope_path: slopePath } }),
}

// ---- LULC ----
export const lulcApi = {
  analyze: (datasetId: string) => api.post(`/lulc/${datasetId}/analyze`),
  classes: () => api.get('/lulc/classes'),
  calculateNdvi: (formData: FormData) =>
    api.post('/lulc/calculate-ndvi', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  calculateNdwi: (formData: FormData) =>
    api.post('/lulc/calculate-ndwi', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
}

// ---- Rainfall ----
export const rainfallApi = {
  analyze: (datasetId: string) => api.post(`/rainfall/${datasetId}/analyze`),
  intensity: (mm: number) => api.get(`/rainfall/intensity/${mm}`),
}

// ---- Drainage ----
export const drainageApi = {
  analyze: (datasetId: string, refRasterId?: string) =>
    api.post(`/drainage/${datasetId}/analyze`, null, { params: { ref_raster_dataset_id: refRasterId } }),
}

// ---- Overlay ----
export const overlayApi = {
  defaultWeights: () => api.get('/overlay/default-weights'),
  getWeights: (studyAreaId: string) => api.get(`/overlay/weights/${studyAreaId}`),
  setWeight: (data: any, studyAreaId?: string) =>
    api.post('/overlay/weights', data, { params: { study_area_id: studyAreaId } }),
  run: (data: any) => api.post('/overlay/run', data),
  listAssessments: (studyAreaId?: string) =>
    api.get('/overlay/assessments', { params: { study_area_id: studyAreaId } }),
  getAssessment: (id: string) => api.get(`/overlay/assessments/${id}`),
}

// ---- ML ----
export const mlApi = {
  train: (data: any) => api.post('/ml/train', data),
  listModels: (studyAreaId?: string) => api.get('/ml/models', { params: { study_area_id: studyAreaId } }),
  getModel: (id: string) => api.get(`/ml/models/${id}`),
  getEvaluation: (modelId: string) => api.get(`/ml/models/${modelId}/evaluation`),
  predict: (modelId: string, features: any) => api.post(`/ml/models/${modelId}/predict`, features),
}

// ---- Scenarios ----
export const scenarioApi = {
  run: (data: any) => api.post('/scenarios/run', data),
  list: (studyAreaId?: string) => api.get('/scenarios/', { params: { study_area_id: studyAreaId } }),
  get: (id: string) => api.get(`/scenarios/${id}`),
}

// ---- Satellite ----
export const satelliteApi = {
  info: () => api.get('/satellite/info'),
  process: (formData: FormData) =>
    api.post('/satellite/process', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
}

// ---- Reports ----
export const reportApi = {
  generatePdf: (assessmentId: string, includeMl?: boolean) =>
    api.post(`/reports/${assessmentId}/pdf`, null, { params: { include_ml: includeMl }, responseType: 'blob' }),
  exportCsv: (assessmentId: string) =>
    api.post(`/reports/${assessmentId}/csv`, null, { responseType: 'blob' }),
  exportJson: (assessmentId: string) =>
    api.post(`/reports/${assessmentId}/json`, null, { responseType: 'blob' }),
}

export default api
