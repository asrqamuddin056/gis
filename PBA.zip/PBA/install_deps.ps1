$py = "C:\Users\ARQAM\AppData\Local\Programs\Python\Python312\python.exe"
$log = "d:\PBA\backend\pip_install.log"

"=== Installing core web packages ===" | Out-File $log
& $py -m pip install fastapi uvicorn python-multipart pydantic pydantic-settings python-dotenv SQLAlchemy aiosqlite 2>&1 | Out-File $log -Append

"=== Installing numpy/scipy/pandas ===" | Out-File $log -Append
& $py -m pip install numpy scipy pandas 2>&1 | Out-File $log -Append

"=== Installing geospatial packages ===" | Out-File $log -Append
& $py -m pip install shapely pyproj geopandas rasterio 2>&1 | Out-File $log -Append

"=== Installing ML packages ===" | Out-File $log -Append
& $py -m pip install scikit-learn xgboost 2>&1 | Out-File $log -Append

"=== Installing reporting packages ===" | Out-File $log -Append
& $py -m pip install reportlab matplotlib 2>&1 | Out-File $log -Append

"=== Installing test packages ===" | Out-File $log -Append
& $py -m pip install httpx pytest pytest-asyncio 2>&1 | Out-File $log -Append

"=== ALL DONE ===" | Out-File $log -Append
