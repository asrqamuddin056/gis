$py = "C:\Users\ARQAM\AppData\Local\Programs\Python\Python312\python.exe"
$log = "d:\PBA\backend\pip_batch2.log"
$pkgs = @("pandas","scipy","shapely","pyproj","geopandas","rasterio","scikit-learn","xgboost","httpx")
foreach($p in $pkgs) {
    "Installing $p ..." | Out-File $log -Append
    & $py -m pip install $p --timeout 180 --retries 10 2>&1 | Out-File $log -Append
    "=== $p DONE ===" | Out-File $log -Append
}
"BATCH2_DONE" | Out-File $log -Append
