$log = "d:\PBA\verify_all.txt"
$r = @()
$py = "C:\Users\ARQAM\AppData\Local\Programs\Python\Python312\python.exe"
$r += "=== PYTHON ==="
$r += "version: $(& $py --version 2>&1)"
$r += "pip: $(& $py -m pip --version 2>&1)"

$r += ""
$r += "=== NODE ==="
$nodePaths = @("C:\Program Files\nodejs\node.exe", "$env:LOCALAPPDATA\Programs\nodejs\node.exe", "$env:PROGRAMFILES\nodejs\node.exe")
$nodeFound = $false
foreach($p in $nodePaths) {
    if(Test-Path $p) {
        $r += "node at: $p"
        $r += "node version: $(& $p --version 2>&1)"
        $nodeFound = $true
        break
    }
}
if(-not $nodeFound) { $r += "node NOT at standard paths, checking Get-Command after PATH refresh..." }

# Refresh PATH from registry
$env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
$nc = Get-Command node -ErrorAction SilentlyContinue
if($nc) { $r += "node on PATH: $($nc.Source)" } else { $r += "node NOT on refreshed PATH" }
$nmc = Get-Command npm -ErrorAction SilentlyContinue
if($nmc) { $r += "npm on PATH: $($nmc.Source)" } else { $r += "npm NOT on refreshed PATH" }

$r += ""
$r += "=== GIT ==="
$r += "git: $(git --version 2>&1)"

$r | Out-File $log -Encoding UTF8
"FINISHED" | Out-File $log -Append -Encoding UTF8
