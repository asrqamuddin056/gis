"""Entry point script to start the FastAPI backend server.

Usage:
    python run.py

The server starts on http://localhost:8000
API docs available at http://localhost:8000/docs
"""

import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
