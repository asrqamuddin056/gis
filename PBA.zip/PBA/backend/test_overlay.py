"""Re-test overlay after weight validation fix."""
import httpx
import json
import asyncio

BASE = "http://localhost:8000"
results = []

async def test():
    async with httpx.AsyncClient(base_url=BASE, timeout=120) as c:
        # Get study area
        r = await c.get("/api/v1/study-areas/")
        areas = r.json()
        if not areas:
            results.append("No study areas found — creating one")
            r = await c.post("/api/v1/study-areas/create-hyderabad-sample")
            areas = (await c.get("/api/v1/study-areas/")).json()

        area_id = areas[0]["id"]
        results.append(f"Study area: {areas[0]['name']} ({area_id})")

        # Check datasets exist
        r = await c.get(f"/api/v1/datasets/?study_area_id={area_id}")
        datasets = r.json()
        results.append(f"Datasets: {len(datasets)}")

        # Generate sample data if none
        if len(datasets) < 8:
            r = await c.post("/api/v1/datasets/generate-sample-data", data={"study_area_id": area_id})
            results.append(f"Generated sample data: {r.json().get('message', '')}")
            datasets = (await c.get(f"/api/v1/datasets/?study_area_id={area_id}")).json()
            results.append(f"Datasets now: {len(datasets)}")

        # List dataset names to see which layers are available
        for ds in datasets:
            results.append(f"  {ds['name']} ({ds['data_type']}) valid={ds['validation_status']}")

        # Run overlay
        overlay_req = {
            "study_area_id": area_id,
            "name": "Test Assessment",
            "weights": {
                "rainfall": 0.25,
                "elevation": 0.20,
                "drainage_proximity": 0.20,
                "slope": 0.15,
                "lulc": 0.15,
                "built_up": 0.05,
            },
            "thresholds": {"low": 2.0, "medium": 3.0, "high": 4.0, "very_high": 5.0},
        }
        r = await c.post("/api/v1/overlay/run", json=overlay_req, timeout=120)
        results.append(f"Overlay run: {r.status_code}")
        if r.status_code == 200:
            result = r.json()
            results.append(f"  status: {result.get('status')}")
            res = result.get("result", {})
            results.append(f"  risk_distribution: {res.get('risk_distribution')}")
            results.append(f"  high_risk_pct: {res.get('high_risk_percentage')}%")
            results.append(f"  area_by_category: {res.get('area_by_category')}")
            results.append(f"  layers_used: {res.get('layers_used')}")
            results.append(f"  weights_used: {res.get('weights_used')}")
            assessment_id = result.get("assessment_id", "")

            # Check dashboard stats now have data
            r2 = await c.get("/api/v1/stats")
            stats = r2.json()
            results.append(f"Dashboard stats after overlay:")
            results.append(f"  total_assessments: {stats['total_assessments']}")
            results.append(f"  high_risk_zones: {stats['high_risk_zones']}")
            results.append(f"  very_high_risk_zones: {stats['very_high_risk_zones']}")
            results.append(f"  high_risk_percentage: {stats['high_risk_percentage']}%")
            results.append(f"  risk_distribution: {stats['risk_distribution']}")
            results.append(f"  datasets_processed: {stats['datasets_processed']}")

            # Test PDF report generation
            r3 = await c.post(f"/api/v1/reports/{assessment_id}/pdf", params={"include_ml": False}, timeout=60)
            results.append(f"PDF report: {r3.status_code}")

            # Test CSV export
            r4 = await c.post(f"/api/v1/reports/{assessment_id}/csv")
            results.append(f"CSV export: {r4.status_code}")

            # Test JSON export
            r5 = await c.post(f"/api/v1/reports/{assessment_id}/json")
            results.append(f"JSON export: {r5.status_code}")
        else:
            results.append(f"  error: {r.text[:500]}")

    with open("overlay_test_results.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(results))
    print("DONE")

asyncio.run(test())
