"""Quick test to verify all backend imports work."""
import sys
import os
import io

# Redirect output to a string
output = io.StringIO()
orig_print = print
def print(*args, **kwargs):
    output.write(" ".join(str(a) for a in args) + "\n")

# Ensure we're in the backend directory
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.getcwd())

print("Testing imports...")
try:
    from app.core.config import settings
    print(f"  OK: config - {settings.APP_NAME}")
except Exception as e:
    print(f"  FAIL: config - {e}")

try:
    from app.database.connection import Base, engine, init_db
    print("  OK: database connection")
except Exception as e:
    print(f"  FAIL: database - {e}")

try:
    from app.models.study_area import StudyArea
    from app.models.dataset import Dataset
    from app.models.assessment import RiskAssessment
    from app.models.ml_model import MLModel, ModelEvaluation
    from app.models.processing_job import ProcessingJob
    print("  OK: all models")
except Exception as e:
    print(f"  FAIL: models - {e}")

try:
    from app.schemas.study_area import StudyAreaCreate
    from app.schemas.dataset import DatasetCreate
    from app.schemas.assessment import WeightedOverlayRequest
    from app.schemas.ml import MLTrainingRequest
    print("  OK: all schemas")
except Exception as e:
    print(f"  FAIL: schemas - {e}")

try:
    import rasterio
    print(f"  OK: rasterio {rasterio.__version__}")
except Exception as e:
    print(f"  FAIL: rasterio - {e}")

try:
    import geopandas
    print(f"  OK: geopandas {geopandas.__version__}")
except Exception as e:
    print(f"  FAIL: geopandas - {e}")

try:
    import numpy as np
    print(f"  OK: numpy {np.__version__}")
except Exception as e:
    print(f"  FAIL: numpy - {e}")

try:
    import sklearn
    print(f"  OK: scikit-learn {sklearn.__version__}")
except Exception as e:
    print(f"  FAIL: scikit-learn - {e}")

try:
    import xgboost
    print(f"  OK: xgboost {xgboost.__version__}")
except Exception as e:
    print(f"  FAIL: xgboost - {e}")

try:
    from app.geospatial.raster_processing import has_rasterio
    print(f"  OK: geospatial.raster_processing (rasterio={has_rasterio()})")
except Exception as e:
    print(f"  FAIL: geospatial.raster_processing - {e}")

try:
    from app.geospatial.spatial_analysis import calculate_slope, weighted_overlay, classify_risk
    print("  OK: geospatial.spatial_analysis")
except Exception as e:
    print(f"  FAIL: geospatial.spatial_analysis - {e}")

try:
    from app.services.overlay_service import run_weighted_overlay
    print("  OK: services.overlay_service")
except Exception as e:
    print(f"  FAIL: services.overlay_service - {e}")

try:
    from app.services.ml_service import train_model
    print("  OK: services.ml_service")
except Exception as e:
    print(f"  FAIL: services.ml_service - {e}")

try:
    from app.services.report_service import generate_pdf_report
    print("  OK: services.report_service")
except Exception as e:
    print(f"  FAIL: services.report_service - {e}")

try:
    from app.utils.sample_data import generate_all_sample_data
    print("  OK: utils.sample_data")
except Exception as e:
    print(f"  FAIL: utils.sample_data - {e}")

try:
    from app.main import app
    print(f"  OK: main app - routes: {len(app.routes)}")
except Exception as e:
    print(f"  FAIL: main app - {e}")

print("\nImport test complete.")

# Write all output to file
with open("import_test_results.txt", "w", encoding="utf-8") as f:
    f.write(output.getvalue())
# Write a marker file to confirm completion
with open("import_test_done.txt", "w") as f:
    f.write("done")
