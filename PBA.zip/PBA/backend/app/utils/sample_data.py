"""Sample data generator for demonstration mode.

Creates synthetic but realistic geospatial datasets for the Hyderabad
demonstration region so the system is fully functional without downloading
gigabytes of real data.

All sample data is clearly labelled as SAMPLE DATA.

Generated datasets:
  - DEM (GeoTIFF) with realistic elevation gradient
  - Slope raster (derived from DEM)
  - Rainfall data (CSV + raster)
  - LULC raster (land use / land cover classification)
  - Drainage network (GeoJSON)
  - Built-up density raster
  - Historical flood occurrence points (CSV with coordinates + labels)
  - Study area boundary (GeoJSON polygon)
"""

import json
import math
import csv
import os
from pathlib import Path
from typing import Dict, Tuple
import numpy as np


# Hyderabad bounding box (approximately)
HYDERABAD_BBOX = {
    "min_lon": 78.25,
    "min_lat": 17.20,
    "max_lon": 78.75,
    "max_lat": 17.65,
    "centre_lon": 78.4867,
    "centre_lat": 17.3850,
    "name": "Hyderabad, Telangana, India",
}

# Default raster grid size for sample data (small for laptop performance)
GRID_WIDTH = 200
GRID_HEIGHT = 200


def _generate_elevation(shape: Tuple[int, int], bbox: Dict) -> np.ndarray:
    """Generate a realistic-looking DEM for the Hyderabad area.

    Hyderabad elevation ranges roughly 400–600m with hills in the south
    and lower areas near the Musi river and water bodies.
    """
    h, w = shape
    # Base elevation gradient — higher in the south, lower in centre/north
    y = np.linspace(0, 1, h)
    x = np.linspace(0, 1, w)
    xx, yy = np.meshgrid(x, y)

    # Base elevation: 450-600m range
    base = 450 + 150 * (1 - yy)

    # Add some hills (Golconda area in southwest)
    hill1 = 80 * np.exp(-((xx - 0.25)**2 + (yy - 0.75)**2) / 0.05)
    hill2 = 60 * np.exp(-((xx - 0.70)**2 + (yy - 0.30)**2) / 0.03)

    # Low-lying areas (Musi river corridor — east-west through centre)
    river = -40 * np.exp(-((yy - 0.45)**2) / 0.005)

    # Water bodies (Hussain Sagar lake area)
    lake = -30 * np.exp(-((xx - 0.50)**2 + (yy - 0.48)**2) / 0.003)

    # Random terrain variation
    rng = np.random.default_rng(42)
    noise = rng.normal(0, 10, shape)

    elevation = base + hill1 + hill2 + river + lake + noise
    elevation = np.clip(elevation, 380, 650)
    elevation = elevation.astype(np.float32)

    return elevation


def _generate_rainfall(shape: Tuple[int, int], bbox: Dict) -> np.ndarray:
    """Generate synthetic rainfall distribution (mm) for monsoon conditions."""
    h, w = shape
    y = np.linspace(0, 1, h)
    x = np.linspace(0, 1, w)
    xx, yy = np.meshgrid(x, y)

    # Base rainfall: 80-180mm with higher values in certain areas
    base = 80 + 100 * (1 - xx)  # higher in west

    # Rainfall concentration bands
    band1 = 30 * np.exp(-((yy - 0.3)**2) / 0.05)
    band2 = 40 * np.exp(-((xx - 0.3)**2 + (yy - 0.6)**2) / 0.04)

    rng = np.random.default_rng(123)
    noise = rng.normal(0, 15, shape)

    rainfall = base + band1 + band2 + noise
    rainfall = np.clip(rainfall, 20, 250)
    return rainfall.astype(np.float32)


def _generate_lulc(shape: Tuple[int, int], bbox: Dict) -> np.ndarray:
    """Generate LULC classification raster.

    Classes:
      1 = Water bodies
      2 = Vegetation
      3 = Built-up areas
      4 = Agricultural land
      5 = Bare soil
    """
    h, w = shape
    y = np.linspace(0, 1, h)
    x = np.linspace(0, 1, w)
    xx, yy = np.meshgrid(x, y)

    lulc = np.ones(shape, dtype=np.int16) * 4  # Default: agricultural

    # Water bodies (Hussain Sagar + other water bodies)
    water = ((xx - 0.50)**2 + (yy - 0.48)**2) < 0.003
    water2 = ((xx - 0.15)**2 + (yy - 0.60)**2) < 0.002
    water3 = ((xx - 0.80)**2 + (yy - 0.35)**2) < 0.002
    lulc[water | water2 | water3] = 1

    # Built-up areas (concentrated in centre)
    builtup = ((xx - 0.50)**2 + (yy - 0.48)**2) < 0.08
    builtup = builtup | (((xx - 0.35)**2 + (yy - 0.55)**2) < 0.03)
    builtup = builtup | (((xx - 0.65)**2 + (yy - 0.40)**2) < 0.03)
    lulc[builtup] = 3

    # Vegetation (parks, green areas)
    veg = ((xx - 0.20)**2 + (yy - 0.30)**2) < 0.02
    veg = veg | (((xx - 0.70)**2 + (yy - 0.65)**2) < 0.015)
    veg = veg & ~builtup
    lulc[veg] = 2

    # Bare soil (outskirts)
    bare = (xx < 0.1) | (xx > 0.9) | (yy < 0.1) | (yy > 0.9)
    bare = bare & ~water & ~builtup
    lulc[bare] = 5

    # Add some scattered vegetation in agricultural areas
    rng = np.random.default_rng(456)
    random_veg = rng.random(shape) < 0.15
    random_veg = random_veg & (lulc == 4) & ~builtup & ~water
    lulc[random_veg] = 2

    return lulc


def _generate_built_up(shape: Tuple[int, int]) -> np.ndarray:
    """Generate built-up density (0–1)."""
    h, w = shape
    y = np.linspace(0, 1, h)
    x = np.linspace(0, 1, w)
    xx, yy = np.meshgrid(x, y)

    # High density in centre, decreasing outward
    density = np.exp(-((xx - 0.50)**2 + (yy - 0.48)**2) / 0.08)

    # Secondary clusters
    density += 0.5 * np.exp(-((xx - 0.35)**2 + (yy - 0.55)**2) / 0.02)
    density += 0.5 * np.exp(-((xx - 0.65)**2 + (yy - 0.40)**2) / 0.02)

    rng = np.random.default_rng(789)
    noise = rng.normal(0, 0.05, shape)
    density = np.clip(density + noise, 0, 1)
    return density.astype(np.float32)


def _generate_drainage_geojson(bbox: Dict) -> Dict:
    """Generate a drainage network GeoJSON (rivers + water bodies)."""
    features = []

    # Musi River (east-west through centre)
    river_coords = [
        [78.27, 17.46], [78.32, 17.45], [78.37, 17.44], [78.42, 17.43],
        [78.47, 17.44], [78.52, 17.42], [78.57, 17.41], [78.62, 17.40],
        [78.67, 17.39], [78.72, 17.38]
    ]
    features.append({
        "type": "Feature",
        "properties": {"name": "Musi River", "type": "river", "id": "river_1"},
        "geometry": {"type": "LineString", "coordinates": river_coords}
    })

    # Tributary 1
    trib1 = [
        [78.40, 17.60], [78.43, 17.55], [78.45, 17.50], [78.47, 17.44]
    ]
    features.append({
        "type": "Feature",
        "properties": {"name": "Tributary 1", "type": "river", "id": "river_2"},
        "geometry": {"type": "LineString", "coordinates": trib1}
    })

    # Tributary 2
    trib2 = [
        [78.55, 17.60], [78.53, 17.55], [78.50, 17.48], [78.47, 17.44]
    ]
    features.append({
        "type": "Feature",
        "properties": {"name": "Tributary 2", "type": "river", "id": "river_3"},
        "geometry": {"type": "LineString", "coordinates": trib2}
    })

    # Hussain Sagar Lake
    lake_coords = [
        [78.46, 17.43], [78.47, 17.425], [78.48, 17.42], [78.49, 17.425],
        [78.495, 17.43], [78.49, 17.435], [78.48, 17.44], [78.47, 17.44]
    ]
    features.append({
        "type": "Feature",
        "properties": {"name": "Hussain Sagar", "type": "lake", "id": "lake_1"},
        "geometry": {"type": "Polygon", "coordinates": [lake_coords]}
    })

    # Small lake
    lake2_coords = [
        [78.32, 17.58], [78.33, 17.575], [78.34, 17.58], [78.33, 17.585]
    ]
    features.append({
        "type": "Feature",
        "properties": {"name": "Saroornagar Lake", "type": "lake", "id": "lake_2"},
        "geometry": {"type": "Polygon", "coordinates": [lake2_coords]}
    })

    return {"type": "FeatureCollection", "features": features}


def _generate_study_area_boundary(bbox: Dict) -> Dict:
    """Generate study area boundary GeoJSON polygon."""
    coords = [
        [bbox["min_lon"], bbox["min_lat"]],
        [bbox["max_lon"], bbox["min_lat"]],
        [bbox["max_lon"], bbox["max_lat"]],
        [bbox["min_lon"], bbox["max_lat"]],
        [bbox["min_lon"], bbox["min_lat"]],
    ]
    return {
        "type": "Feature",
        "properties": {"name": bbox["name"]},
        "geometry": {"type": "Polygon", "coordinates": [coords]}
    }


def _generate_flood_points(
    bbox: Dict, n_points: int = 200
) -> list:
    """Generate historical flood occurrence points with labels.

    Points near rivers and low-elevation areas are more likely to be
    labelled as flood=1 (historically flooded).

    Returns list of dicts: {lat, lon, elevation, flood_label, rainfall_mm, distance_to_river_m}
    """
    rng = np.random.default_rng(999)

    # River line approximation for distance calc
    river_lons = np.array([78.27, 78.32, 78.37, 78.42, 78.47, 78.52, 78.57, 78.62, 78.67, 78.72])
    river_lats = np.array([17.46, 17.45, 17.44, 17.43, 17.44, 17.42, 17.41, 17.40, 17.39, 17.38])

    points = []
    for _ in range(n_points):
        lon = rng.uniform(bbox["min_lon"], bbox["max_lon"])
        lat = rng.uniform(bbox["min_lat"], bbox["max_lat"])

        # Approximate distance to river (nearest point on river line)
        dists = np.sqrt((river_lons - lon)**2 + (river_lats - lat)**2)
        min_dist_deg = dists.min()
        distance_to_river_m = min_dist_deg * 111000  # approx metres

        # Approximate elevation (lower near river)
        # Use same logic as DEM: south is higher, river is in centre
        y_frac = (lat - bbox["min_lat"]) / (bbox["max_lat"] - bbox["min_lat"])
        x_frac = (lon - bbox["min_lon"]) / (bbox["max_lon"] - bbox["min_lon"])
        elevation = 450 + 150 * (1 - y_frac)
        # River depression
        river_dist_lat = abs(y_frac - 0.45)
        elevation -= 40 * np.exp(-(river_dist_lat**2) / 0.005)
        elevation += rng.normal(0, 10)

        # Rainfall
        rainfall = 80 + 100 * (1 - x_frac) + rng.normal(0, 15)
        rainfall = max(20, min(250, rainfall))

        # Flood label: more likely if low elevation, close to river, high rainfall
        flood_prob = 0.15  # base probability
        if elevation < 480:
            flood_prob += 0.25
        if distance_to_river_m < 2000:
            flood_prob += 0.30
        if rainfall > 130:
            flood_prob += 0.15

        flood_label = 1 if rng.random() < min(flood_prob, 0.85) else 0

        points.append({
            "lat": round(lat, 6),
            "lon": round(lon, 6),
            "elevation": round(float(elevation), 2),
            "slope": round(float(rng.uniform(0, 15)), 2),
            "rainfall_mm": round(float(rainfall), 2),
            "distance_to_river_m": round(float(distance_to_river_m), 1),
            "built_up_density": round(float(rng.uniform(0, 1)), 3),
            "lulc_class": int(rng.choice([1, 2, 3, 4, 5], p=[0.05, 0.15, 0.45, 0.25, 0.10])),
            "flood_label": flood_label,
        })

    return points


def generate_all_sample_data(output_dir: str) -> Dict[str, str]:
    """Generate all sample datasets and return a dict of file paths.

    This creates the complete set of sample data needed to demonstrate
    the system end-to-end.

    Args:
        output_dir: base directory for sample data

    Returns:
        Dict of {dataset_type: file_path}
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    shape = (GRID_HEIGHT, GRID_WIDTH)
    bbox = HYDERABAD_BBOX

    # Resolution in degrees
    res_lon = (bbox["max_lon"] - bbox["min_lon"]) / GRID_WIDTH
    res_lat = (bbox["max_lat"] - bbox["min_lat"]) / GRID_HEIGHT

    # --- DEM ---
    elevation = _generate_elevation(shape, bbox)
    dem_path = str(out / "dem_sample.tif")

    # --- Rainfall ---
    rainfall = _generate_rainfall(shape, bbox)
    rainfall_path = str(out / "rainfall_sample.tif")

    # --- LULC ---
    lulc = _generate_lulc(shape, bbox)
    lulc_path = str(out / "lulc_sample.tif")

    # --- Built-up density ---
    built_up = _generate_built_up(shape)
    built_up_path = str(out / "built_up_sample.tif")

    # Write rasters (using rasterio if available, otherwise numpy .npy)
    try:
        import rasterio
        from rasterio.transform import from_origin

        def _write_tif(path, data, dtype, nodata=None):
            transform = from_origin(bbox["min_lon"], bbox["max_lat"], res_lon, res_lat)
            with rasterio.open(
                path, "w", driver="GTiff",
                height=data.shape[0], width=data.shape[1],
                count=1, dtype=dtype, crs="EPSG:4326",
                transform=transform, nodata=nodata,
            ) as dst:
                dst.write(data.astype(dtype), 1)

        _write_tif(dem_path, elevation, "float32")
        _write_tif(rainfall_path, rainfall, "float32")
        _write_tif(lulc_path, lulc, "int16")
        _write_tif(built_up_path, built_up, "float32")

    except ImportError:
        # Fallback: save as numpy arrays
        np.save(str(out / "dem_sample.npy"), elevation)
        np.save(str(out / "rainfall_sample.npy"), rainfall)
        np.save(str(out / "lulc_sample.npy"), lulc)
        np.save(str(out / "built_up_sample.npy"), built_up)
        dem_path = str(out / "dem_sample.npy")
        rainfall_path = str(out / "rainfall_sample.npy")
        lulc_path = str(out / "lulc_sample.npy")
        built_up_path = str(out / "built_up_sample.npy")

    # --- Slope (derived from DEM) ---
    try:
        from app.geospatial.spatial_analysis import calculate_slope
        pixel_size_m = res_lon * 111000  # approx metres per pixel
        slope = calculate_slope(elevation, pixel_size_m)
        slope_path = str(out / "slope_sample.tif")
        try:
            import rasterio
            from rasterio.transform import from_origin
            transform = from_origin(bbox["min_lon"], bbox["max_lat"], res_lon, res_lat)
            with rasterio.open(
                slope_path, "w", driver="GTiff",
                height=slope.shape[0], width=slope.shape[1],
                count=1, dtype="float32", crs="EPSG:4326",
                transform=transform,
            ) as dst:
                dst.write(slope.astype("float32"), 1)
        except ImportError:
            np.save(str(out / "slope_sample.npy"), slope)
            slope_path = str(out / "slope_sample.npy")
    except ImportError:
        slope_path = ""

    # --- Drainage GeoJSON ---
    drainage_geojson = _generate_drainage_geojson(bbox)
    drainage_path = str(out / "drainage_sample.geojson")
    with open(drainage_path, "w", encoding="utf-8") as f:
        json.dump(drainage_geojson, f)

    # --- Study area boundary GeoJSON ---
    boundary_geojson = _generate_study_area_boundary(bbox)
    boundary_path = str(out / "study_area_boundary_sample.geojson")
    with open(boundary_path, "w", encoding="utf-8") as f:
        json.dump(boundary_geojson, f)

    # --- Rainfall CSV (time-series at weather stations) ---
    rainfall_csv_path = str(out / "rainfall_stations_sample.csv")
    rng = np.random.default_rng(42)
    stations = [
        ("Station_Central", 78.4867, 17.3850),
        ("Station_North", 78.4867, 17.60),
        ("Station_South", 78.4867, 17.25),
        ("Station_East", 78.65, 17.3850),
        ("Station_West", 78.30, 17.3850),
    ]
    months = ["Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May"]
    with open(rainfall_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["station", "lat", "lon", "month", "rainfall_mm", "year"])
        for station_name, slat, slon in stations:
            for year in [2021, 2022, 2023]:
                for i, month in enumerate(months):
                    # Monsoon months (Jun-Sep) have higher rainfall
                    base = 120 if month in ["Jun", "Jul", "Aug", "Sep"] else 25
                    rf = max(0, base + rng.normal(0, 30))
                    writer.writerow([station_name, slat, slon, month, round(rf, 1), year])

    # --- Historical flood occurrence points CSV ---
    flood_points = _generate_flood_points(bbox, n_points=200)
    flood_csv_path = str(out / "flood_occurrence_sample.csv")
    with open(flood_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "lat", "lon", "elevation", "slope", "rainfall_mm",
            "distance_to_river_m", "built_up_density", "lulc_class", "flood_label"
        ])
        writer.writeheader()
        writer.writerows(flood_points)

    # --- Satellite imagery placeholder info ---
    satellite_info_path = str(out / "satellite_info.json")
    satellite_info = {
        "source": "SAMPLE DATA — no external satellite imagery downloaded",
        "note": "This is sample data for demonstration. To use real Sentinel-2 imagery, "
                "upload GeoTIFF files through the Dataset Management interface or configure "
                "Google Earth Engine access.",
        "bbox": [bbox["min_lon"], bbox["min_lat"], bbox["max_lon"], bbox["max_lat"]],
        "bands": {
            "red": "Sample red band values (generated, not from real Sentinel-2)",
            "nir": "Sample NIR band values (generated, not from real Sentinel-2)",
            "green": "Sample green band values (generated, not from real Sentinel-2)",
        },
    }
    with open(satellite_info_path, "w", encoding="utf-8") as f:
        json.dump(satellite_info, f, indent=2)

    return {
        "dem": dem_path,
        "slope": slope_path,
        "rainfall_raster": rainfall_path,
        "rainfall_csv": rainfall_csv_path,
        "lulc": lulc_path,
        "built_up": built_up_path,
        "drainage": drainage_path,
        "study_area_boundary": boundary_path,
        "flood_occurrence": flood_csv_path,
        "satellite_info": satellite_info_path,
        "bbox": json.dumps({
            "min_lon": bbox["min_lon"],
            "min_lat": bbox["min_lat"],
            "max_lon": bbox["max_lon"],
            "max_lat": bbox["max_lat"],
            "centre_lon": bbox["centre_lon"],
            "centre_lat": bbox["centre_lat"],
            "name": bbox["name"],
        }),
    }


def get_bbox_info() -> Dict:
    """Return the Hyderabad bounding box info."""
    return HYDERABAD_BBOX.copy()


def get_lulc_class_info() -> Dict[int, str]:
    """Return LULC class code → name mapping."""
    return {
        1: "Water bodies",
        2: "Vegetation",
        3: "Built-up areas",
        4: "Agricultural land",
        5: "Bare soil",
    }


def get_lulc_risk_scores() -> Dict[int, float]:
    """Return LULC class → risk score (1–5 scale).

    Water bodies and bare soil near water have higher flood risk.
    Built-up areas have medium risk (urban runoff).
    Vegetation and agricultural land have lower risk.
    """
    return {
        1: 5.0,  # Water bodies — highest risk
        2: 2.0,  # Vegetation — low risk (infiltration)
        3: 3.5,  # Built-up — medium-high (impermeable surfaces, runoff)
        4: 2.5,  # Agricultural — low-medium
        5: 3.0,  # Bare soil — medium
    }
