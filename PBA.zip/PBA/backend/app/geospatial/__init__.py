"""Geospatial processing utilities for raster, vector, and spatial analysis."""
