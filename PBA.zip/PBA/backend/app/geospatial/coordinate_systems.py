"""Coordinate reference system helpers using pyproj.

Provides utilities for transforming between WGS84 (lon/lat) and
projected CRS (e.g. UTM) for accurate distance and area calculations.
"""

from typing import Tuple, Optional

try:
    import pyproj
    from pyproj import CRS, Transformer
    HAS_PYPROJ = True
except ImportError:
    HAS_PYPROJ = False

# WGS84 — the default for GeoJSON and most web data
WGS84_EPSG = 4326


def get_utm_zone(longitude: float) -> int:
    """Return the UTM zone number for a given longitude."""
    return int((longitude + 180) / 6) + 1


def get_utm_crs(longitude: float, latitude: float) -> str:
    """Return an EPSG code for the appropriate UTM zone.

    Uses the hemisphere to pick north vs south.
    """
    zone = get_utm_zone(longitude)
    if latitude >= 0:
        return f"326{zone:02d}"  # UTM North
    return f"327{zone:02d}"  # UTM South


def get_utm_crs_for_bbox(
    min_lon: float, min_lat: float, max_lon: float, max_lat: float
) -> str:
    """Return a UTM CRS code suitable for a bounding box.

    Uses the centre of the bbox to determine the zone.
    """
    centre_lon = (min_lon + max_lon) / 2
    centre_lat = (min_lat + max_lat) / 2
    return get_utm_crs(centre_lon, centre_lat)


def transform_point(
    lon: float, lat: float, from_epsg: int, to_epsg: int
) -> Tuple[float, float]:
    """Transform a point from one CRS to another.

    Returns (x, y) in the target CRS.
    """
    if not HAS_PYPROJ:
        if from_epsg == to_epsg:
            return lon, lat
        raise ImportError("pyproj is required for coordinate transformation")

    transformer = Transformer.from_crs(f"EPSG:{from_epsg}", f"EPSG:{to_epsg}", always_xy=True)
    x, y = transformer.transform(lon, lat)
    return x, y


def calculate_area_km2(
    min_lon: float, min_lat: float, max_lon: float, max_lat: float
) -> float:
    """Approximate the area of a bounding box in square kilometres.

    Projects to UTM first for accuracy.
    """
    if not HAS_PYPROJ:
        # Rough approximation using Haversine for the lat/lon degrees
        import math
        # 1 degree lat ~ 111 km
        lat_km = (max_lat - min_lat) * 111.0
        # 1 degree lon ~ 111 * cos(lat) km
        avg_lat = (min_lat + max_lat) / 2
        lon_km = (max_lon - min_lon) * 111.0 * math.cos(math.radians(avg_lat))
        return lat_km * lon_km

    utm_crs = get_utm_crs_for_bbox(min_lon, min_lat, max_lon, max_lat)
    transformer = Transformer.from_crs(f"EPSG:{WGS84_EPSG}", f"EPSG:{utm_crs}", always_xy=True)
    x1, y1 = transformer.transform(min_lon, min_lat)
    x2, y2 = transformer.transform(max_lon, max_lat)
    width_m = abs(x2 - x1)
    height_m = abs(y2 - y1)
    return (width_m * height_m) / 1_000_000


def get_crs_info(crs_str: str) -> dict:
    """Return human-readable info about a CRS string."""
    if not HAS_PYPROJ:
        return {"crs": crs_str, "name": crs_str}

    try:
        crs = CRS.from_string(crs_str)
        return {
            "crs": str(crs),
            "name": crs.name,
            "epsg": crs.to_epsg() if crs.is_geographic or crs.is_projected else None,
            "is_geographic": crs.is_geographic,
            "is_projected": crs.is_projected,
            "unit": str(crs.axis_info[0].unit_name) if crs.axis_info else "unknown",
        }
    except Exception:
        return {"crs": crs_str, "name": crs_str, "error": "Could not parse CRS"}
