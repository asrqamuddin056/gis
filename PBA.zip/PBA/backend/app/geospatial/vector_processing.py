"""Vector processing utilities using geopandas and shapely.

Handles loading, saving, buffering, and analysis of vector datasets
(GeoJSON, shapefiles).
"""

from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path
import json

import numpy as np

try:
    import geopandas as gpd
    from shapely.geometry import shape, mapping, Point, Polygon, LineString, MultiPolygon, MultiLineString
    from shapely.ops import unary_union, nearest_points
    HAS_VECTOR = True
except ImportError:
    HAS_VECTOR = False


def has_vector_libs() -> bool:
    return HAS_VECTOR


def load_vector(file_path: str) -> Dict[str, Any]:
    """Load a vector file (GeoJSON, shapefile, etc.) and return metadata.

    Returns dict with: gdf, crs, geometry_type, feature_count, bounds, columns
    """
    if not HAS_VECTOR:
        raise ImportError("geopandas is required to load vector files")

    gdf = gpd.read_file(file_path)
    return {
        "gdf": gdf,
        "crs": str(gdf.crs) if gdf.crs else "EPSG:4326",
        "geometry_type": str(gdf.geom_type.iloc[0]) if len(gdf) > 0 else "unknown",
        "feature_count": len(gdf),
        "bounds": list(gdf.total_bounds),  # minx, miny, maxx, maxy
        "columns": list(gdf.columns),
    }


def load_geojson(file_path: str) -> Optional[Dict]:
    """Load a GeoJSON file and return the parsed dictionary."""
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_geojson(file_path: str, geojson: Dict) -> str:
    """Save a GeoJSON dictionary to file."""
    Path(file_path).parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(geojson, f)
    return file_path


def validate_geojson(geojson: Dict) -> Tuple[bool, List[str]]:
    """Validate a GeoJSON structure. Returns (is_valid, errors)."""
    errors = []

    if not isinstance(geojson, dict):
        return False, ["Not a valid JSON object"]

    geo_type = geojson.get("type")
    if geo_type == "FeatureCollection":
        features = geojson.get("features", [])
        if not features:
            errors.append("FeatureCollection has no features")
        for i, feat in enumerate(features):
            if feat.get("type") != "Feature":
                errors.append(f"Feature {i} is not a valid Feature")
            geom = feat.get("geometry")
            if not geom or not geom.get("type") or not geom.get("coordinates"):
                errors.append(f"Feature {i} has invalid geometry")
    elif geo_type == "Feature":
        geom = geojson.get("geometry")
        if not geom:
            errors.append("Feature has no geometry")
    elif geo_type in ("Point", "LineString", "Polygon", "MultiPoint", "MultiLineString", "MultiPolygon"):
        if not geojson.get("coordinates"):
            errors.append("Geometry has no coordinates")
    else:
        errors.append(f"Unknown GeoJSON type: {geo_type}")

    return len(errors) == 0, errors


def buffer_geometries(
    gdf: "gpd.GeoDataFrame", distance_m: float, target_crs: str = "EPSG:32644"
) -> "gpd.GeoDataFrame":
    """Buffer geometries by a given distance in metres.

    Reprojects to a projected CRS for accurate buffering, then back.
    """
    if not HAS_VECTOR:
        raise ImportError("geopandas is required for buffering")

    original_crs = gdf.crs
    if str(original_crs) != target_crs:
        gdf = gdf.to_crs(target_crs)

    buffered = gdf.copy()
    buffered.geometry = gdf.geometry.buffer(distance_m)

    if str(original_crs) != target_crs:
        buffered = buffered.to_crs(original_crs)

    return buffered


def calculate_distance_raster(
    geometries: "gpd.GeoDataFrame",
    raster_shape: Tuple[int, int],
    transform,
    target_crs: str = "EPSG:32644",
    max_distance_m: float = 5000.0,
) -> np.ndarray:
    """Calculate a distance raster from a set of geometries.

    Each pixel contains the distance to the nearest geometry in metres.
    """
    if not HAS_VECTOR:
        raise ImportError("geopandas is required for distance calculation")

    import rasterio
    from rasterio.features import rasterize

    # Rasterize the geometries (1 where geometry exists, 0 elsewhere)
    shapes = [(geom, 1) for geom in geometries.geometry if geom is not None]
    if not shapes:
        return np.full(raster_shape, max_distance_m, dtype=np.float32)

    mask = rasterize(
        shapes,
        out_shape=raster_shape,
        transform=transform,
        fill=0,
        dtype=np.uint8,
    )

    # Use scipy distance transform for efficiency
    from scipy.ndimage import distance_transform_edt

    # Get pixel resolution in metres
    # transform is Affine: (a, b, c, d, e, f) where a=pixel width, e=pixel height (negative)
    pixel_size = abs(transform.a)  # in CRS units
    # If CRS is geographic (degrees), convert to metres approximately
    # For UTM CRS, pixel_size is already in metres

    if target_crs.startswith("EPSG:326") or target_crs.startswith("EPSG:327"):
        # UTM — pixel size is in metres
        distances = distance_transform_edt(mask == 0) * pixel_size
    else:
        # Approximate: 1 degree ≈ 111000 metres
        distances = distance_transform_edt(mask == 0) * pixel_size * 111000

    distances = np.clip(distances, 0, max_distance_m).astype(np.float32)
    return distances


def extract_centroids(gdf: "gpd.GeoDataFrame") -> List[Tuple[float, float]]:
    """Extract (lon, lat) centroids from a GeoDataFrame."""
    if not HAS_VECTOR:
        raise ImportError("geopandas is required")

    # Ensure WGS84
    if str(gdf.crs) != "EPSG:4326":
        gdf = gdf.to_crs("EPSG:4326")

    centroids = []
    for geom in gdf.geometry:
        if geom is not None:
            c = geom.centroid
            centroids.append((c.x, c.y))
    return centroids


def get_geometry_info(geom) -> Dict[str, Any]:
    """Return metadata about a single geometry."""
    if not HAS_VECTOR:
        return {"type": "unknown"}

    info = {
        "type": geom.geom_type,
        "is_valid": geom.is_valid,
        "is_empty": geom.is_empty,
        "area": geom.area,
        "length": geom.length,
    }
    bounds = geom.bounds  # minx, miny, maxx, maxy
    info["bounds"] = list(bounds)
    return info
