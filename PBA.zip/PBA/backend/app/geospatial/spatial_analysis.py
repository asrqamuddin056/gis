"""Spatial analysis: slope calculation, weighted overlay, risk classification.

These are the core geospatial algorithms for flood susceptibility assessment.
"""

from typing import Dict, Tuple, Optional, List
import numpy as np

try:
    from scipy.ndimage import sobel, distance_transform_edt
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False


def calculate_slope(
    elevation: np.ndarray,
    pixel_size_m: float = 30.0,
    nodata: Optional[float] = None,
) -> np.ndarray:
    """Calculate slope (degrees) from a DEM array using a Horn-based approach.

    Uses Sobel filters (from scipy.ndimage) as an approximation of the
    finite-difference gradient.

    Args:
        elevation: 2D elevation array
        pixel_size_m: pixel resolution in metres
        nodata: nodata value to preserve

    Returns:
        2D slope array in degrees
    """
    if not HAS_SCIPY:
        raise ImportError("scipy is required for slope calculation")

    arr = elevation.astype(np.float64)

    # Create nodata mask
    if nodata is not None:
        valid_mask = arr != nodata
        # Fill nodata with median for gradient calculation, then mask later
        fill_val = np.median(arr[valid_mask]) if valid_mask.any() else 0
        arr_filled = np.where(valid_mask, arr, fill_val)
    else:
        valid_mask = np.ones_like(arr, dtype=bool)
        arr_filled = arr

    # Compute gradients using Sobel filters
    # Sobel gives gradient in x and y directions (sum of finite differences)
    dz_dx = sobel(arr_filled, axis=1) / (8.0 * pixel_size_m)
    dz_dy = sobel(arr_filled, axis=0) / (8.0 * pixel_size_m)

    # Slope magnitude
    slope_rad = np.arctan(np.sqrt(dz_dx**2 + dz_dy**2))
    slope_deg = np.degrees(slope_rad)

    # Mask nodata areas
    slope_deg[~valid_mask] = nodata if nodata is not None else 0

    return slope_deg


def weighted_overlay(
    layers: Dict[str, np.ndarray],
    weights: Dict[str, float],
    nodata: float = -1.0,
) -> np.ndarray:
    """Perform weighted overlay of multiple normalised risk layers.

    Each layer should already be normalised to a 1–5 risk scale.
    Weights should sum to 1.0 (will be normalised if not).

    FRI = Σ (Wi × Ri)

    Args:
        layers: dict of {factor_name: 2D array} normalised to 1–5
        weights: dict of {factor_name: weight} (0–1)
        nodata: nodata value in input layers

    Returns:
        2D Flood Risk Index array
    """
    if not layers:
        raise ValueError("No layers provided for weighted overlay")

    # Normalise weights to sum to 1
    total_weight = sum(weights.values())
    if total_weight <= 0:
        raise ValueError("Total weight must be positive")

    norm_weights = {k: v / total_weight for k, v in weights.items()}

    # Determine shape from first available layer
    first_layer = next(iter(layers.values()))
    shape = first_layer.shape

    fri = np.zeros(shape, dtype=np.float64)
    weight_sum = np.zeros(shape, dtype=np.float64)

    for factor, weight in norm_weights.items():
        if factor not in layers:
            continue

        layer = layers[factor]
        if layer.shape != shape:
            continue

        # Create valid mask for this layer
        valid = layer != nodata
        valid = valid & np.isfinite(layer)

        fri[valid] += weight * layer[valid]
        weight_sum[valid] += weight

    # Normalise by actual weights used (in case some layers had nodata)
    result = np.full(shape, nodata, dtype=np.float64)
    valid_pixels = weight_sum > 0
    result[valid_pixels] = fri[valid_pixels] / weight_sum[valid_pixels]

    return result


def classify_risk(
    fri: np.ndarray,
    thresholds: Optional[Dict[str, float]] = None,
    nodata: float = -1.0,
) -> np.ndarray:
    """Classify Flood Risk Index into risk categories.

    Default thresholds (on 1–5 scale):
        Low:       < 2.0
        Medium:    2.0 – 3.0
        High:      3.0 – 4.0
        Very High: >= 4.0

    Returns:
        Integer array with class codes: 1=Low, 2=Medium, 3=High, 4=Very High
    """
    if thresholds is None:
        thresholds = {"low": 2.0, "medium": 3.0, "high": 4.0, "very_high": 5.0}

    result = np.full(fri.shape, 0, dtype=np.int8)

    valid = (fri != nodata) & np.isfinite(fri)

    result[valid & (fri < thresholds["low"])] = 1  # Low
    result[valid & (fri >= thresholds["low"]) & (fri < thresholds["medium"])] = 2  # Medium
    result[valid & (fri >= thresholds["medium"]) & (fri < thresholds["high"])] = 3  # High
    result[valid & (fri >= thresholds["high"])] = 4  # Very High

    result[~valid] = 0  # NoData
    return result


def risk_class_label(class_code: int) -> str:
    """Map a risk class code to a human-readable label."""
    labels = {0: "No Data", 1: "Low", 2: "Medium", 3: "High", 4: "Very High"}
    return labels.get(class_code, "Unknown")


def calculate_area_by_category(
    class_array: np.ndarray,
    pixel_size_m: float,
    nodata_class: int = 0,
) -> Dict[str, float]:
    """Calculate area (km²) for each risk category.

    Args:
        class_array: integer array with class codes 1–4
        pixel_size_m: pixel size in metres
        nodata_class: class code representing nodata

    Returns:
        Dict of {category_name: area_km2}
    """
    pixel_area_m2 = pixel_size_m * pixel_size_m

    result = {}
    for class_code, label in [(1, "Low"), (2, "Medium"), (3, "High"), (4, "Very High")]:
        count = int(np.sum(class_array == class_code))
        result[label] = round(count * pixel_area_m2 / 1_000_000, 4)

    result["No Data"] = round(int(np.sum(class_array == nodata_class)) * pixel_area_m2 / 1_000_000, 4)
    return result


def calculate_risk_distribution(class_array: np.ndarray) -> Dict[str, int]:
    """Count pixels in each risk category."""
    result = {}
    for class_code, label in [(1, "Low"), (2, "Medium"), (3, "High"), (4, "Very High")]:
        result[label] = int(np.sum(class_array == class_code))
    result["No Data"] = int(np.sum(class_array == 0))
    return result


def compute_difference(
    baseline: np.ndarray,
    scenario: np.ndarray,
    nodata: float = -1.0,
) -> np.ndarray:
    """Compute the difference between scenario and baseline risk arrays."""
    result = np.full(baseline.shape, nodata, dtype=np.float64)
    valid = (baseline != nodata) & (scenario != nodata) & np.isfinite(baseline) & np.isfinite(scenario)
    result[valid] = scenario[valid] - baseline[valid]
    return result


def classify_change(
    baseline_classes: np.ndarray,
    scenario_classes: np.ndarray,
) -> Dict[str, int]:
    """Identify areas whose risk category changed between baseline and scenario."""
    changed = baseline_classes != scenario_classes
    total_changed = int(np.sum(changed & (baseline_classes > 0) & (scenario_classes > 0)))

    changes = {}
    for old_code, old_label in [(1, "Low"), (2, "Medium"), (3, "High"), (4, "Very High")]:
        for new_code, new_label in [(1, "Low"), (2, "Medium"), (3, "High"), (4, "Very High")]:
            if old_code != new_code:
                count = int(np.sum((baseline_classes == old_code) & (scenario_classes == new_code)))
                if count > 0:
                    changes[f"{old_label} → {new_label}"] = count

    changes["total_changed"] = total_changed
    return changes
