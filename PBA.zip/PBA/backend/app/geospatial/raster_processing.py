"""Raster processing utilities using rasterio and numpy.

Handles loading, saving, resampling, clipping, and statistics
for GeoTIFF raster datasets.
"""

from typing import Optional, Tuple, Dict, Any
from pathlib import Path
import math

import numpy as np

try:
    import rasterio
    from rasterio.transform import from_origin
    from rasterio.warp import reproject, Resampling, calculate_default_transform
    from rasterio.mask import mask as rasterio_mask
    from rasterio.features import shapes as rasterio_shapes
    HAS_RASTERIO = True
except ImportError:
    HAS_RASTERIO = False


def has_rasterio() -> bool:
    """Check if rasterio is available."""
    return HAS_RASTERIO


def read_raster(file_path: str) -> Dict[str, Any]:
    """Read a raster file and return array + metadata.

    Returns dict with: data, transform, crs, nodata, width, height, bounds, dtype
    """
    if not HAS_RASTERIO:
        raise ImportError("rasterio is required to read raster files")

    with rasterio.open(file_path) as src:
        data = src.read(1)  # first band
        transform = src.transform
        crs = str(src.crs) if src.crs else "EPSG:4326"
        nodata = src.nodata
        width = src.width
        height = src.height
        bounds = src.bounds

    return {
        "data": data,
        "transform": transform,
        "crs": crs,
        "nodata": nodata,
        "width": width,
        "height": height,
        "bounds": (bounds.left, bounds.bottom, bounds.right, bounds.top),
        "dtype": str(data.dtype),
    }


def write_raster(
    file_path: str,
    data: np.ndarray,
    transform,
    crs: str = "EPSG:4326",
    nodata: Optional[float] = None,
    dtype: Optional[str] = None,
) -> str:
    """Write a numpy array to a GeoTIFF file.

    Returns the file path.
    """
    if not HAS_RASTERIO:
        raise ImportError("rasterio is required to write raster files")

    if dtype is None:
        dtype = str(data.dtype)

    # Ensure data is 2D
    if data.ndim == 3:
        data = data[0]

    Path(file_path).parent.mkdir(parents=True, exist_ok=True)

    with rasterio.open(
        file_path,
        "w",
        driver="GTiff",
        height=data.shape[0],
        width=data.shape[1],
        count=1,
        dtype=dtype,
        crs=crs,
        transform=transform,
        nodata=nodata,
    ) as dst:
        dst.write(data.astype(dtype), 1)

    return file_path


def create_raster_from_array(
    file_path: str,
    data: np.ndarray,
    top_left_lon: float,
    top_left_lat: float,
    resolution_deg: float,
    crs: str = "EPSG:4326",
    nodata: Optional[float] = None,
) -> str:
    """Create a GeoTIFF from a numpy array with WGS84 georeferencing.

    Args:
        file_path: output file path
        data: 2D numpy array
        top_left_lon: longitude of the top-left corner
        top_left_lat: latitude of the top-left corner
        resolution_deg: pixel size in degrees
        crs: coordinate reference system
        nodata: nodata value
    """
    if not HAS_RASTERIO:
        raise ImportError("rasterio is required to create raster files")

    transform = from_origin(top_left_lon, top_left_lat, resolution_deg, resolution_deg)
    return write_raster(file_path, data, transform, crs, nodata)


def get_raster_stats(data: np.ndarray, nodata: Optional[float] = None) -> Dict[str, float]:
    """Compute basic statistics for a raster array, ignoring nodata."""
    arr = data.astype(np.float64)

    if nodata is not None:
        valid = arr[arr != nodata]
    else:
        valid = arr[np.isfinite(arr)]

    if len(valid) == 0:
        return {
            "min": 0.0, "max": 0.0, "mean": 0.0, "std": 0.0,
            "count": 0, "nodata_count": int(np.prod(arr.shape)),
        }

    return {
        "min": float(np.min(valid)),
        "max": float(np.max(valid)),
        "mean": float(np.mean(valid)),
        "std": float(np.std(valid)),
        "count": int(len(valid)),
        "nodata_count": int(np.prod(arr.shape) - len(valid)),
        "p25": float(np.percentile(valid, 25)),
        "p50": float(np.percentile(valid, 50)),
        "p75": float(np.percentile(valid, 75)),
    }


def normalize_to_scale(
    data: np.ndarray,
    low_risk_value: float,
    high_risk_value: float,
    scale_min: float = 1.0,
    scale_max: float = 5.0,
    invert: bool = False,
    nodata: Optional[float] = None,
) -> np.ndarray:
    """Normalise raster values to a risk scale (default 1–5).

    For factors where low values = high risk (e.g. elevation), set invert=True
    so that low input values map to high risk scores.

    Args:
        data: input array
        low_risk_value: the input value that corresponds to LOW risk
        high_risk_value: the input value that corresponds to HIGH risk
        scale_min: minimum risk score
        scale_max: maximum risk score
        invert: if True, low input → high risk
        nodata: nodata value to preserve
    """
    arr = data.astype(np.float64)
    result = np.full_like(arr, nodata if nodata is not None else -1)

    # Create valid mask
    if nodata is not None:
        valid_mask = arr != nodata
    else:
        valid_mask = np.ones_like(arr, dtype=bool)

    valid = arr[valid_mask]

    if invert:
        # Low input → high risk (e.g. low elevation = high flood risk)
        # So we invert: low_risk_value maps to scale_max, high_risk_value maps to scale_min
        # Actually: if low_risk_value is where risk is LOW and high_risk_value is where risk is HIGH
        # and we invert, then low_risk_value should map to scale_min (low risk)
        # Wait, let me reconsider. "invert" means the factor works opposite.
        # For elevation: low elevation = high risk. So if we define low_risk_value=high elevation
        # and high_risk_value=low elevation, then we don't need invert.
        # Actually, the semantics should be: low_risk_value maps to scale_min, high_risk_value maps to scale_max
        # invert means we swap which end is low vs high risk
        low_val, high_val = high_risk_value, low_risk_value
    else:
        low_val, high_val = low_risk_value, high_risk_value

    # Linear interpolation
    if high_val != low_val:
        normalized = (valid - low_val) / (high_val - low_val)
        normalized = np.clip(normalized, 0, 1)
        result[valid_mask] = scale_min + normalized * (scale_max - scale_min)
    else:
        result[valid_mask] = (scale_min + scale_max) / 2

    return result


def resample_raster(
    src_path: str,
    dst_path: str,
    target_width: int,
    target_height: int,
    resampling_method: str = "bilinear",
) -> str:
    """Resample a raster to a target grid size."""
    if not HAS_RASTERIO:
        raise ImportError("rasterio is required for resampling")

    method_map = {
        "bilinear": Resampling.bilinear,
        "nearest": Resampling.nearest,
        "cubic": Resampling.cubic,
        "average": Resampling.average,
    }
    method = method_map.get(resampling_method, Resampling.bilinear)

    with rasterio.open(src_path) as src:
        data = src.read(1)
        # Use numpy for simple resampling
        from scipy.ndimage import zoom
        zoom_factors = (target_height / src.height, target_width / src.width)
        resampled = zoom(data, zoom_factors, order=1 if resampling_method == "bilinear" else 0)

        # Adjust transform
        transform = from_origin(
            src.bounds.left,
            src.bounds.top,
            (src.bounds.right - src.bounds.left) / target_width,
            (src.bounds.top - src.bounds.bottom) / target_height,
        )

        write_raster(
            dst_path,
            resampled[:target_height, :target_width],
            transform,
            str(src.crs),
            src.nodata,
        )

    return dst_path


def raster_to_polygons(
    raster_path: str,
    output_path: str,
    field_name: str = "value",
) -> str:
    """Convert a raster to vector polygons grouped by unique values.

    Returns the GeoJSON file path.
    """
    if not HAS_RASTERIO:
        raise ImportError("rasterio is required for raster-to-vector conversion")

    try:
        import geopandas as gpd
        from shapely.geometry import shape
    except ImportError:
        raise ImportError("geopandas and shapely are required for raster-to-vector conversion")

    with rasterio.open(raster_path) as src:
        data = src.read(1)
        transform = src.transform
        crs = src.crs
        nodata = src.nodata

    # Generate shapes from raster
    results = []
    geometries = rasterio_shapes(data, transform=transform)

    for geom, value in geometries:
        if nodata is not None and value == nodata:
            continue
        results.append({"geometry": shape(geom), field_name: int(value) if value == int(value) else value})

    if not results:
        return ""

    gdf = gpd.GeoDataFrame(results, crs=crs)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    gdf.to_file(output_path, driver="GeoJSON")
    return output_path


def sample_raster_at_point(
    raster_path: str, lon: float, lat: float
) -> Optional[float]:
    """Sample a raster value at a given lon/lat point."""
    if not HAS_RASTERIO:
        return None

    with rasterio.open(raster_path) as src:
        # Transform point to raster CRS if needed
        if src.crs and str(src.crs) != "EPSG:4326":
            from app.geospatial.coordinate_systems import transform_point
            src_epsg = int(str(src.crs).split(":")[-1]) if ":" in str(src.crs) else 4326
            x, y = transform_point(lon, lat, 4326, src_epsg)
        else:
            x, y = lon, lat

        # Convert to row/col
        row, col = src.index(x, y)

        if 0 <= row < src.height and 0 <= col < src.width:
            val = src.read(1)[row, col]
            if src.nodata is not None and val == src.nodata:
                return None
            return float(val)
    return None
