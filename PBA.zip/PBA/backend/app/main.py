"""FastAPI application — main entry point.

Intelligent Urban Flood Risk Assessment and Prediction System
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.core.config import settings
from app.database.connection import init_db

# Configure logging
logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown lifecycle."""
    logger.info("Starting %s v%s", settings.APP_NAME, settings.APP_VERSION)
    await init_db()
    logger.info("Database initialised")

    # Generate sample data on first run if not present
    import os
    from app.utils.sample_data import generate_all_sample_data
    sample_dir = os.path.join(os.path.dirname(__file__), "..", "..", "data", "sample")
    sample_dir = os.path.abspath(sample_dir)
    if not os.path.exists(os.path.join(sample_dir, "dem_sample.tif")):
        try:
            logger.info("Generating sample data for demonstration...")
            generate_all_sample_data(sample_dir)
            logger.info("Sample data generated at %s", sample_dir)
        except Exception as e:
            logger.warning("Could not generate sample data: %s", e)

    yield
    logger.info("Shutting down %s", settings.APP_NAME)


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "An intelligent geospatial system for identifying, analysing and visualising "
        "urban areas susceptible to flooding using GIS, remote sensing, machine learning "
        "and geospatial analytics."
    ),
    lifespan=lifespan,
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files for output (generated rasters, reports, etc.)
output_dir = settings.output_path
app.mount("/output", StaticFiles(directory=str(output_dir)), name="output")

# Import and include routers
from app.api.routes import dashboard, study_areas, datasets, terrain, lulc, rainfall, drainage, overlay, ml, scenarios, satellite, reports  # noqa: E402

api_prefix = "/api/v1"

app.include_router(dashboard.router, prefix=api_prefix, tags=["Dashboard"])
app.include_router(study_areas.router, prefix=f"{api_prefix}/study-areas", tags=["Study Areas"])
app.include_router(datasets.router, prefix=f"{api_prefix}/datasets", tags=["Datasets"])
app.include_router(terrain.router, prefix=f"{api_prefix}/terrain", tags=["Terrain Analysis"])
app.include_router(lulc.router, prefix=f"{api_prefix}/lulc", tags=["LULC Classification"])
app.include_router(rainfall.router, prefix=f"{api_prefix}/rainfall", tags=["Rainfall Analysis"])
app.include_router(drainage.router, prefix=f"{api_prefix}/drainage", tags=["Drainage Analysis"])
app.include_router(overlay.router, prefix=f"{api_prefix}/overlay", tags=["Weighted Overlay"])
app.include_router(ml.router, prefix=f"{api_prefix}/ml", tags=["Machine Learning"])
app.include_router(scenarios.router, prefix=f"{api_prefix}/scenarios", tags=["Scenario Analysis"])
app.include_router(satellite.router, prefix=f"{api_prefix}/satellite", tags=["Satellite Imagery"])
app.include_router(reports.router, prefix=f"{api_prefix}/reports", tags=["Reports"])


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs",
        "api_prefix": api_prefix,
        "endpoints": {
            "dashboard": f"{api_prefix}/stats",
            "study_areas": f"{api_prefix}/study-areas/",
            "datasets": f"{api_prefix}/datasets/",
            "terrain": f"{api_prefix}/terrain/",
            "lulc": f"{api_prefix}/lulc/",
            "rainfall": f"{api_prefix}/rainfall/",
            "drainage": f"{api_prefix}/drainage/",
            "overlay": f"{api_prefix}/overlay/",
            "ml": f"{api_prefix}/ml/",
            "scenarios": f"{api_prefix}/scenarios/",
            "satellite": f"{api_prefix}/satellite/",
            "reports": f"{api_prefix}/reports/",
        },
    }


@app.get("/api/v1/health")
async def health():
    """Health check."""
    return {"status": "ok", "service": "Flood Risk Assessment API"}
