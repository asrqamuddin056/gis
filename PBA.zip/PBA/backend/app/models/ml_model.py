"""Machine learning model and evaluation, plus scenario analysis models."""

import uuid
from datetime import datetime, timezone

from sqlalchemy import String, Text, DateTime, Float, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column

from app.database.connection import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class MLModel(Base):
    """A trained machine learning model record."""

    __tablename__ = "ml_models"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    study_area_id: Mapped[str] = mapped_column(String(36), ForeignKey("study_areas.id"), nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    algorithm: Mapped[str] = mapped_column(String(50), nullable=False)  # random_forest, xgboost, logistic_regression
    # Hyperparameters as JSON
    hyperparameters: Mapped[dict] = mapped_column(JSON, default=dict)
    # Feature names as JSON list
    features: Mapped[dict] = mapped_column(JSON, default=dict)
    # Path to saved model file (joblib)
    model_path: Mapped[str] = mapped_column(String(512), default="")
    # Training info
    training_dataset_id: Mapped[str] = mapped_column(String(36), ForeignKey("datasets.id"), nullable=True)
    n_samples: Mapped[int] = mapped_column(Integer, default=0)
    n_features: Mapped[int] = mapped_column(Integer, default=0)
    # Feature importance as JSON
    feature_importance: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending, training, trained, failed
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    trained_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)


class ModelEvaluation(Base):
    """Evaluation metrics for a trained ML model."""

    __tablename__ = "model_evaluations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    model_id: Mapped[str] = mapped_column(String(36), ForeignKey("ml_models.id"), nullable=False)
    accuracy: Mapped[float] = mapped_column(Float, default=0.0)
    precision: Mapped[float] = mapped_column(Float, default=0.0)
    recall: Mapped[float] = mapped_column(Float, default=0.0)
    f1_score: Mapped[float] = mapped_column(Float, default=0.0)
    roc_auc: Mapped[float] = mapped_column(Float, default=0.0)
    # Confusion matrix as JSON [[tn, fp], [fn, tp]]
    confusion_matrix: Mapped[dict] = mapped_column(JSON, default=dict)
    # Classification report as JSON
    classification_report: Mapped[dict] = mapped_column(JSON, default=dict)
    # Validation strategy description
    validation_strategy: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class ScenarioAnalysis(Base):
    """A hypothetical rainfall scenario analysis."""

    __tablename__ = "scenario_analyses"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    study_area_id: Mapped[str] = mapped_column(String(36), ForeignKey("study_areas.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    # Hypothetical rainfall intensity in mm
    scenario_rainfall_mm: Mapped[float] = mapped_column(Float, default=0.0)
    # Baseline assessment for comparison
    baseline_assessment_id: Mapped[str] = mapped_column(String(36), ForeignKey("risk_assessments.id"), nullable=True)
    # Output paths
    scenario_raster_path: Mapped[str] = mapped_column(String(512), default="")
    difference_raster_path: Mapped[str] = mapped_column(String(512), default="")
    # Statistics as JSON
    statistics: Mapped[dict] = mapped_column(JSON, default=dict)
    # Areas whose risk category changed
    changed_areas: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    completed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)
