"""Dataset and metadata models for uploaded geospatial data."""

import uuid
from datetime import datetime, timezone

from sqlalchemy import String, Text, DateTime, Integer, Float, Boolean, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.connection import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Dataset(Base):
    """An uploaded geospatial or tabular dataset."""

    __tablename__ = "datasets"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    # Dataset type: raster, vector, csv, rainfall, flood_record, satellite
    data_type: Mapped[str] = mapped_column(String(50), nullable=False)
    source: Mapped[str] = mapped_column(String(255), default="")
    # Relative path to stored file
    file_path: Mapped[str] = mapped_column(String(512), default="")
    original_filename: Mapped[str] = mapped_column(String(255), default="")
    file_size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    # Coordinate reference system
    crs: Mapped[str] = mapped_column(String(50), default="")
    # Spatial resolution in metres (for rasters)
    spatial_resolution: Mapped[float] = mapped_column(Float, default=0.0)
    # Coverage area description
    coverage_area: Mapped[str] = mapped_column(String(255), default="")
    # Processing status: pending, processing, completed, failed
    processing_status: Mapped[str] = mapped_column(String(20), default="pending")
    # Validation status: pending, valid, invalid
    validation_status: Mapped[str] = mapped_column(String(20), default="pending")
    validation_errors: Mapped[str] = mapped_column(Text, default="")
    # Foreign key to study area
    study_area_id: Mapped[str] = mapped_column(String(36), ForeignKey("study_areas.id"), nullable=True)
    is_sample_data: Mapped[bool] = mapped_column(Boolean, default=False)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    processed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)

    metadata_records: Mapped[list["DatasetMetadata"]] = relationship(back_populates="dataset", cascade="all, delete-orphan")


class DatasetMetadata(Base):
    """Key-value metadata entries for a dataset (extensible)."""

    __tablename__ = "dataset_metadata"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    dataset_id: Mapped[str] = mapped_column(String(36), ForeignKey("datasets.id"), nullable=False)
    key: Mapped[str] = mapped_column(String(100), nullable=False)
    value: Mapped[str] = mapped_column(Text, default="")

    dataset: Mapped["Dataset"] = relationship(back_populates="metadata_records")
