"""Flood risk assessment, weights, and thematic layer models."""

import uuid
from datetime import datetime, timezone

from sqlalchemy import String, Text, DateTime, Float, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.connection import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class RiskWeight(Base):
    """Weight configuration for weighted overlay analysis."""

    __tablename__ = "risk_weights"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    study_area_id: Mapped[str] = mapped_column(String(36), ForeignKey("study_areas.id"), nullable=True)
    # Factor name: rainfall, elevation, slope, drainage_proximity, lulc, built_up, soil
    factor: Mapped[str] = mapped_column(String(50), nullable=False)
    # Weight as a fraction 0–1
    weight: Mapped[float] = mapped_column(Float, nullable=False)
    label: Mapped[str] = mapped_column(String(100), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    is_enabled: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class RiskLayer(Base):
    """A generated thematic layer for a study area."""

    __tablename__ = "risk_layers"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    assessment_id: Mapped[str] = mapped_column(String(36), ForeignKey("risk_assessments.id"), nullable=True)
    study_area_id: Mapped[str] = mapped_column(String(36), ForeignKey("study_areas.id"), nullable=True)
    # Layer type: elevation, slope, rainfall, lulc, drainage_proximity, water_proximity, built_up, soil
    layer_type: Mapped[str] = mapped_column(String(50), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    # Path to generated raster or vector file
    file_path: Mapped[str] = mapped_column(String(512), default="")
    # Statistics stored as JSON
    statistics: Mapped[dict] = mapped_column(JSON, default=dict)
    crs: Mapped[str] = mapped_column(String(50), default="")
    spatial_resolution: Mapped[float] = mapped_column(Float, default=0.0)
    is_enabled: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    assessment: Mapped["RiskAssessment"] = relationship(back_populates="layers")


class RiskAssessment(Base):
    """A complete flood risk assessment run."""

    __tablename__ = "risk_assessments"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    study_area_id: Mapped[str] = mapped_column(String(36), ForeignKey("study_areas.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    # Method: weighted_overlay or machine_learning
    method: Mapped[str] = mapped_column(String(50), default="weighted_overlay")
    # Weights configuration as JSON
    weights: Mapped[dict] = mapped_column(JSON, default=dict)
    # Classification thresholds as JSON
    thresholds: Mapped[dict] = mapped_column(JSON, default=dict)
    # Output file paths
    risk_raster_path: Mapped[str] = mapped_column(String(512), default="")
    risk_vector_path: Mapped[str] = mapped_column(String(512), default="")
    # Statistics as JSON
    statistics: Mapped[dict] = mapped_column(JSON, default=dict)
    # Area calculations per risk category as JSON
    area_by_category: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    completed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)

    layers: Mapped[list["RiskLayer"]] = relationship(back_populates="assessment")
