"""Background processing job model for long-running geospatial tasks."""

import uuid
from datetime import datetime, timezone

from sqlalchemy import String, Text, DateTime, Integer, Float, JSON
from sqlalchemy.orm import Mapped, mapped_column

from app.database.connection import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ProcessingJob(Base):
    """Tracks background processing jobs (DEM, LULC, overlay, ML, etc.)."""

    __tablename__ = "processing_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    # Job type: dem_analysis, lulc_classification, overlay, ml_training, etc.
    job_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # Status: pending, running, completed, failed
    status: Mapped[str] = mapped_column(String(20), default="pending")
    # Progress 0–100
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    # Message / status text
    message: Mapped[str] = mapped_column(Text, default="")
    # Result data as JSON
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    # Error message if failed
    error: Mapped[str] = mapped_column(Text, default="")
    # Related entities
    study_area_id: Mapped[str] = mapped_column(String(36), nullable=True)
    dataset_id: Mapped[str] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)
