"""Study area model — a user-defined geographical region of interest."""

import uuid
from datetime import datetime, timezone

from sqlalchemy import String, Text, DateTime, Float
from sqlalchemy.orm import Mapped, mapped_column

from app.database.connection import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class StudyArea(Base):
    """A geographical study area with optional boundary geometry (GeoJSON)."""

    __tablename__ = "study_areas"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    # GeoJSON string of the boundary polygon
    boundary_geojson: Mapped[str] = mapped_column(Text, default="")
    # Bounding box in WGS84 (lon/lat)
    bbox_min_lon: Mapped[float] = mapped_column(Float, default=0.0)
    bbox_min_lat: Mapped[float] = mapped_column(Float, default=0.0)
    bbox_max_lon: Mapped[float] = mapped_column(Float, default=0.0)
    bbox_max_lat: Mapped[float] = mapped_column(Float, default=0.0)
    # Area in square kilometres
    area_km2: Mapped[float] = mapped_column(Float, default=0.0)
    # Coordinate reference system EPSG code for analysis
    analysis_crs: Mapped[str] = mapped_column(String(10), default="32644")  # UTM Zone 44N
    location_label: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)
