"""Weighted overlay analysis service — the core flood risk engine.

Implements the GIS-based Weighted Overlay Analysis:
    FRI = Σ (Wi × Ri)

Where:
    FRI = Flood Risk Index
    Wi  = Weight assigned to the i-th factor
    Ri  = Normalised risk score (1–5) for the i-th factor

This service:
1. Loads all available thematic layers for a study area
2. Normalises each to a 1–5 risk scale
3. Applies user-configurable weights
4. Computes the weighted overlay (FRI)
5. Classifies the result into risk categories
6. Generates statistics and area calculations
7. Saves outputs as GeoTIFF and GeoJSON
"""

import os
import json
from pathlib import Path
from typing import Dict, Optional, List, Tuple
import numpy as np

from app.core.config import settings
from app.geospatial.raster_processing import (
    read_raster, write_raster, get_raster_stats, normalize_to_scale,
    has_rasterio, raster_to_polygons,
)
from app.geospatial.spatial_analysis import (
    weighted_overlay, classify_risk, calculate_area_by_category,
    calculate_risk_distribution, risk_class_label,
)
from app.utils.sample_data import get_lulc_risk_scores

# Default weights (illustrative initial values, not scientifically universal)
DEFAULT_WEIGHTS = {
    "rainfall": 0.25,
    "elevation": 0.20,
    "drainage_proximity": 0.20,
    "slope": 0.15,
    "lulc": 0.15,
    "built_up": 0.05,
}

DEFAULT_THRESHOLDS = {
    "low": 2.0,
    "medium": 3.0,
    "high": 4.0,
    "very_high": 5.0,
}


def validate_weights(weights: Dict[str, float]) -> Tuple[bool, str]:
    """Validate weight configuration.

    Rules:
    - All weights non-negative
    - Total weight is positive (will be normalised internally)
    """
    if not weights:
        return False, "No weights provided"

    total = 0.0
    for factor, weight in weights.items():
        if weight < 0:
            return False, f"Weight for '{factor}' is negative"
        if weight > 1:
            return False, f"Weight for '{factor}' exceeds 1.0"
        total += weight

    if total <= 0:
        return False, "Total weight must be positive"

    return True, ""


def normalize_layer(
    layer_type: str,
    data: np.ndarray,
    nodata: Optional[float] = None,
) -> np.ndarray:
    """Normalize a thematic layer to a 1–5 risk scale.

    Different factors use different normalisation strategies:
    - Elevation: low elevation → high risk (inverted)
    - Slope: low slope → high risk (flat areas flood more)
    - Rainfall: high rainfall → high risk
    - Drainage proximity: close to drainage → high risk (inverted distance)
    - LULC: class-based risk scores
    - Built-up density: high density → medium-high risk (runoff)
    """
    arr = data.astype(np.float64)

    if layer_type == "elevation":
        # Low elevation → high flood risk
        stats = get_raster_stats(arr, nodata)
        if stats["count"] == 0:
            return np.full_like(arr, 3.0)
        return normalize_to_scale(
            arr, low_risk_value=stats["max"], high_risk_value=stats["min"],
            invert=True, nodata=nodata,
        )

    elif layer_type == "slope":
        # Low slope (flat) → high risk; steep slopes drain quickly
        stats = get_raster_stats(arr, nodata)
        if stats["count"] == 0:
            return np.full_like(arr, 3.0)
        return normalize_to_scale(
            arr, low_risk_value=stats["max"], high_risk_value=stats["min"],
            invert=True, nodata=nodata,
        )

    elif layer_type == "rainfall":
        # High rainfall → high risk
        stats = get_raster_stats(arr, nodata)
        if stats["count"] == 0:
            return np.full_like(arr, 3.0)
        return normalize_to_scale(
            arr, low_risk_value=stats["min"], high_risk_value=stats["max"],
            nodata=nodata,
        )

    elif layer_type == "drainage_proximity":
        # Close to drainage → high risk (inverted distance)
        stats = get_raster_stats(arr, nodata)
        if stats["count"] == 0:
            return np.full_like(arr, 3.0)
        return normalize_to_scale(
            arr, low_risk_value=stats["max"], high_risk_value=stats["min"],
            invert=True, nodata=nodata,
        )

    elif layer_type == "lulc":
        # Class-based risk scores
        risk_scores = get_lulc_risk_scores()
        result = np.full(arr.shape, 3.0, dtype=np.float64)
        valid = arr != nodata if nodata is not None else np.ones_like(arr, dtype=bool)
        for class_code, score in risk_scores.items():
            result[valid & (arr == class_code)] = float(score)
        return result

    elif layer_type == "built_up":
        # High built-up → medium-high risk (impermeable surfaces)
        stats = get_raster_stats(arr, nodata)
        if stats["count"] == 0:
            return np.full_like(arr, 3.0)
        # Scale: 0 density → risk 2, 1 density → risk 4
        return normalize_to_scale(
            arr, low_risk_value=0.0, high_risk_value=1.0,
            scale_min=2.0, scale_max=4.0, nodata=nodata,
        )

    else:
        # Default: linear normalisation
        stats = get_raster_stats(arr, nodata)
        if stats["count"] == 0:
            return np.full_like(arr, 3.0)
        return normalize_to_scale(
            arr, low_risk_value=stats["min"], high_risk_value=stats["max"],
            nodata=nodata,
        )


def run_weighted_overlay(
    layer_paths: Dict[str, str],
    weights: Dict[str, float],
    thresholds: Optional[Dict[str, float]] = None,
    output_dir: str = "./output",
    assessment_id: str = "assessment",
) -> Dict:
    """Run the complete weighted overlay analysis.

    Args:
        layer_paths: dict of {factor_name: file_path} for available layers
        weights: dict of {factor_name: weight} (0–1, sum to 1)
        thresholds: classification thresholds
        output_dir: directory for output files
        assessment_id: unique ID for output file naming

    Returns:
        Dict with FRI raster path, classification, statistics, area calculations
    """
    if not has_rasterio():
        raise ImportError("rasterio is required for weighted overlay analysis")

    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS.copy()

    # Validate weights
    is_valid, msg = validate_weights(weights)
    if not is_valid:
        raise ValueError(f"Invalid weights: {msg}")

    # Load and normalize each available layer
    normalized_layers = {}
    reference_raster = None
    reference_transform = None
    reference_crs = None
    reference_nodata = None
    reference_bounds = None
    reference_width = None
    reference_height = None

    for factor, weight in weights.items():
        if factor not in layer_paths or not layer_paths[factor]:
            continue
        if weight <= 0:
            continue

        file_path = layer_paths[factor]
        if not os.path.exists(file_path):
            continue

        try:
            raster = read_raster(file_path)
            data = raster["data"]

            if reference_raster is None:
                reference_raster = data
                reference_transform = raster["transform"]
                reference_crs = raster["crs"]
                reference_nodata = raster["nodata"]
                reference_bounds = raster["bounds"]
                reference_width = raster["width"]
                reference_height = raster["height"]

            # Normalize to 1–5 risk scale
            normalized = normalize_layer(factor, data, raster["nodata"])
            normalized_layers[factor] = normalized
        except Exception as e:
            print(f"Warning: Could not load layer '{factor}': {e}")
            continue

    if not normalized_layers:
        raise ValueError("No valid layers could be loaded for weighted overlay")

    # Resample all layers to match reference grid
    ref_shape = reference_raster.shape
    aligned_layers = {}
    for factor, layer in normalized_layers.items():
        if layer.shape == ref_shape:
            aligned_layers[factor] = layer
        else:
            # Simple resampling using scipy zoom
            try:
                from scipy.ndimage import zoom
                factors = (ref_shape[0] / layer.shape[0], ref_shape[1] / layer.shape[1])
                aligned_layers[factor] = zoom(layer, factors, order=1)
                aligned_layers[factor] = aligned_layers[factor][:ref_shape[0], :ref_shape[1]]
            except Exception:
                aligned_layers[factor] = layer  # Use as-is

    # Run weighted overlay
    fri_nodata = -1.0
    fri = weighted_overlay(aligned_layers, weights, fri_nodata)

    # Classify risk
    risk_classes = classify_risk(fri, thresholds, fri_nodata)

    # Calculate statistics
    fri_stats = get_raster_stats(fri, fri_nodata)
    risk_dist = calculate_risk_distribution(risk_classes)

    # Determine pixel size for area calculation
    if reference_bounds and reference_width and reference_height:
        # Calculate from bounds and dimensions (most reliable)
        lon_extent = reference_bounds[2] - reference_bounds[0]  # right - left
        lat_extent = reference_bounds[3] - reference_bounds[1]  # top - bottom
        pixel_width_deg = lon_extent / reference_width
        pixel_height_deg = lat_extent / reference_height

        # Approximate metres per degree at average latitude
        avg_lat = (reference_bounds[1] + reference_bounds[3]) / 2
        import math
        metres_per_deg_lat = 111000.0
        metres_per_deg_lon = 111000.0 * math.cos(math.radians(avg_lat))

        pixel_size_m = (pixel_width_deg * metres_per_deg_lon + pixel_height_deg * metres_per_deg_lat) / 2
    elif reference_transform:
        pixel_size_deg = abs(reference_transform.a)
        pixel_size_m = pixel_size_deg * 111000
        if reference_crs and "326" in str(reference_crs):
            pixel_size_m = pixel_size_deg
    else:
        pixel_size_m = 30.0  # default

    area_by_cat = calculate_area_by_category(risk_classes, pixel_size_m)

    # Save outputs
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    fri_path = os.path.join(output_dir, f"fri_{assessment_id}.tif")
    write_raster(fri_path, fri.astype(np.float32), reference_transform, reference_crs, fri_nodata)

    risk_class_path = os.path.join(output_dir, f"risk_class_{assessment_id}.tif")
    write_raster(risk_class_path, risk_classes.astype(np.int16), reference_transform, reference_crs, 0)

    # Convert to vector polygons
    risk_vector_path = ""
    try:
        risk_vector_path = os.path.join(output_dir, f"risk_vector_{assessment_id}.geojson")
        raster_to_polygons(risk_class_path, risk_vector_path, "risk_class")
    except Exception as e:
        print(f"Warning: Could not generate vector output: {e}")

    # Calculate high risk percentage
    total_valid = sum(risk_dist.get(k, 0) for k in ["Low", "Medium", "High", "Very High"])
    high_count = risk_dist.get("High", 0) + risk_dist.get("Very High", 0)
    high_pct = (high_count / total_valid * 100) if total_valid > 0 else 0

    return {
        "fri_raster_path": fri_path,
        "risk_class_raster_path": risk_class_path,
        "risk_vector_path": risk_vector_path,
        "fri_stats": fri_stats,
        "risk_distribution": risk_dist,
        "area_by_category": area_by_cat,
        "high_risk_percentage": round(high_pct, 2),
        "weights_used": weights,
        "thresholds_used": thresholds,
        "layers_used": list(aligned_layers.keys()),
        "pixel_size_m": pixel_size_m,
    }


def run_scenario_analysis(
    layer_paths: Dict[str, str],
    weights: Dict[str, float],
    thresholds: Dict[str, float],
    scenario_rainfall_mm: float,
    output_dir: str = "./output",
    assessment_id: str = "scenario",
    baseline_fri: Optional[np.ndarray] = None,
    baseline_classes: Optional[np.ndarray] = None,
    reference_transform=None,
    reference_crs: str = "EPSG:4326",
) -> Dict:
    """Run a hypothetical rainfall scenario analysis.

    Replaces the rainfall layer with a uniform scenario value and
    recalculates the FRI.

    Args:
        layer_paths: available layer file paths
        weights: weight configuration
        thresholds: risk classification thresholds
        scenario_rainfall_mm: hypothetical rainfall intensity in mm
        output_dir: directory for outputs
        assessment_id: unique ID for naming
        baseline_fri: baseline FRI array for comparison
        baseline_classes: baseline risk classes for change detection
        reference_transform: geotransform for output rasters
        reference_crs: CRS for output rasters

    Returns:
        Dict with scenario results and change analysis
    """
    from app.geospatial.spatial_analysis import compute_difference, classify_change

    # Load existing layers
    normalized_layers = {}
    ref_shape = None
    ref_transform = reference_transform
    ref_crs = reference_crs

    for factor, weight in weights.items():
        if factor == "rainfall":
            continue  # We'll replace this with the scenario
        if factor not in layer_paths or not layer_paths[factor]:
            continue
        if weight <= 0:
            continue

        file_path = layer_paths[factor]
        if not os.path.exists(file_path):
            continue

        try:
            raster = read_raster(file_path)
            data = raster["data"]
            if ref_shape is None:
                ref_shape = data.shape
                ref_transform = raster["transform"]
                ref_crs = raster["crs"]
            normalized = normalize_layer(factor, data, raster["nodata"])
            normalized_layers[factor] = normalized
        except Exception as e:
            print(f"Warning: Could not load layer '{factor}': {e}")

    if ref_shape is None:
        raise ValueError("No reference layer available for scenario analysis")

    # Create scenario rainfall layer (uniform value)
    scenario_rainfall = np.full(ref_shape, scenario_rainfall_mm, dtype=np.float64)
    # If we have the original rainfall layer, use its distribution pattern but scale to scenario
    if "rainfall" in layer_paths and os.path.exists(layer_paths["rainfall"]):
        try:
            orig_raster = read_raster(layer_paths["rainfall"])
            orig_rain = orig_raster["data"].astype(np.float64)
            # Scale: create a spatially varying pattern centered on the scenario value
            orig_stats = get_raster_stats(orig_rain, orig_raster["nodata"])
            if orig_stats["count"] > 0 and orig_stats["max"] > orig_stats["min"]:
                # Normalize original pattern, then scale to scenario range
                pattern = (orig_rain - orig_stats["min"]) / (orig_stats["max"] - orig_stats["min"])
                # Scenario: vary from 50% to 150% of the scenario value based on original pattern
                scenario_rainfall = scenario_rainfall_mm * (0.5 + pattern)
                scenario_rainfall = np.clip(scenario_rainfall, 0, scenario_rainfall_mm * 1.5)
                if scenario_rainfall.shape != ref_shape:
                    from scipy.ndimage import zoom
                    factors = (ref_shape[0] / scenario_rainfall.shape[0], ref_shape[1] / scenario_rainfall.shape[1])
                    scenario_rainfall = zoom(scenario_rainfall, factors, order=1)[:ref_shape[0], :ref_shape[1]]
        except Exception as e:
            print(f"Warning: Using uniform rainfall: {e}")

    # Normalize scenario rainfall
    scenario_normalized = normalize_layer("rainfall", scenario_rainfall)
    if scenario_normalized.shape != ref_shape:
        from scipy.ndimage import zoom
        factors = (ref_shape[0] / scenario_normalized.shape[0], ref_shape[1] / scenario_normalized.shape[1])
        scenario_normalized = zoom(scenario_normalized, factors, order=1)[:ref_shape[0], :ref_shape[1]]
    normalized_layers["rainfall"] = scenario_normalized

    # Run weighted overlay with scenario
    fri_nodata = -1.0
    scenario_fri = weighted_overlay(normalized_layers, weights, fri_nodata)
    scenario_classes = classify_risk(scenario_fri, thresholds, fri_nodata)

    # Save scenario outputs
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    scenario_fri_path = os.path.join(output_dir, f"scenario_fri_{assessment_id}.tif")
    write_raster(scenario_fri_path, scenario_fri.astype(np.float32), ref_transform, ref_crs, fri_nodata)

    scenario_class_path = os.path.join(output_dir, f"scenario_class_{assessment_id}.tif")
    write_raster(scenario_class_path, scenario_classes.astype(np.int16), ref_transform, ref_crs, 0)

    # Calculate statistics
    scenario_stats = get_raster_stats(scenario_fri, fri_nodata)
    scenario_dist = calculate_risk_distribution(scenario_classes)

    # Compute difference if baseline provided
    diff_path = ""
    changes = {}
    if baseline_fri is not None and baseline_classes is not None:
        diff = compute_difference(baseline_fri, scenario_fri, fri_nodata)
        diff_path = os.path.join(output_dir, f"diff_{assessment_id}.tif")
        write_raster(diff_path, diff.astype(np.float32), ref_transform, ref_crs, fri_nodata)
        changes = classify_change(baseline_classes, scenario_classes)

    return {
        "scenario_fri_path": scenario_fri_path,
        "scenario_class_path": scenario_class_path,
        "difference_path": diff_path,
        "scenario_rainfall_mm": scenario_rainfall_mm,
        "scenario_stats": scenario_stats,
        "risk_distribution": scenario_dist,
        "changed_areas": changes,
        "weights_used": weights,
    }
