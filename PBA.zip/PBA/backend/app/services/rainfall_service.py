"""Rainfall analysis service.

Handles rainfall data import, distribution analysis, intensity
classification, temporal visualisation, and anomaly detection.
"""

import os
import csv
import json
from pathlib import Path
from typing import Dict, Optional, List, Any
from datetime import datetime
import numpy as np

from app.core.config import settings
from app.geospatial.raster_processing import (
    read_raster, write_raster, get_raster_stats, has_rasterio,
)


# Rainfall intensity classes (mm for a typical monsoon month)
RAINALL_INTENSITY_CLASSES = {
    "very_light": (0, 50),
    "light": (50, 100),
    "moderate": (100, 150),
    "heavy": (150, 200),
    "very_heavy": (200, 9999),
}


def classify_rainfall_intensity(rainfall_mm: float) -> str:
    """Classify a rainfall value into an intensity category."""
    for label, (low, high) in RAINALL_INTENSITY_CLASSES.items():
        if low <= rainfall_mm < high:
            return label
    return "very_heavy"


def process_rainfall_csv(file_path: str) -> Dict:
    """Process a rainfall CSV file with station data.

    Expected columns: station, lat, lon, month, rainfall_mm, year
    (or similar)
    """
    import pandas as pd

    df = pd.read_csv(file_path)

    # Find relevant columns
    rainfall_col = None
    for c in df.columns:
        if c.lower() in ("rainfall_mm", "rainfall", "rain", "precipitation", "precip"):
            rainfall_col = c
            break

    if rainfall_col is None:
        raise ValueError("CSV must contain a rainfall column (rainfall_mm, rainfall, rain, precipitation)")

    df[rainfall_col] = pd.to_numeric(df[rainfall_col], errors="coerce")

    # Statistics
    stats = {
        "total_records": len(df),
        "min_rainfall": float(df[rainfall_col].min()),
        "max_rainfall": float(df[rainfall_col].max()),
        "mean_rainfall": float(df[rainfall_col].mean()),
        "std_rainfall": float(df[rainfall_col].std()),
        "missing_values": int(df[rainfall_col].isna().sum()),
    }

    # Temporal analysis if month/year columns exist
    temporal = {}
    month_col = None
    year_col = None
    for c in df.columns:
        if c.lower() in ("month", "mon"):
            month_col = c
        if c.lower() in ("year", "yr"):
            year_col = c

    if month_col:
        monthly_avg = df.groupby(month_col)[rainfall_col].mean().to_dict()
        temporal["monthly_average"] = {str(k): round(v, 2) for k, v in monthly_avg.items()}

    if year_col:
        yearly_avg = df.groupby(year_col)[rainfall_col].mean().to_dict()
        temporal["yearly_average"] = {str(k): round(v, 2) for k, v in yearly_avg.items()}

    # Station analysis if station column exists
    stations = []
    station_col = None
    lat_col = None
    lon_col = None
    for c in df.columns:
        if c.lower() in ("station", "name", "station_name"):
            station_col = c
        if c.lower() in ("lat", "latitude"):
            lat_col = c
        if c.lower() in ("lon", "lng", "longitude"):
            lon_col = c

    if station_col:
        for station_name in df[station_col].unique():
            station_data = df[df[station_col] == station_name]
            entry = {
                "name": str(station_name),
                "mean_rainfall": round(float(station_data[rainfall_col].mean()), 2),
                "max_rainfall": round(float(station_data[rainfall_col].max()), 2),
                "min_rainfall": round(float(station_data[rainfall_col].min()), 2),
                "record_count": int(len(station_data)),
            }
            if lat_col and lon_col:
                entry["lat"] = float(station_data[lat_col].iloc[0])
                entry["lon"] = float(station_data[lon_col].iloc[0])
            stations.append(entry)

    # Detect anomalies (unusually high rainfall)
    if len(df[rainfall_col].dropna()) > 10:
        q1 = df[rainfall_col].quantile(0.25)
        q3 = df[rainfall_col].quantile(0.75)
        iqr = q3 - q1
        upper_bound = q3 + 1.5 * iqr
        anomalies = df[df[rainfall_col] > upper_bound]
        anomaly_list = []
        for _, row in anomalies.iterrows():
            entry = {"rainfall_mm": float(row[rainfall_col])}
            if station_col:
                entry["station"] = str(row[station_col])
            if month_col:
                entry["month"] = str(row[month_col])
            if year_col:
                entry["year"] = str(row[year_col])
            anomaly_list.append(entry)
    else:
        anomaly_list = []

    # Intensity distribution
    intensity_dist = {label: 0 for label in RAINALL_INTENSITY_CLASSES}
    for val in df[rainfall_col].dropna():
        intensity_dist[classify_rainfall_intensity(val)] += 1

    return {
        "stats": stats,
        "temporal": temporal,
        "stations": stations,
        "anomalies": anomaly_list,
        "intensity_distribution": intensity_dist,
        "is_historical": True,  # CSV data is historical observation, NOT forecast
        "note": "This rainfall data represents historical observations, not live weather forecasts.",
    }


def process_rainfall_raster(file_path: str, output_dir: str = "./output") -> Dict:
    """Process a rainfall raster and generate statistics + distribution."""
    if not has_rasterio():
        raise ImportError("rasterio is required for rainfall raster processing")

    raster = read_raster(file_path)
    data = raster["data"]
    stats = get_raster_stats(data, raster["nodata"])

    # Generate distribution histogram
    valid = data[data != raster["nodata"]] if raster["nodata"] is not None else data[np.isfinite(data)]
    if len(valid) > 0:
        counts, bin_edges = np.histogram(valid, bins=10)
        bins = [round((bin_edges[i] + bin_edges[i + 1]) / 2, 1) for i in range(len(bin_edges) - 1)]
        distribution = {"bins": bins, "counts": counts.tolist()}
    else:
        distribution = {"bins": [], "counts": []}

    # Classify intensity
    intensity_raster = np.zeros(data.shape, dtype=np.int8)
    valid_mask = data != raster["nodata"] if raster["nodata"] is not None else np.ones_like(data, dtype=bool)

    for class_idx, (label, (low, high)) in enumerate(RAINALL_INTENSITY_CLASSES.items(), 1):
        mask = valid_mask & (data >= low) & (data < high)
        intensity_raster[mask] = class_idx

    # Save intensity classification
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    intensity_path = os.path.join(output_dir, "rainfall_intensity.tif")
    write_raster(intensity_path, intensity_raster, raster["transform"], raster["crs"], 0)

    # Count by intensity
    intensity_counts = {}
    for class_idx, (label, _) in enumerate(RAINALL_INTENSITY_CLASSES.items(), 1):
        intensity_counts[label] = int(np.sum(intensity_raster == class_idx))

    return {
        "stats": stats,
        "distribution": distribution,
        "intensity_counts": intensity_counts,
        "intensity_raster_path": intensity_path,
        "is_historical": True,
        "note": "This rainfall data represents historical observations, not live weather forecasts.",
    }


def get_rainfall_at_point(file_path: str, lon: float, lat: float) -> Optional[float]:
    """Get rainfall value at a specific point."""
    if not has_rasterio():
        return None
    from app.geospatial.raster_processing import sample_raster_at_point
    return sample_raster_at_point(file_path, lon, lat)
