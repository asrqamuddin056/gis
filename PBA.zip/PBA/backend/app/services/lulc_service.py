"""Land Use / Land Cover classification service.

Handles LULC raster loading, class statistics, area calculations,
and optional Random Forest classification when training samples are available.

LULC classes:
    1 = Water bodies
    2 = Vegetation
    3 = Built-up areas
    4 = Agricultural land
    5 = Bare soil
"""

import os
import json
from pathlib import Path
from typing import Dict, Optional, List
import numpy as np

from app.core.config import settings
from app.geospatial.raster_processing import (
    read_raster, write_raster, get_raster_stats, has_rasterio,
)
from app.utils.sample_data import get_lulc_class_info


LULC_CLASSES = get_lulc_class_info()


def process_lulc_raster(
    lulc_path: str,
    output_dir: str = "./output",
    study_area_id: str = "default",
) -> Dict:
    """Process a LULC raster and generate class statistics + area calculations.

    Args:
        lulc_path: path to LULC GeoTIFF
        output_dir: directory for outputs
        study_area_id: study area identifier

    Returns:
        Dict with class statistics, area per class, distribution
    """
    if not has_rasterio():
        raise ImportError("rasterio is required for LULC processing")

    raster = read_raster(lulc_path)
    data = raster["data"]
    transform = raster["transform"]
    crs = raster["crs"]
    nodata = raster["nodata"]

    # Count pixels per class
    class_counts = {}
    class_areas = {}
    total_valid = 0

    for class_code, class_name in LULC_CLASSES.items():
        count = int(np.sum(data == class_code))
        class_counts[class_name] = count
        total_valid += count

    # Calculate area (approximate)
    pixel_size_deg = abs(transform.a) if transform else 0.001
    pixel_area_km2 = (pixel_size_deg * 111) ** 2 / 1_000_000  # rough km²

    for class_name, count in class_counts.items():
        class_areas[class_name] = round(count * pixel_area_km2, 4)

    total_area_km2 = round(total_valid * pixel_area_km2, 4)

    # Calculate distribution percentages
    class_distribution = {}
    if total_valid > 0:
        for class_name, count in class_counts.items():
            class_distribution[class_name] = round(count / total_valid * 100, 2)

    # Get raster statistics
    stats = get_raster_stats(data, nodata)

    # Generate NDVI / NDWI if satellite bands are available
    # (This would require multispectral imagery — documented separately)

    return {
        "class_counts": class_counts,
        "class_areas_km2": class_areas,
        "class_distribution": class_distribution,
        "total_area_km2": total_area_km2,
        "stats": stats,
        "crs": crs,
        "pixel_size_deg": pixel_size_deg,
        "lulc_classes": LULC_CLASSES,
    }


def calculate_ndvi(nir_path: str, red_path: str, output_path: str) -> Dict:
    """Calculate NDVI from NIR and Red bands.

    NDVI = (NIR - Red) / (NIR + Red)

    Returns:
        Dict with NDVI stats and output path
    """
    if not has_rasterio():
        raise ImportError("rasterio is required for NDVI calculation")

    nir_raster = read_raster(nir_path)
    red_raster = read_raster(red_path)

    nir = nir_raster["data"].astype(np.float64)
    red = red_raster["data"].astype(np.float64)

    # Align shapes if different
    if nir.shape != red.shape:
        from scipy.ndimage import zoom
        factors = (nir.shape[0] / red.shape[0], nir.shape[1] / red.shape[1])
        red = zoom(red, factors, order=1)[:nir.shape[0], :nir.shape[1]]

    # Calculate NDVI
    with np.errstate(divide="ignore", invalid="ignore"):
        ndvi = (nir - red) / (nir + red)
        ndvi = np.nan_to_num(ndvi, nan=-1.0)
        ndvi = np.clip(ndvi, -1.0, 1.0)

    stats = get_raster_stats(ndvi, -1.0)
    write_raster(output_path, ndvi.astype(np.float32), nir_raster["transform"], nir_raster["crs"], -1.0)

    return {
        "ndvi_path": output_path,
        "stats": stats,
        "formula": "NDVI = (NIR - Red) / (NIR + Red)",
    }


def calculate_ndwi(green_path: str, nir_path: str, output_path: str) -> Dict:
    """Calculate NDWI (Normalised Difference Water Index).

    NDWI = (Green - NIR) / (Green + NIR)

    Used for identifying water-related features.

    Returns:
        Dict with NDWI stats and output path
    """
    if not has_rasterio():
        raise ImportError("rasterio is required for NDWI calculation")

    green_raster = read_raster(green_path)
    nir_raster = read_raster(nir_path)

    green = green_raster["data"].astype(np.float64)
    nir = nir_raster["data"].astype(np.float64)

    if green.shape != nir.shape:
        from scipy.ndimage import zoom
        factors = (green.shape[0] / nir.shape[0], green.shape[1] / nir.shape[1])
        nir = zoom(nir, factors, order=1)[:green.shape[0], :green.shape[1]]

    with np.errstate(divide="ignore", invalid="ignore"):
        ndwi = (green - nir) / (green + nir)
        ndwi = np.nan_to_num(ndwi, nan=-1.0)
        ndwi = np.clip(ndwi, -1.0, 1.0)

    stats = get_raster_stats(ndwi, -1.0)
    write_raster(output_path, ndwi.astype(np.float32), green_raster["transform"], green_raster["crs"], -1.0)

    return {
        "ndwi_path": output_path,
        "stats": stats,
        "formula": "NDWI = (Green - NIR) / (Green + NIR)",
    }


def train_lulc_classifier(
    training_samples_path: str,
    satellite_bands_paths: List[str],
    output_dir: str,
) -> Dict:
    """Train a Random Forest LULC classifier from labelled samples.

    This requires:
    - A training samples file (CSV or vector) with coordinates and class labels
    - Satellite imagery bands (GeoTIFF files)

    If no training samples exist, this will return a message explaining
    the workflow for obtaining them.

    Returns:
        Dict with training results or instructions for obtaining training data
    """
    if not has_rasterio():
        raise ImportError("rasterio is required for LULC classification")

    try:
        import pandas as pd
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
        import joblib
    except ImportError as e:
        raise ImportError(f"Required packages missing: {e}")

    # Load training samples
    if training_samples_path.endswith(".csv"):
        df = pd.read_csv(training_samples_path)
    else:
        from app.geospatial.vector_processing import load_vector
        info = load_vector(training_samples_path)
        df = info["gdf"]
        # Extract centroid coordinates
        df["lon"] = df.geometry.centroid.x
        df["lat"] = df.geometry.centroid.y

    # Find coordinate and class columns
    lat_col = next((c for c in df.columns if c.lower() in ("lat", "latitude", "y")), None)
    lon_col = next((c for c in df.columns if c.lower() in ("lon", "lng", "longitude", "x")), None)
    class_col = next((c for c in df.columns if c.lower() in ("class", "lulc_class", "label", "landcover")), None)

    if not all([lat_col, lon_col, class_col]):
        return {
            "status": "failed",
            "message": "Training samples must have latitude, longitude, and class columns",
        }

    # Sample band values at training point locations
    from app.geospatial.raster_processing import sample_raster_at_point

    feature_matrix = []
    labels = []

    for _, row in df.iterrows():
        features = []
        valid = True
        for band_path in satellite_bands_paths:
            val = sample_raster_at_point(band_path, float(row[lon_col]), float(row[lat_col]))
            if val is None:
                valid = False
                break
            features.append(val)

        if valid:
            feature_matrix.append(features)
            labels.append(int(row[class_col]))

    if len(feature_matrix) < 10:
        return {
            "status": "failed",
            "message": f"Only {len(feature_matrix)} valid training samples found. Need at least 10.",
        }

    X = np.array(feature_matrix)
    y = np.array(labels)

    # Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

    # Train Random Forest
    clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    clf.fit(X_train, y_train)

    # Evaluate
    y_pred = clf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, output_dict=True)
    cm = confusion_matrix(y_test, y_pred).tolist()

    # Save model
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    model_path = os.path.join(output_dir, "lulc_rf_model.joblib")
    joblib.dump(clf, model_path)

    return {
        "status": "trained",
        "accuracy": round(accuracy, 4),
        "classification_report": report,
        "confusion_matrix": cm,
        "model_path": model_path,
        "n_samples": len(feature_matrix),
        "n_features": len(satellite_bands_paths),
        "feature_importance": dict(zip(
            [f"band_{i+1}" for i in range(len(satellite_bands_paths))],
            [round(v, 4) for v in clf.feature_importances_]
        )),
    }
