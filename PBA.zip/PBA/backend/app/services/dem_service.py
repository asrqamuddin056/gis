"""DEM (Digital Elevation Model) analysis service.

Handles elevation loading, slope calculation, terrain classification,
and generation of elevation/slope thematic layers.
"""

import os
from pathlib import Path
from typing import Dict, Optional, Tuple
import numpy as np

from app.core.config import settings
from app.geospatial.raster_processing import (
    read_raster, write_raster, create_raster_from_array,
    get_raster_stats, has_rasterio, sample_raster_at_point,
)
from app.geospatial.spatial_analysis import calculate_slope


def process_dem(
    dem_path: str,
    output_dir: str,
    study_area_id: str,
) -> Dict:
    """Process a DEM raster and generate elevation + slope thematic layers.

    Args:
        dem_path: path to the DEM GeoTIFF
        output_dir: directory for output files
        study_area_id: associated study area ID

    Returns:
        Dict with elevation and slope layer info
    """
    if not has_rasterio():
        raise ImportError("rasterio is required for DEM processing")

    # Read DEM
    raster = read_raster(dem_path)
    elevation = raster["data"]
    transform = raster["transform"]
    crs = raster["crs"]
    nodata = raster["nodata"]

    # Calculate statistics
    elev_stats = get_raster_stats(elevation, nodata)

    # Calculate slope
    # Determine pixel size in metres
    if crs and "326" in str(crs):  # UTM — already in metres
        pixel_size_m = abs(transform.a)
    else:
        # WGS84 — convert degrees to metres approximately
        # Average latitude for conversion
        bounds = raster["bounds"]
        avg_lat = (bounds[1] + bounds[3]) / 2
        pixel_size_m = abs(transform.a) * 111000 * np.cos(np.radians(avg_lat))

    slope = calculate_slope(elevation, pixel_size_m, nodata)
    slope_stats = get_raster_stats(slope, nodata)

    # Generate slope classification (degrees → categories)
    slope_classes = np.full(slope.shape, 0, dtype=np.int8)
    valid = slope != nodata if nodata is not None else np.ones_like(slope, dtype=bool)
    slope_classes[valid & (slope < 5)] = 1      # Flat
    slope_classes[valid & (slope >= 5) & (slope < 15)] = 2  # Gentle
    slope_classes[valid & (slope >= 15) & (slope < 30)] = 3  # Moderate
    slope_classes[valid & (slope >= 30)] = 4    # Steep

    # Identify low-elevation regions (below 25th percentile)
    if elev_stats["count"] > 0:
        low_threshold = elev_stats["p25"]
        low_elevation_mask = (elevation < low_threshold) & valid
    else:
        low_elevation_mask = np.zeros_like(elevation, dtype=bool)

    # Write output rasters
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Save slope raster
    slope_path = os.path.join(output_dir, f"slope_{study_area_id}.tif")
    write_raster(slope_path, slope.astype(np.float32), transform, crs, nodata)

    # Save slope classification raster
    slope_class_path = os.path.join(output_dir, f"slope_class_{study_area_id}.tif")
    write_raster(slope_class_path, slope_classes.astype(np.int16), transform, crs, 0)

    # Count low-elevation pixels
    low_elev_count = int(np.sum(low_elevation_mask))

    return {
        "elevation": {
            "stats": elev_stats,
            "file_path": dem_path,
            "crs": crs,
            "nodata": nodata,
        },
        "slope": {
            "stats": slope_stats,
            "file_path": slope_path,
            "crs": crs,
            "nodata": float(nodata) if nodata is not None else None,
            "pixel_size_m": pixel_size_m,
        },
        "slope_classification": {
            "file_path": slope_class_path,
            "classes": {
                "flat": int(np.sum(slope_classes == 1)),
                "gentle": int(np.sum(slope_classes == 2)),
                "moderate": int(np.sum(slope_classes == 3)),
                "steep": int(np.sum(slope_classes == 4)),
            },
        },
        "low_elevation_pixels": low_elev_count,
        "low_elevation_threshold": float(low_threshold) if elev_stats["count"] > 0 else None,
    }


def get_elevation_at_point(dem_path: str, lon: float, lat: float) -> Optional[float]:
    """Get elevation value at a specific point."""
    return sample_raster_at_point(dem_path, lon, lat)


def get_slope_at_point(slope_path: str, lon: float, lat: float) -> Optional[float]:
    """Get slope value at a specific point."""
    return sample_raster_at_point(slope_path, lon, lat)


def generate_elevation_distribution(elevation: np.ndarray, nodata: Optional[float] = None, n_bins: int = 10) -> Dict:
    """Generate elevation distribution histogram data for visualisation."""
    arr = elevation.astype(np.float64)
    if nodata is not None:
        valid = arr[arr != nodata]
    else:
        valid = arr[np.isfinite(arr)]

    if len(valid) == 0:
        return {"bins": [], "counts": []}

    counts, bin_edges = np.histogram(valid, bins=n_bins)
    bins = [round((bin_edges[i] + bin_edges[i + 1]) / 2, 1) for i in range(len(bin_edges) - 1)]

    return {
        "bins": bins,
        "counts": counts.tolist(),
        "min": float(valid.min()),
        "max": float(valid.max()),
        "mean": float(valid.mean()),
    }
