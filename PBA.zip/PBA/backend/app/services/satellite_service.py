"""Satellite imagery processing service.

Handles satellite imagery loading, preprocessing, cloud masking,
spectral index calculation (NDVI, NDWI), and imagery clipping.

When Google Earth Engine credentials are not configured, the system
supports local satellite imagery uploads instead of pretending to
retrieve imagery from external services.
"""

import os
import json
from pathlib import Path
from typing import Dict, Optional, List
import numpy as np

from app.core.config import settings
from app.geospatial.raster_processing import (
    read_raster, write_raster, get_raster_stats, has_rasterio,
)


def is_gee_available() -> bool:
    """Check if Google Earth Engine is configured."""
    return bool(settings.GEE_PROJECT_ID and settings.GEE_SERVICE_ACCOUNT and settings.GEE_PRIVATE_KEY)


def get_satellite_info() -> Dict:
    """Return information about the satellite imagery source."""
    if is_gee_available():
        return {
            "source": "Google Earth Engine",
            "imagery": "Sentinel-2",
            "status": "configured",
            "project_id": settings.GEE_PROJECT_ID,
        }
    return {
        "source": "Upload-based (local satellite imagery)",
        "imagery": "User-uploaded GeoTIFF bands",
        "status": "upload_mode",
        "note": "Google Earth Engine is not configured. Upload satellite imagery "
                "through the Dataset Management interface to use satellite analysis features.",
    }


def process_satellite_imagery(
    band_paths: Dict[str, str],
    study_area_geojson: Optional[Dict] = None,
    output_dir: str = "./output",
) -> Dict:
    """Process satellite imagery bands and calculate spectral indices.

    Args:
        band_paths: dict of {band_name: file_path} e.g. {"red": "...", "nir": "...", "green": "..."}
        study_area_geojson: optional study area boundary for clipping
        output_dir: directory for outputs

    Returns:
        Dict with band info, spectral indices, and metadata
    """
    if not has_rasterio():
        raise ImportError("rasterio is required for satellite imagery processing")

    Path(output_dir).mkdir(parents=True, exist_ok=True)

    results = {
        "bands": {},
        "indices": {},
        "note": "Satellite imagery processed from uploaded files.",
    }

    # Read each band
    band_data = {}
    ref_transform = None
    ref_crs = None
    ref_shape = None

    for band_name, band_path in band_paths.items():
        if not os.path.exists(band_path):
            results["bands"][band_name] = {"error": f"File not found: {band_path}"}
            continue

        try:
            raster = read_raster(band_path)
            band_data[band_name] = raster["data"]
            if ref_transform is None:
                ref_transform = raster["transform"]
                ref_crs = raster["crs"]
                ref_shape = raster["data"].shape

            stats = get_raster_stats(raster["data"], raster["nodata"])
            results["bands"][band_name] = {
                "file_path": band_path,
                "stats": stats,
                "crs": raster["crs"],
                "width": raster["width"],
                "height": raster["height"],
            }
        except Exception as e:
            results["bands"][band_name] = {"error": str(e)}

    # Calculate NDVI if NIR and Red are available
    if "nir" in band_data and "red" in band_data:
        from app.services.lulc_service import calculate_ndvi
        try:
            ndvi_path = os.path.join(output_dir, "ndvi.tif")
            ndvi_result = calculate_ndvi(band_paths["nir"], band_paths["red"], ndvi_path)
            results["indices"]["ndvi"] = ndvi_result
        except Exception as e:
            results["indices"]["ndvi"] = {"error": str(e)}

    # Calculate NDWI if Green and NIR are available
    if "green" in band_data and "nir" in band_data:
        from app.services.lulc_service import calculate_ndwi
        try:
            ndwi_path = os.path.join(output_dir, "ndwi.tif")
            ndwi_result = calculate_ndwi(band_paths["green"], band_paths["nir"], ndwi_path)
            results["indices"]["ndwi"] = ndwi_result
        except Exception as e:
            results["indices"]["ndwi"] = {"error": str(e)}

    return results


def clip_imagery_to_boundary(
    raster_path: str,
    boundary_geojson: Dict,
    output_path: str,
) -> str:
    """Clip a raster to a study area boundary polygon."""
    if not has_rasterio():
        raise ImportError("rasterio is required for clipping")

    try:
        import geopandas as gpd
        from rasterio.mask import mask as rasterio_mask
        import rasterio

        # Load boundary
        gdf = gpd.GeoDataFrame.from_features(boundary_geojson["features"] if "features" in boundary_geojson else [boundary_geojson])

        with rasterio.open(raster_path) as src:
            # Reproject boundary to raster CRS if needed
            if gdf.crs and str(gdf.crs) != str(src.crs):
                gdf = gdf.to_crs(src.crs)

            out_image, out_transform = rasterio_mask(src, gdf.geometry, crop=True)
            out_meta = src.meta.copy()
            out_meta.update({
                "height": out_image.shape[1],
                "width": out_image.shape[2],
                "transform": out_transform,
            })

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with rasterio.open(output_path, "w", **out_meta) as dst:
            dst.write(out_image)

        return output_path
    except Exception as e:
        raise RuntimeError(f"Failed to clip imagery: {e}")


def apply_cloud_mask(
    raster_path: str,
    qa_path: str,
    output_path: str,
    cloud_threshold: int = 1024,
) -> Dict:
    """Apply cloud masking using a QA band.

    Pixels where the QA band value exceeds the threshold are masked.

    Returns:
        Dict with output path and masked pixel statistics
    """
    if not has_rasterio():
        raise ImportError("rasterio is required for cloud masking")

    main_raster = read_raster(raster_path)
    qa_raster = read_raster(qa_path)

    data = main_raster["data"].astype(np.float32)
    qa = qa_raster["data"]

    # Align shapes
    if qa.shape != data.shape:
        from scipy.ndimage import zoom
        factors = (data.shape[0] / qa.shape[0], data.shape[1] / qa.shape[1])
        qa = zoom(qa, factors, order=0)[:data.shape[0], :data.shape[1]]

    # Mask cloudy pixels
    cloud_mask = qa > cloud_threshold
    masked_count = int(np.sum(cloud_mask))

    data[cloud_mask] = main_raster["nodata"] if main_raster["nodata"] is not None else -1

    write_raster(output_path, data, main_raster["transform"], main_raster["crs"], main_raster["nodata"])

    total_pixels = data.size
    return {
        "output_path": output_path,
        "masked_pixels": masked_count,
        "total_pixels": int(total_pixels),
        "cloud_coverage_pct": round(masked_count / total_pixels * 100, 2) if total_pixels > 0 else 0,
    }
