"""Dataset management service — handles uploads, validation, metadata."""

import os
import json
import shutil
import uuid
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Dict, List, Any, Tuple

from sqlalchemy import select, func, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.dataset import Dataset, DatasetMetadata
from app.schemas.dataset import DatasetCreate, DatasetValidationResult, DatasetResponse

# Allowed file extensions by data type
ALLOWED_EXTENSIONS = {
    "raster": {".tif", ".tiff"},
    "vector": {".geojson", ".json", ".shp", ".gpkg", ".kml"},
    "csv": {".csv"},
    "rainfall": {".csv", ".tif", ".tiff"},
    "flood_record": {".csv", ".geojson", ".json"},
    "satellite": {".tif", ".tiff"},
}


def get_file_extension(filename: str) -> str:
    """Return lowercase file extension including the dot."""
    return Path(filename).suffix.lower()


def validate_file_extension(filename: str, data_type: str) -> Tuple[bool, str]:
    """Validate that a file extension is allowed for the given data type."""
    ext = get_file_extension(filename)
    allowed = ALLOWED_EXTENSIONS.get(data_type, set())

    # For shapefiles, .shp requires companion files
    if not allowed:
        return False, f"Unknown data type: {data_type}"

    if ext not in allowed:
        return False, f"Extension {ext} not allowed for data type '{data_type}'. Allowed: {', '.join(allowed)}"

    return True, ""


def validate_file_size(file_size: int) -> Tuple[bool, str]:
    """Validate file size against the configured maximum."""
    if file_size > settings.max_file_size_bytes:
        return False, f"File size {file_size / 1024 / 1024:.1f} MB exceeds maximum of {settings.MAX_FILE_SIZE_MB} MB"
    return True, ""


def save_uploaded_file(file_content: bytes, filename: str, data_type: str) -> str:
    """Save an uploaded file to the upload directory.

    Returns the relative file path.
    """
    ext = get_file_extension(filename)
    unique_name = f"{uuid.uuid4().hex}{ext}"
    file_path = settings.upload_path / unique_name

    with open(file_path, "wb") as f:
        f.write(file_content)

    return str(file_path)


def validate_csv_geospatial(file_path: str) -> DatasetValidationResult:
    """Validate a CSV file with geographical coordinates."""
    import pandas as pd

    errors = []
    warnings = []

    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        return DatasetValidationResult(
            valid=False,
            errors=[f"Could not read CSV: {str(e)}"],
        )

    # Check for coordinate columns
    lat_cols = [c for c in df.columns if c.lower() in ("lat", "latitude", "y")]
    lon_cols = [c for c in df.columns if c.lower() in ("lon", "lng", "longitude", "x")]

    if not lat_cols or not lon_cols:
        errors.append("CSV must contain latitude and longitude columns (lat/latitude/y and lon/lng/longitude/x)")
    else:
        lat_col = lat_cols[0]
        lon_col = lon_cols[0]

        # Check for invalid coordinates
        lats = pd.to_numeric(df[lat_col], errors="coerce")
        lons = pd.to_numeric(df[lon_col], errors="coerce")

        null_count = lats.isna().sum() + lons.isna().sum()
        if null_count > 0:
            warnings.append(f"{null_count} rows have invalid (non-numeric) coordinates")

        valid_lats = lats.dropna()
        valid_lons = lons.dropna()

        if len(valid_lats) > 0:
            if valid_lats.min() < -90 or valid_lats.max() > 90:
                errors.append(f"Latitude values out of range [-90, 90]: min={valid_lats.min()}, max={valid_lats.max()}")
            if valid_lons.min() < -180 or valid_lons.max() > 180:
                errors.append(f"Longitude values out of range [-180, 180]: min={valid_lons.min()}, max={valid_lons.max()}")

        # Check for duplicates
        dup_count = df.duplicated(subset=[lat_col, lon_col]).sum()
        if dup_count > 0:
            warnings.append(f"{dup_count} duplicate coordinate pairs found")

    # Check for missing values in general
    null_total = df.isnull().sum().sum()
    if null_total > 0:
        warnings.append(f"{null_total} total missing values across all columns")

    metadata = {
        "row_count": len(df),
        "columns": list(df.columns),
        "has_coordinates": bool(lat_cols and lon_cols),
    }

    return DatasetValidationResult(
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        metadata=metadata,
    )


def validate_raster_file(file_path: str) -> DatasetValidationResult:
    """Validate a raster (GeoTIFF) file."""
    errors = []
    warnings = []
    metadata = {}

    try:
        from app.geospatial.raster_processing import read_raster, get_raster_stats
        from app.geospatial.coordinate_systems import get_crs_info

        raster = read_raster(file_path)
        stats = get_raster_stats(raster["data"], raster["nodata"])

        metadata = {
            "width": raster["width"],
            "height": raster["height"],
            "crs": raster["crs"],
            "bounds": list(raster["bounds"]),
            "dtype": raster["dtype"],
            "nodata": raster["nodata"],
            "stats": stats,
        }

        # Check for all-nodata
        if stats["count"] == 0:
            errors.append("Raster contains only NoData values")

        # Check for very large nodata ratio
        total_pixels = raster["width"] * raster["height"]
        if total_pixels > 0 and stats["nodata_count"] / total_pixels > 0.5:
            warnings.append(f"{stats['nodata_count'] / total_pixels * 100:.1f}% of pixels are NoData")

        # Check CRS
        if not raster["crs"] or raster["crs"] == "None":
            warnings.append("Raster has no coordinate reference system defined")

    except ImportError:
        warnings.append("rasterio not available — raster validation limited to file existence check")
        if not Path(file_path).exists():
            errors.append("File does not exist")
    except Exception as e:
        errors.append(f"Could not read raster: {str(e)}")

    return DatasetValidationResult(
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        metadata=metadata,
    )


def validate_vector_file(file_path: str) -> DatasetValidationResult:
    """Validate a vector (GeoJSON/shapefile) file."""
    errors = []
    warnings = []
    metadata = {}

    if file_path.endswith(".geojson") or file_path.endswith(".json"):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                geojson = json.load(f)

            from app.geospatial.vector_processing import validate_geojson
            is_valid, geom_errors = validate_geojson(geojson)

            if not is_valid:
                errors.extend(geom_errors)

            # Count features
            if geojson.get("type") == "FeatureCollection":
                metadata["feature_count"] = len(geojson.get("features", []))
            elif geojson.get("type") == "Feature":
                metadata["feature_count"] = 1
            else:
                metadata["feature_count"] = 0

        except json.JSONDecodeError as e:
            errors.append(f"Invalid JSON: {str(e)}")
        except Exception as e:
            errors.append(f"Could not read file: {str(e)}")

    elif file_path.endswith(".shp"):
        try:
            from app.geospatial.vector_processing import load_vector
            info = load_vector(file_path)
            metadata = {
                "feature_count": info["feature_count"],
                "crs": info["crs"],
                "geometry_type": info["geometry_type"],
                "bounds": info["bounds"],
                "columns": info["columns"],
            }

            # Check for companion files
            base = Path(file_path).stem
            d = Path(file_path).parent
            for ext in [".dbf", ".shx", ".prj"]:
                if not (d / f"{base}{ext}").exists():
                    warnings.append(f"Missing shapefile component: {base}{ext}")

        except ImportError:
            warnings.append("geopandas not available — vector validation limited")
        except Exception as e:
            errors.append(f"Could not read shapefile: {str(e)}")

    return DatasetValidationResult(
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        metadata=metadata,
    )


def validate_dataset(file_path: str, data_type: str) -> DatasetValidationResult:
    """Validate a dataset file based on its type."""
    if not Path(file_path).exists():
        return DatasetValidationResult(
            valid=False,
            errors=["File does not exist"],
        )

    if data_type in ("raster", "satellite"):
        return validate_raster_file(file_path)
    elif data_type in ("vector",):
        return validate_vector_file(file_path)
    elif data_type == "rainfall":
        # Rainfall can be CSV or raster — check by extension
        if file_path.endswith((".tif", ".tiff")):
            return validate_raster_file(file_path)
        else:
            return validate_csv_geospatial(file_path)
    elif data_type in ("csv", "flood_record"):
        return validate_csv_geospatial(file_path)
    else:
        # Generic validation — just check file exists
        return DatasetValidationResult(
            valid=True,
            warnings=["Unknown data type — minimal validation performed"],
        )


async def create_dataset_record(
    db: AsyncSession,
    name: str,
    description: str,
    data_type: str,
    source: str,
    file_path: str,
    original_filename: str,
    file_size: int,
    study_area_id: Optional[str] = None,
    is_sample_data: bool = False,
) -> Dataset:
    """Create a new dataset record in the database."""
    dataset = Dataset(
        name=name,
        description=description,
        data_type=data_type,
        source=source,
        file_path=file_path,
        original_filename=original_filename,
        file_size_bytes=file_size,
        study_area_id=study_area_id,
        is_sample_data=is_sample_data,
        processing_status="pending",
        validation_status="pending",
    )
    db.add(dataset)
    await db.flush()
    return dataset


async def update_dataset_validation(
    db: AsyncSession,
    dataset_id: str,
    validation_result: DatasetValidationResult,
    metadata: Optional[Dict] = None,
) -> Dataset:
    """Update a dataset's validation status and metadata."""
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise ValueError(f"Dataset {dataset_id} not found")

    dataset.validation_status = "valid" if validation_result.valid else "invalid"
    dataset.validation_errors = json.dumps({
        "errors": validation_result.errors,
        "warnings": validation_result.warnings,
    })
    dataset.processing_status = "completed"

    # Store metadata
    if metadata:
        for key, value in metadata.items():
            db.add(DatasetMetadata(
                dataset_id=dataset_id,
                key=key,
                value=str(value),
            ))

    dataset.processed_at = datetime.now(timezone.utc)
    await db.flush()
    return dataset


async def get_datasets(
    db: AsyncSession,
    study_area_id: Optional[str] = None,
    data_type: Optional[str] = None,
) -> List[Dataset]:
    """Get datasets, optionally filtered by study area or data type."""
    query = select(Dataset).order_by(Dataset.uploaded_at.desc())

    if study_area_id:
        query = query.where(Dataset.study_area_id == study_area_id)
    if data_type:
        query = query.where(Dataset.data_type == data_type)

    result = await db.execute(query)
    return list(result.scalars().all())


async def get_dataset_stats(db: AsyncSession) -> Dict:
    """Get dataset statistics for the dashboard."""
    total = await db.scalar(select(func.count(Dataset.id)))
    valid = await db.scalar(select(func.count(Dataset.id)).where(Dataset.validation_status == "valid"))
    invalid = await db.scalar(select(func.count(Dataset.id)).where(Dataset.validation_status == "invalid"))

    # Count by type
    type_query = select(Dataset.data_type, func.count(Dataset.id)).group_by(Dataset.data_type)
    type_result = await db.execute(type_query)
    by_type = {row[0]: row[1] for row in type_result}

    # Count by status
    status_query = select(Dataset.processing_status, func.count(Dataset.id)).group_by(Dataset.processing_status)
    status_result = await db.execute(status_query)
    by_status = {row[0]: row[1] for row in status_result}

    return {
        "total_datasets": total or 0,
        "by_type": by_type,
        "by_status": by_status,
        "valid_datasets": valid or 0,
        "invalid_datasets": invalid or 0,
    }
