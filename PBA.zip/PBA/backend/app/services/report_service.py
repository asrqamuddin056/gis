"""Report generation service.

Generates professional flood risk assessment reports in:
- PDF format (using reportlab)
- CSV export
- GeoJSON export
- Analysis summary

Reports use actual analysis results — no fabricated data.
"""

import os
import json
import csv
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Optional
import numpy as np

from app.core.config import settings


def generate_pdf_report(
    assessment_data: Dict,
    study_area_info: Dict,
    output_path: str,
    ml_results: Optional[Dict] = None,
) -> str:
    """Generate a professional PDF flood risk assessment report.

    Uses reportlab to create a structured document.

    Args:
        assessment_data: results from weighted overlay analysis
        study_area_info: study area metadata
        output_path: output PDF file path
        ml_results: optional ML evaluation results

    Returns:
        Path to the generated PDF
    """
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm, mm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        PageBreak, Image,
    )
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        rightMargin=2 * cm, leftMargin=2 * cm,
        topMargin=2 * cm, bottomMargin=2 * cm,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "CustomTitle", parent=styles["Title"],
        fontSize=18, spaceAfter=20, alignment=TA_CENTER,
        textColor=colors.HexColor("#1e3a5f"),
    )
    heading_style = ParagraphStyle(
        "CustomHeading", parent=styles["Heading1"],
        fontSize=14, spaceAfter=10, spaceBefore=15,
        textColor=colors.HexColor("#1e3a5f"),
    )
    body_style = ParagraphStyle(
        "CustomBody", parent=styles["Normal"],
        fontSize=10, spaceAfter=8, alignment=TA_JUSTIFY, leading=14,
    )

    story = []

    # --- Title Page ---
    story.append(Spacer(1, 3 * cm))
    story.append(Paragraph("Intelligent Urban Flood Risk<br/>Assessment and Prediction System", title_style))
    story.append(Spacer(1, 1 * cm))
    story.append(Paragraph(f"<b>Study Area:</b> {study_area_info.get('name', 'N/A')}", body_style))
    story.append(Paragraph(f"<b>Assessment Date:</b> {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}", body_style))
    story.append(Paragraph(f"<b>Method:</b> {assessment_data.get('method', 'Weighted Overlay Analysis')}", body_style))
    story.append(Paragraph(f"<b>Assessment Name:</b> {assessment_data.get('name', 'Flood Risk Assessment')}", body_style))
    story.append(Spacer(1, 2 * cm))
    story.append(Paragraph("This report was generated automatically by the Intelligent Urban Flood Risk Assessment System. "
                           "All statistics and results are derived from actual geospatial analysis.", body_style))
    story.append(PageBreak())

    # --- 1. Abstract ---
    story.append(Paragraph("1. Abstract", heading_style))
    story.append(Paragraph(
        "This report presents the results of a GIS-based flood susceptibility assessment for "
        f"{study_area_info.get('name', 'the study area')}. The assessment uses a Weighted Overlay "
        "Analysis approach, integrating multiple environmental and geographical factors including "
        "elevation, slope, rainfall, land use/land cover, drainage proximity, and built-up density. "
        "The study area was classified into Low, Medium, High, and Very High flood risk categories "
        "based on a computed Flood Risk Index (FRI).", body_style))

    # --- 2. Study Area Description ---
    story.append(Paragraph("2. Study Area Description", heading_style))
    study_area_table = Table([
        ["Parameter", "Value"],
        ["Name", study_area_info.get("name", "N/A")],
        ["Location", study_area_info.get("location_label", "N/A")],
        ["Area (km²)", f"{study_area_info.get('area_km2', 0):.2f}"],
        ["Bounding Box", f"{study_area_info.get('bbox_min_lon', 0):.4f}, {study_area_info.get('bbox_min_lat', 0):.4f} to "
                        f"{study_area_info.get('bbox_max_lon', 0):.4f}, {study_area_info.get('bbox_max_lat', 0):.4f}"],
        ["Analysis CRS", str(study_area_info.get("analysis_crs", "EPSG:32644"))],
    ], colWidths=[5 * cm, 11 * cm])
    study_area_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e3a5f")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ]))
    story.append(study_area_table)
    story.append(Spacer(1, 0.5 * cm))

    # --- 3. Methodology ---
    story.append(Paragraph("3. Methodology", heading_style))
    story.append(Paragraph(
        "The flood susceptibility assessment was conducted using GIS-based Weighted Overlay Analysis. "
        "Each contributing factor was normalised to a 1–5 risk scale, and weights were assigned based on "
        "their relative importance to flood susceptibility. The Flood Risk Index (FRI) was computed as:", body_style))
    story.append(Paragraph("<b>FRI = Σ (Wi × Ri)</b>", ParagraphStyle("Formula", parent=body_style, alignment=TA_CENTER, fontSize=12)))
    story.append(Paragraph("Where Wi is the weight assigned to the i-th factor and Ri is the normalised risk score.", body_style))

    # --- 4. Weight Assignment ---
    story.append(Paragraph("4. Weight Assignment", heading_style))
    weights = assessment_data.get("weights", {})
    if weights:
        weight_data = [["Factor", "Weight"]]
        for factor, weight in weights.items():
            weight_data.append([factor.replace("_", " ").title(), f"{weight * 100:.0f}%"])
        weight_data.append(["Total", "100%"])
        weight_table = Table(weight_data, colWidths=[8 * cm, 8 * cm])
        weight_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e3a5f")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(weight_table)
        story.append(Paragraph(
            "<i>Note: These weights are illustrative initial values and should be validated with "
            "domain expertise. They are not universally established scientific constants.</i>", body_style))

    # --- 5. Risk Classification ---
    story.append(Paragraph("5. Risk Classification", heading_style))
    thresholds = assessment_data.get("thresholds", {})
    story.append(Paragraph(
        f"The FRI values were classified into four risk categories using the following thresholds "
        f"(on a 1–5 scale): Low (&lt; {thresholds.get('low', 2.0)}), "
        f"Medium ({thresholds.get('low', 2.0)}–{thresholds.get('medium', 3.0)}), "
        f"High ({thresholds.get('medium', 3.0)}–{thresholds.get('high', 4.0)}), "
        f"Very High (≥ {thresholds.get('high', 4.0)}).", body_style))

    # --- 6. Statistical Results ---
    story.append(Paragraph("6. Statistical Results", heading_style))
    area_by_cat = assessment_data.get("area_by_category", {})
    risk_dist = assessment_data.get("risk_distribution", {})

    if area_by_cat or risk_dist:
        stats_data = [["Risk Category", "Pixel Count", "Area (km²)"]]
        for cat in ["Low", "Medium", "High", "Very High"]:
            stats_data.append([
                cat,
                str(risk_dist.get(cat, 0)),
                f"{area_by_cat.get(cat, 0):.4f}",
            ])
        stats_table = Table(stats_data, colWidths=[5 * cm, 5 * cm, 6 * cm])
        stats_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e3a5f")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(stats_table)

        story.append(Paragraph(f"<b>High Risk Percentage:</b> {assessment_data.get('high_risk_percentage', 0):.2f}%", body_style))

    # --- 7. ML Results (if available) ---
    if ml_results and ml_results.get("status") == "trained":
        story.append(Paragraph("7. Machine Learning Evaluation", heading_style))
        ml_data = [
            ["Metric", "Value"],
            ["Algorithm", ml_results.get("algorithm", "N/A")],
            ["Accuracy", f"{ml_results.get('accuracy', 0):.4f}"],
            ["Precision", f"{ml_results.get('precision', 0):.4f}"],
            ["Recall", f"{ml_results.get('recall', 0):.4f}"],
            ["F1-Score", f"{ml_results.get('f1_score', 0):.4f}"],
            ["ROC-AUC", f"{ml_results.get('roc_auc', 0):.4f}"],
            ["Validation Strategy", ml_results.get("validation_strategy", "N/A")],
        ]
        ml_table = Table(ml_data, colWidths=[5 * cm, 11 * cm])
        ml_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e3a5f")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(ml_table)

        if ml_results.get("feature_importance"):
            story.append(Paragraph("<b>Feature Importance:</b>", body_style))
            fi_data = [["Feature", "Importance"]]
            for feat, imp in list(ml_results["feature_importance"].items())[:10]:
                fi_data.append([feat, f"{imp:.4f}"])
            fi_table = Table(fi_data, colWidths=[8 * cm, 8 * cm])
            fi_table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e3a5f")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ]))
            story.append(fi_table)

    # --- 8. Limitations ---
    story.append(Paragraph("8. Limitations", heading_style))
    limitations = [
        "This assessment is a susceptibility analysis, not a real-time flood forecast.",
        "Results depend on the quality and resolution of input datasets.",
        "The weights used are illustrative and should be validated with domain expertise.",
        "Proximity to drainage does not prove drainage capacity or failure.",
        "Low elevation alone does not guarantee flooding; multiple factors interact.",
        "Machine learning results require sufficient labelled historical flood data for reliability.",
    ]
    for lim in limitations:
        story.append(Paragraph(f"• {lim}", body_style))

    # --- 9. Recommendations ---
    story.append(Paragraph("9. Recommendations", heading_style))
    recommendations = [
        "Use this assessment alongside field surveys and local knowledge for planning decisions.",
        "Regularly update input datasets, especially rainfall and LULC data.",
        "Validate and refine factor weights with local flood experts.",
        "Consider integrating real-time weather data for operational flood warning.",
        "Use the machine learning module when sufficient historical flood records become available.",
        "Investigate areas classified as Very High risk for detailed flood mitigation planning.",
    ]
    for rec in recommendations:
        story.append(Paragraph(f"• {rec}", body_style))

    # --- 10. Conclusion ---
    story.append(Paragraph("10. Conclusion", heading_style))
    story.append(Paragraph(
        f"The flood susceptibility assessment for {study_area_info.get('name', 'the study area')} was completed "
        f"using GIS-based Weighted Overlay Analysis. The study area was classified into risk categories "
        f"based on the computed Flood Risk Index. {assessment_data.get('high_risk_percentage', 0):.1f}% of the "
        f"analysed area was classified as High or Very High risk. This assessment provides a baseline "
        f"for urban flood risk management and should be refined with additional data and domain expertise.",
        body_style))

    story.append(Spacer(1, 1 * cm))
    story.append(Paragraph(
        f"<i>Generated on {datetime.now(timezone.utc).strftime('%Y-%m-%d at %H:%M UTC')} "
        f"by the Intelligent Urban Flood Risk Assessment System.</i>", body_style))

    doc.build(story)
    return output_path


def export_csv(
    data: Dict,
    output_path: str,
) -> str:
    """Export assessment statistics to CSV."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Parameter", "Value"])

        # Basic info
        for key in ["name", "method", "status"]:
            writer.writerow([key, data.get(key, "")])

        # Statistics
        stats = data.get("statistics", {})
        for key, value in stats.items():
            writer.writerow([f"stats_{key}", value])

        # Area by category
        area = data.get("area_by_category", {})
        for cat, val in area.items():
            writer.writerow([f"area_{cat}", val])

        # Risk distribution
        dist = data.get("risk_distribution", {})
        for cat, count in dist.items():
            writer.writerow([f"count_{cat}", count])

        # Weights
        weights = data.get("weights", {})
        for factor, weight in weights.items():
            writer.writerow([f"weight_{factor}", weight])

    return output_path


def export_summary_json(
    assessment_data: Dict,
    study_area_info: Dict,
    output_path: str,
) -> str:
    """Export a complete analysis summary as JSON."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    summary = {
        "report_title": "Flood Risk Assessment Summary",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "study_area": study_area_info,
        "assessment": assessment_data,
        "system": "Intelligent Urban Flood Risk Assessment System",
        "version": "1.0.0",
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)

    return output_path
