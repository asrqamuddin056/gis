"""Machine learning service for flood susceptibility prediction.

Implements training, evaluation, and prediction using:
- Random Forest
- XGBoost (where available)
- Logistic Regression (baseline)

Key design decisions:
- Uses spatially separated validation to avoid spatial data leakage
- Handles class imbalance
- Only works when labelled historical flood data is available
- Does NOT manufacture accuracy results

If no labelled data exists, the ML module returns a clear message
explaining that labelled data is required.
"""

import os
import json
from pathlib import Path
from typing import Dict, Optional, List, Tuple
import numpy as np

from app.core.config import settings


def prepare_ml_dataset(
    flood_csv_path: str,
    layer_paths: Optional[Dict[str, str]] = None,
) -> Dict:
    """Prepare a dataset for ML training from flood occurrence CSV.

    The CSV should contain coordinates and a flood_label column (0/1).
    Additional features (elevation, slope, rainfall, etc.) can either be
    in the CSV directly or sampled from raster layers.

    Returns:
        Dict with X (features), y (labels), feature_names
    """
    import pandas as pd

    df = pd.read_csv(flood_csv_path)

    # Find label column
    label_col = None
    for c in df.columns:
        if c.lower() in ("flood_label", "label", "target", "flood", "flooded", "class"):
            label_col = c
            break

    if label_col is None:
        raise ValueError("Flood occurrence CSV must contain a label column (flood_label, label, target, etc.)")

    y = df[label_col].astype(int).values

    # Feature columns — use all numeric columns except the label and coordinates
    exclude = {label_col.lower(), "lat", "latitude", "lon", "lng", "longitude", "x", "y"}
    feature_cols = [c for c in df.columns if c.lower() not in exclude and df[c].dtype in ("int64", "float64", "float32", "int32")]

    if not feature_cols:
        raise ValueError("No numeric feature columns found in the dataset")

    X = df[feature_cols].values.astype(np.float64)

    # Handle missing values
    nan_mask = np.isnan(X)
    if nan_mask.any():
        # Fill with column median
        for col_idx in range(X.shape[1]):
            col = X[:, col_idx]
            col_valid = col[~np.isnan(col)]
            if len(col_valid) > 0:
                median = np.median(col_valid)
                col[nan_mask[:, col_idx]] = median
            else:
                col[nan_mask[:, col_idx]] = 0

    return {
        "X": X,
        "y": y,
        "feature_names": feature_cols,
        "n_samples": len(X),
        "n_features": X.shape[1],
        "class_distribution": {
            "non_flood": int(np.sum(y == 0)),
            "flood": int(np.sum(y == 1)),
        },
    }


def spatial_train_test_split(
    X: np.ndarray,
    y: np.ndarray,
    lons: np.ndarray,
    lats: np.ndarray,
    test_size: float = 0.3,
    random_state: int = 42,
) -> Tuple:
    """Split data spatially to avoid spatial data leakage.

    Uses a simple east-west split: the western portion is training,
    the eastern portion is testing. This ensures spatial separation.

    Returns (X_train, X_test, y_train, y_test)
    """
    rng = np.random.default_rng(random_state)

    # Determine split longitude (median of all longitudes)
    split_lon = np.median(lons)

    # Add some randomness to the split
    lon_range = lons.max() - lons.min()
    split_lon += rng.uniform(-0.1, 0.1) * lon_range

    # West = training, East = testing
    train_mask = lons <= split_lon
    test_mask = lons > split_lon

    # Ensure both sets have both classes
    if np.sum(train_mask) == 0 or np.sum(test_mask) == 0:
        # Fall back to random split if spatial split doesn't work
        from sklearn.model_selection import train_test_split
        return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)

    X_train, X_test = X[train_mask], X[test_mask]
    y_train, y_test = y[train_mask], y[test_mask]

    # Ensure both classes present in training
    if len(np.unique(y_train)) < 2:
        from sklearn.model_selection import train_test_split
        return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)

    return X_train, X_test, y_train, y_test


def train_model(
    dataset_path: str,
    algorithm: str = "random_forest",
    test_size: float = 0.3,
    random_state: int = 42,
    hyperparameters: Optional[Dict] = None,
    output_dir: str = "./output",
    model_id: str = "ml_model",
    use_spatial_split: bool = True,
) -> Dict:
    """Train an ML model for flood susceptibility prediction.

    Args:
        dataset_path: path to flood occurrence CSV
        algorithm: random_forest, xgboost, or logistic_regression
        test_size: fraction for testing
        random_state: random seed
        hyperparameters: model-specific hyperparameters
        output_dir: directory for model output
        model_id: unique model identifier
        use_spatial_split: use spatially separated validation

    Returns:
        Dict with training results, evaluation metrics, feature importance
    """
    import pandas as pd
    import joblib
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score, f1_score,
        roc_auc_score, confusion_matrix, classification_report,
    )

    # Prepare dataset
    data = prepare_ml_dataset(dataset_path)
    X = data["X"]
    y = data["y"]
    feature_names = data["feature_names"]

    # Check for class imbalance
    n_flood = int(np.sum(y == 1))
    n_non_flood = int(np.sum(y == 0))

    if n_flood == 0 or n_non_flood == 0:
        return {
            "status": "failed",
            "message": "Dataset must contain both flood and non-flood samples. "
                       f"Found: {n_flood} flood, {n_non_flood} non-flood.",
        }

    if len(X) < 20:
        return {
            "status": "failed",
            "message": f"Only {len(X)} samples. Need at least 20 for meaningful training.",
        }

    # Load coordinates for spatial split
    df = pd.read_csv(dataset_path)
    lat_col = next((c for c in df.columns if c.lower() in ("lat", "latitude")), None)
    lon_col = next((c for c in df.columns if c.lower() in ("lon", "lng", "longitude")), None)

    # Split data
    if use_spatial_split and lon_col and lat_col:
        lons = df[lon_col].values
        lats = df[lat_col].values
        X_train, X_test, y_train, y_test = spatial_train_test_split(
            X, y, lons, lats, test_size, random_state
        )
        split_strategy = "spatially_separated (west=train, east=test)"
    else:
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )
        split_strategy = "random_stratified"

    # Handle class imbalance with class weights
    n_total = len(y_train)
    weight_flood = n_total / (2 * n_flood) if n_flood > 0 else 1
    weight_non_flood = n_total / (2 * n_non_flood) if n_non_flood > 0 else 1
    class_weights = {0: weight_non_flood, 1: weight_flood}

    # Initialize model
    if hyperparameters is None:
        hyperparameters = {}

    if algorithm == "random_forest":
        from sklearn.ensemble import RandomForestClassifier
        n_estimators = hyperparameters.get("n_estimators", 100)
        max_depth = hyperparameters.get("max_depth", 10)
        model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=random_state,
            class_weight=class_weights,
            n_jobs=-1,
        )
    elif algorithm == "xgboost":
        try:
            import xgboost as xgb
            scale_pos_weight = weight_flood / weight_non_flood if weight_non_flood > 0 else 1
            model = xgb.XGBClassifier(
                n_estimators=hyperparameters.get("n_estimators", 100),
                max_depth=hyperparameters.get("max_depth", 6),
                learning_rate=hyperparameters.get("learning_rate", 0.1),
                random_state=random_state,
                scale_pos_weight=scale_pos_weight,
                use_label_encoder=False,
                eval_metric="logloss",
            )
        except ImportError:
            # Fall back to random forest
            from sklearn.ensemble import RandomForestClassifier
            model = RandomForestClassifier(
                n_estimators=100, max_depth=10, random_state=random_state,
                class_weight=class_weights, n_jobs=-1,
            )
            algorithm = "random_forest (xgboost unavailable, falling back)"
    elif algorithm == "logistic_regression":
        from sklearn.linear_model import LogisticRegression
        model = LogisticRegression(
            max_iter=1000,
            class_weight=class_weights,
            random_state=random_state,
        )
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}. Use random_forest, xgboost, or logistic_regression")

    # Train
    model.fit(X_train, y_train)

    # Predict
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else y_pred

    # Evaluate
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)

    try:
        roc_auc = roc_auc_score(y_test, y_proba)
    except Exception:
        roc_auc = 0.0

    cm = confusion_matrix(y_test, y_pred).tolist()
    report = classification_report(y_test, y_pred, output_dict=True, zero_division=0)

    # Feature importance
    feature_importance = {}
    if hasattr(model, "feature_importances_"):
        feature_importance = dict(zip(feature_names, [round(float(v), 4) for v in model.feature_importances_]))
        feature_importance = dict(sorted(feature_importance.items(), key=lambda x: x[1], reverse=True))
    elif hasattr(model, "coef_"):
        feature_importance = dict(zip(feature_names, [round(float(v), 4) for v in model.coef_[0]]))

    # Save model
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    model_path = os.path.join(output_dir, f"{model_id}.joblib")
    joblib.dump(model, model_path)

    return {
        "status": "trained",
        "algorithm": algorithm,
        "n_samples": len(X),
        "n_train": len(X_train),
        "n_test": len(X_test),
        "n_features": X.shape[1],
        "feature_names": feature_names,
        "accuracy": round(accuracy, 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1_score": round(f1, 4),
        "roc_auc": round(roc_auc, 4),
        "confusion_matrix": cm,
        "classification_report": report,
        "feature_importance": feature_importance,
        "model_path": model_path,
        "validation_strategy": split_strategy,
        "class_distribution": data["class_distribution"],
        "hyperparameters": hyperparameters,
    }


def predict_with_model(
    model_path: str,
    feature_dict: Dict[str, float],
) -> Dict:
    """Make a prediction using a saved model.

    Args:
        model_path: path to saved model (joblib)
        feature_dict: dict of {feature_name: value}

    Returns:
        Dict with prediction and probability
    """
    import joblib

    model = joblib.load(model_path)

    # Get feature names from model if available
    if hasattr(model, "feature_names_in_"):
        feature_names = list(model.feature_names_in_)
    else:
        feature_names = list(feature_dict.keys())

    # Build feature vector in correct order
    X = np.array([[feature_dict.get(name, 0.0) for name in feature_names]])

    prediction = int(model.predict(X)[0])
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X)[0]
        confidence = float(max(proba))
    else:
        confidence = 0.5

    return {
        "prediction": prediction,
        "label": "Flood-prone" if prediction == 1 else "Not flood-prone",
        "confidence": round(confidence, 4),
        "features_used": feature_names,
    }
