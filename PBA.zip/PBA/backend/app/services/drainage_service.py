"""Drainage and hydrological analysis service.

Handles drainage network import, distance buffer calculation,
proximity analysis, and identification of poor drainage access areas.
"""

import os
import json
from pathlib import Path
from typing import Dict, Optional, List, Tuple
import numpy as np

from app.core.config import settings
from app.geospatial.raster_processing import (
    read_raster, write_raster, has_rasterio,
)
from app.geospatial.vector_processing import (
    load_vector, has_vector_libs, buffer_geometries,
)


def process_drainage(
    drainage_path: str,
    reference_raster_path: Optional[str] = None,
    output_dir: str = "./output",
    study_area_id: str = "default",
) -> Dict:
    """Process drainage network data.

    Args:
        drainage_path: path to drainage GeoJSON/shapefile
        reference_raster_path: path to a reference raster (DEM) for grid alignment
        output_dir: directory for outputs
        study_area_id: study area identifier

    Returns:
        Dict with drainage info, distance raster, buffer info
    """
    if not has_vector_libs():
        raise ImportError("geopandas is required for drainage processing")

    # Load drainage vector
    info = load_vector(drainage_path)
    gdf = info["gdf"]

    # Classify features
    rivers = []
    lakes = []
    water_bodies = []

    for _, row in gdf.iterrows():
        feature_info = {
            "geometry_type": str(row.geometry.geom_type),
            "properties": {k: v for k, v in row.items() if k != "geometry"},
        }
        feature_type = str(row.get("type", "")).lower() if "type" in row else ""

        if "river" in feature_type or row.geometry.geom_type in ("LineString", "MultiLineString"):
            rivers.append(feature_info)
        elif "lake" in feature_type or row.geometry.geom_type in ("Polygon", "MultiPolygon"):
            lakes.append(feature_info)
        else:
            water_bodies.append(feature_info)

    # Generate distance raster if reference raster available
    distance_raster_path = ""
    distance_stats = {}

    if reference_raster_path and has_rasterio():
        try:
            ref_raster = read_raster(reference_raster_path)
            ref_shape = (ref_raster["height"], ref_raster["width"])
            ref_transform = ref_raster["transform"]
            ref_crs = ref_raster["crs"]

            # Transform drainage to match reference CRS
            if str(gdf.crs) != ref_crs:
                gdf = gdf.to_crs(ref_crs)

            # Calculate distance to nearest drainage
            from app.geospatial.vector_processing import calculate_distance_raster

            # Determine target CRS for distance calculation
            target_crs = "EPSG:32644"  # Default UTM
            if ref_crs and "326" in str(ref_crs):
                target_crs = str(ref_crs)

            distances = calculate_distance_raster(
                gdf, ref_shape, ref_transform, target_crs, max_distance_m=5000
            )

            distance_raster_path = os.path.join(output_dir, f"drainage_distance_{study_area_id}.tif")
            write_raster(distance_raster_path, distances, ref_transform, ref_crs)

            from app.geospatial.raster_processing import get_raster_stats
            distance_stats = get_raster_stats(distances)

        except Exception as e:
            print(f"Warning: Could not generate distance raster: {e}")

    # Generate buffer zones
    buffers = {}
    try:
        for buffer_m in [500, 1000, 2000]:
            buffered = buffer_geometries(gdf, buffer_m)
            buffer_path = os.path.join(output_dir, f"drainage_buffer_{buffer_m}m_{study_area_id}.geojson")
            Path(output_dir).mkdir(parents=True, exist_ok=True)
            buffered.to_file(buffer_path, driver="GeoJSON")
            buffers[f"{buffer_m}m"] = buffer_path
    except Exception as e:
        print(f"Warning: Could not generate buffers: {e}")

    return {
        "feature_count": info["feature_count"],
        "rivers": rivers,
        "lakes": lakes,
        "water_bodies": water_bodies,
        "bounds": info["bounds"],
        "crs": info["crs"],
        "distance_raster_path": distance_raster_path,
        "distance_stats": distance_stats,
        "buffers": buffers,
        "note": "Proximity to drainage does not prove drainage capacity or failure. "
                "This is a susceptibility indicator only.",
    }


def get_drainage_distance_at_point(distance_raster_path: str, lon: float, lat: float) -> Optional[float]:
    """Get distance to nearest drainage at a specific point."""
    if not has_rasterio():
        return None
    from app.geospatial.raster_processing import sample_raster_at_point
    return sample_raster_at_point(distance_raster_path, lon, lat)
