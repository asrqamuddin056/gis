"""Drainage analysis API."""

import os
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.services.drainage_service import process_drainage

router = APIRouter()


@router.post("/{dataset_id}/analyze")
async def analyze_drainage(
    dataset_id: str,
    ref_raster_dataset_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    """Anse a drainage dataset — generates distance raster and buffers.

    Optionally provide a reference raster dataset (DEM) to align the
    distance raster grid.
    """
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    if not os.path.exists(dataset.file_path):
        raise HTTPException(status_code=404, detail="File not found")

    # Get reference raster path if provided
    ref_raster_path = None
    if ref_raster_dataset_id:
        ref_dataset = await db.get(Dataset, ref_raster_dataset_id)
        if ref_dataset and os.path.exists(ref_dataset.file_path):
            ref_raster_path = ref_dataset.file_path

    study_area_id = dataset.study_area_id or "default"
    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "drainage")
    output_dir = os.path.abspath(output_dir)

    try:
        result = process_drainage(dataset.file_path, ref_raster_path, output_dir, study_area_id)

        dataset.processing_status = "completed"
        from datetime import datetime, timezone
        dataset.processed_at = datetime.now(timezone.utc)

        return {"status": "completed", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
