"""Machine learning API for flood susceptibility prediction."""

import os
import uuid
from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.models.ml_model import MLModel, ModelEvaluation
from app.schemas.ml import MLTrainingRequest, MLModelResponse, ModelEvaluationResponse
from app.services.ml_service import train_model, predict_with_model

router = APIRouter()


@router.post("/train", response_model=dict)
async def train_ml_model(request: MLTrainingRequest, db: AsyncSession = Depends(get_db)):
    """Train an ML model for flood susceptibility prediction.

    Requires a flood occurrence dataset (CSV with coordinates and flood_label column).
    The model is trained using spatially separated validation to avoid data leakage.

    If no labelled data is available, this endpoint returns an error explaining
    what data is needed.
    """
    # Get the training dataset
    dataset = await db.get(Dataset, request.dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Training dataset not found")

    if not os.path.exists(dataset.file_path):
        raise HTTPException(status_code=404, detail="Dataset file not found on disk")

    model_id = str(uuid.uuid4())
    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "ml")
    output_dir = os.path.abspath(output_dir)

    # Create model record
    ml_model = MLModel(
        id=model_id,
        study_area_id=request.study_area_id,
        name=f"{request.algorithm}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        algorithm=request.algorithm,
        hyperparameters=request.hyperparameters,
        status="training",
        training_dataset_id=request.dataset_id,
    )
    db.add(ml_model)
    await db.flush()

    try:
        result = train_model(
            dataset_path=dataset.file_path,
            algorithm=request.algorithm,
            test_size=request.test_size,
            random_state=request.random_state,
            hyperparameters=request.hyperparameters,
            output_dir=output_dir,
            model_id=model_id,
        )

        if result["status"] == "trained":
            # Update model record
            ml_model.status = "trained"
            ml_model.n_samples = result["n_samples"]
            ml_model.n_features = result["n_features"]
            ml_model.features = result["feature_names"]
            ml_model.model_path = result["model_path"]
            ml_model.feature_importance = result["feature_importance"]
            ml_model.trained_at = datetime.now(timezone.utc)

            # Create evaluation record
            evaluation = ModelEvaluation(
                model_id=model_id,
                accuracy=result["accuracy"],
                precision=result["precision"],
                recall=result["recall"],
                f1_score=result["f1_score"],
                roc_auc=result["roc_auc"],
                confusion_matrix=result["confusion_matrix"],
                classification_report=result["classification_report"],
                validation_strategy=result["validation_strategy"],
            )
            db.add(evaluation)
            await db.flush()

            return {
                "model_id": model_id,
                "status": "trained",
                "result": result,
            }
        else:
            ml_model.status = "failed"
            return {
                "model_id": model_id,
                "status": "failed",
                "message": result.get("message", "Training failed"),
            }
    except Exception as e:
        ml_model.status = "failed"
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/models", response_model=list[MLModelResponse])
async def list_models(study_area_id: Optional[str] = None, db: AsyncSession = Depends(get_db)):
    """List all ML models."""
    query = select(MLModel).order_by(MLModel.created_at.desc())
    if study_area_id:
        query = query.where(MLModel.study_area_id == study_area_id)
    result = await db.execute(query)
    return list(result.scalars().all())


@router.get("/models/{model_id}", response_model=MLModelResponse)
async def get_model(model_id: str, db: AsyncSession = Depends(get_db)):
    """Get a specific ML model."""
    model = await db.get(MLModel, model_id)
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    return model


@router.get("/models/{model_id}/evaluation", response_model=ModelEvaluationResponse)
async def get_model_evaluation(model_id: str, db: AsyncSession = Depends(get_db)):
    """Get evaluation metrics for a trained model."""
    result = await db.execute(
        select(ModelEvaluation).where(ModelEvaluation.model_id == model_id)
    )
    evaluation = result.scalars().first()
    if not evaluation:
        raise HTTPException(status_code=404, detail="Evaluation not found")
    return evaluation


@router.post("/models/{model_id}/predict")
async def predict(
    model_id: str,
    features: dict,
    db: AsyncSession = Depends(get_db),
):
    """Make a prediction using a trained model.

    Pass feature values as a JSON object: {"elevation": 450, "slope": 5, ...}
    """
    model = await db.get(MLModel, model_id)
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")

    if not os.path.exists(model.model_path):
        raise HTTPException(status_code=404, detail="Model file not found")

    try:
        result = predict_with_model(model.model_path, features)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
