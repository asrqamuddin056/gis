"""Satellite imagery processing API."""

import os
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.services.satellite_service import (
    process_satellite_imagery, is_gee_available, get_satellite_info,
    clip_imagery_to_boundary, apply_cloud_mask,
)

router = APIRouter()


@router.get("/info")
async def satellite_info():
    """Get information about the satellite imagery source."""
    return get_satellite_info()


@router.post("/process")
async def process_imagery(
    red_file: UploadFile = File(None),
    nir_file: UploadFile = File(None),
    green_file: UploadFile = File(None),
    db: AsyncSession = Depends(get_db),
):
    """Process uploaded satellite imagery bands.

    Upload Red, NIR, and optionally Green band GeoTIFF files.
    The system will calculate NDVI and NDWI spectral indices.

    If Google Earth Engine is not configured, this uses locally uploaded
    imagery (not retrieved from external services).
    """
    from app.services.dataset_service import save_uploaded_file

    band_paths = {}
    if red_file:
        band_paths["red"] = save_uploaded_file(await red_file.read(), red_file.filename, "satellite")
    if nir_file:
        band_paths["nir"] = save_uploaded_file(await nir_file.read(), nir_file.filename, "satellite")
    if green_file:
        band_paths["green"] = save_uploaded_file(await green_file.read(), green_file.filename, "satellite")

    if not band_paths:
        raise HTTPException(status_code=400, detail="At least one band file must be uploaded")

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "satellite")
    output_dir = os.path.abspath(output_dir)

    try:
        result = process_satellite_imagery(band_paths, None, output_dir)
        return {"status": "completed", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/cloud-mask")
async def cloud_mask(
    main_file: UploadFile = File(...),
    qa_file: UploadFile = File(...),
    cloud_threshold: int = Form(1024),
):
    """Apply cloud masking using a QA band."""
    from app.services.dataset_service import save_uploaded_file

    main_path = save_uploaded_file(await main_file.read(), main_file.filename, "satellite")
    qa_path = save_uploaded_file(await qa_file.read(), qa_file.filename, "satellite")

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "satellite")
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "cloud_masked.tif")

    try:
        result = apply_cloud_mask(main_path, qa_path, output_path, cloud_threshold)
        return {"status": "completed", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
