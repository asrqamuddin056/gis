"""Study area management API."""

import json
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.study_area import StudyArea
from app.models.dataset import Dataset
from app.schemas.study_area import StudyAreaCreate, StudyAreaUpdate, StudyAreaResponse, CitySearchResult
from app.utils.sample_data import get_bbox_info
from app.geospatial.coordinate_systems import calculate_area_km2, get_utm_crs_for_bbox

router = APIRouter()


@router.get("/", response_model=list[StudyAreaResponse])
async def list_study_areas(db: AsyncSession = Depends(get_db)):
    """List all study areas."""
    result = await db.execute(select(StudyArea).order_by(StudyArea.created_at.desc()))
    return list(result.scalars().all())


@router.post("/", response_model=StudyAreaResponse)
async def create_study_area(data: StudyAreaCreate, db: AsyncSession = Depends(get_db)):
    """Create a new study area."""
    # Calculate area from bbox if provided
    area_km2 = 0.0
    if data.bbox_max_lon > data.bbox_min_lon and data.bbox_max_lat > data.bbox_min_lat:
        area_km2 = calculate_area_km2(
            data.bbox_min_lon, data.bbox_min_lat, data.bbox_max_lon, data.bbox_max_lat
        )
        # Auto-determine UTM CRS if not specified
        if not data.analysis_crs or data.analysis_crs == "32644":
            data.analysis_crs = get_utm_crs_for_bbox(
                data.bbox_min_lon, data.bbox_min_lat, data.bbox_max_lon, data.bbox_max_lat
            )

    study_area = StudyArea(
        name=data.name,
        description=data.description,
        boundary_geojson=data.boundary_geojson,
        bbox_min_lon=data.bbox_min_lon,
        bbox_min_lat=data.bbox_min_lat,
        bbox_max_lon=data.bbox_max_lon,
        bbox_max_lat=data.bbox_max_lat,
        area_km2=area_km2,
        analysis_crs=data.analysis_crs,
        location_label=data.location_label,
    )
    db.add(study_area)
    await db.flush()
    return study_area


@router.get("/{study_area_id}", response_model=StudyAreaResponse)
async def get_study_area(study_area_id: str, db: AsyncSession = Depends(get_db)):
    """Get a specific study area by ID."""
    study_area = await db.get(StudyArea, study_area_id)
    if not study_area:
        raise HTTPException(status_code=404, detail="Study area not found")
    return study_area


@router.put("/{study_area_id}", response_model=StudyAreaResponse)
async def update_study_area(study_area_id: str, data: StudyAreaUpdate, db: AsyncSession = Depends(get_db)):
    """Update a study area."""
    study_area = await db.get(StudyArea, study_area_id)
    if not study_area:
        raise HTTPException(status_code=404, detail="Study area not found")

    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(study_area, key, value)

    # Recalculate area if bbox changed
    if any(k in update_data for k in ["bbox_min_lon", "bbox_min_lat", "bbox_max_lon", "bbox_max_lat"]):
        study_area.area_km2 = calculate_area_km2(
            study_area.bbox_min_lon, study_area.bbox_min_lat,
            study_area.bbox_max_lon, study_area.bbox_max_lat,
        )

    await db.flush()
    return study_area


@router.delete("/{study_area_id}")
async def delete_study_area(study_area_id: str, db: AsyncSession = Depends(get_db)):
    """Delete a study area and its associated datasets."""
    study_area = await db.get(StudyArea, study_area_id)
    if not study_area:
        raise HTTPException(status_code=404, detail="Study area not found")

    # Delete associated datasets
    await db.execute(delete(Dataset).where(Dataset.study_area_id == study_area_id))

    await db.delete(study_area)
    return {"message": "Study area deleted", "id": study_area_id}


@router.post("/search-city", response_model=list[CitySearchResult])
async def search_city(query: str = Query(..., min_length=2)):
    """Search for a city by name.

    Uses a built-in list of common cities for demonstration.
    In production, this would use a geocoding service like Nominatim.
    """
    # Built-in city database for demonstration
    cities = [
        CitySearchResult(name="Hyderabad", country="India", lat=17.3850, lon=78.4867,
                         bbox=[78.25, 17.20, 78.75, 17.65]),
        CitySearchResult(name="Mumbai", country="India", lat=19.0760, lon=72.8777,
                         bbox=[72.75, 18.90, 73.00, 19.30]),
        CitySearchResult(name="Chennai", country="India", lat=13.0827, lon=80.2707,
                         bbox=[80.10, 12.90, 80.40, 13.25]),
        CitySearchResult(name="Delhi", country="India", lat=28.7041, lon=77.1025,
                         bbox=[76.85, 28.40, 77.35, 28.90]),
        CitySearchResult(name="Bangalore", country="India", lat=12.9716, lon=77.5946,
                         bbox=[77.45, 12.80, 77.75, 13.10]),
        CitySearchResult(name="Kolkata", country="India", lat=22.5726, lon=88.3639,
                         bbox=[88.20, 22.40, 88.50, 22.70]),
        CitySearchResult(name="Pune", country="India", lat=18.5204, lon=73.8567,
                         bbox=[73.70, 18.40, 74.00, 18.65]),
        CitySearchResult(name="Ahmedabad", country="India", lat=23.0225, lon=72.5714,
                         bbox=[72.45, 22.90, 72.70, 23.15]),
    ]

    query_lower = query.lower()
    results = [c for c in cities if query_lower in c.name.lower()]
    return results


@router.post("/create-hyderabad-sample")
async def create_hyderabad_sample(db: AsyncSession = Depends(get_db)):
    """Create a pre-configured Hyderabad study area for quick demonstration."""
    bbox = get_bbox_info()

    # Check if already exists
    existing = await db.execute(select(StudyArea).where(StudyArea.name == "Hyderabad"))
    if existing.scalars().first():
        return {"message": "Hyderabad study area already exists"}

    # Load boundary GeoJSON from sample data
    import os
    from app.utils.sample_data import generate_all_sample_data

    sample_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "data", "sample")
    sample_dir = os.path.abspath(sample_dir)

    boundary_path = os.path.join(sample_dir, "study_area_boundary_sample.geojson")
    boundary_geojson = ""
    if os.path.exists(boundary_path):
        with open(boundary_path, "r") as f:
            boundary_geojson = f.read()

    area_km2 = calculate_area_km2(
        bbox["min_lon"], bbox["min_lat"], bbox["max_lon"], bbox["max_lat"]
    )

    study_area = StudyArea(
        name="Hyderabad",
        description="Hyderabad metropolitan area, Telangana, India. Default demonstration study area.",
        boundary_geojson=boundary_geojson,
        bbox_min_lon=bbox["min_lon"],
        bbox_min_lat=bbox["min_lat"],
        bbox_max_lon=bbox["max_lon"],
        bbox_max_lat=bbox["max_lat"],
        area_km2=area_km2,
        analysis_crs=get_utm_crs_for_bbox(bbox["min_lon"], bbox["min_lat"], bbox["max_lon"], bbox["max_lat"]),
        location_label=bbox["name"],
    )
    db.add(study_area)
    await db.flush()
    return {"message": "Hyderabad study area created", "id": study_area.id}
