"""Report generation and export API."""

import os
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.responses import FileResponse

from app.database.connection import get_db
from app.models.assessment import RiskAssessment
from app.models.study_area import StudyArea
from app.models.ml_model import MLModel, ModelEvaluation
from app.services.report_service import generate_pdf_report, export_csv, export_summary_json

router = APIRouter()


@router.post("/{assessment_id}/pdf")
async def generate_report_pdf(
    assessment_id: str,
    include_ml: bool = Query(False),
    db: AsyncSession = Depends(get_db),
):
    """Generate a professional PDF flood risk assessment report.

    The report contains actual analysis results from the specified assessment.
    """
    assessment = await db.get(RiskAssessment, assessment_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    study_area = await db.get(StudyArea, assessment.study_area_id)
    if not study_area:
        raise HTTPException(status_code=404, detail="Study area not found")

    # Get ML results if requested
    ml_results = None
    if include_ml:
        ml_models = (await db.execute(
            select(MLModel).where(
                MLModel.study_area_id == assessment.study_area_id,
                MLModel.status == "trained",
            ).order_by(MLModel.trained_at.desc())
        )).scalars().first()

        if ml_models:
            eval_result = (await db.execute(
                select(ModelEvaluation).where(ModelEvaluation.model_id == ml_models.id)
            )).scalars().first()

            ml_results = {
                "status": "trained",
                "algorithm": ml_models.algorithm,
                "accuracy": eval_result.accuracy if eval_result else 0,
                "precision": eval_result.precision if eval_result else 0,
                "recall": eval_result.recall if eval_result else 0,
                "f1_score": eval_result.f1_score if eval_result else 0,
                "roc_auc": eval_result.roc_auc if eval_result else 0,
                "validation_strategy": eval_result.validation_strategy if eval_result else "",
                "feature_importance": ml_models.feature_importance,
            }

    # Prepare assessment data for the report
    assessment_data = {
        "name": assessment.name,
        "method": assessment.method,
        "status": assessment.status,
        "weights": assessment.weights or {},
        "thresholds": assessment.thresholds or {},
        "statistics": assessment.statistics or {},
        "area_by_category": assessment.area_by_category or {},
        "risk_distribution": (assessment.statistics or {}).get("risk_distribution", {}),
        "high_risk_percentage": (assessment.statistics or {}).get("high_risk_percentage", 0),
    }

    study_area_info = {
        "name": study_area.name,
        "location_label": study_area.location_label,
        "area_km2": study_area.area_km2,
        "bbox_min_lon": study_area.bbox_min_lon,
        "bbox_min_lat": study_area.bbox_min_lat,
        "bbox_max_lon": study_area.bbox_max_lon,
        "bbox_max_lat": study_area.bbox_max_lat,
        "analysis_crs": study_area.analysis_crs,
    }

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "reports")
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    pdf_path = os.path.join(output_dir, f"report_{assessment_id}.pdf")

    try:
        generate_pdf_report(assessment_data, study_area_info, pdf_path, ml_results)
        return FileResponse(pdf_path, filename=f"flood_risk_report_{assessment_id}.pdf",
                           media_type="application/pdf")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{assessment_id}/csv")
async def export_csv_report(
    assessment_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Export assessment statistics to CSV."""
    assessment = await db.get(RiskAssessment, assessment_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "reports")
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    csv_path = os.path.join(output_dir, f"export_{assessment_id}.csv")

    export_csv({
        "name": assessment.name,
        "method": assessment.method,
        "status": assessment.status,
        "statistics": assessment.statistics or {},
        "area_by_category": assessment.area_by_category or {},
        "risk_distribution": (assessment.statistics or {}).get("risk_distribution", {}),
        "weights": assessment.weights or {},
    }, csv_path)

    return FileResponse(csv_path, filename=f"flood_risk_export_{assessment_id}.csv",
                       media_type="text/csv")


@router.post("/{assessment_id}/json")
async def export_json_report(
    assessment_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Export a complete analysis summary as JSON."""
    assessment = await db.get(RiskAssessment, assessment_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    study_area = await db.get(StudyArea, assessment.study_area_id)

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "reports")
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    json_path = os.path.join(output_dir, f"summary_{assessment_id}.json")

    study_area_info = {
        "name": study_area.name if study_area else "",
        "location_label": study_area.location_label if study_area else "",
        "area_km2": study_area.area_km2 if study_area else 0,
    }

    assessment_data = {
        "name": assessment.name,
        "method": assessment.method,
        "status": assessment.status,
        "weights": assessment.weights or {},
        "thresholds": assessment.thresholds or {},
        "statistics": assessment.statistics or {},
        "area_by_category": assessment.area_by_category or {},
    }

    export_summary_json(assessment_data, study_area_info, json_path)

    return FileResponse(json_path, filename=f"analysis_summary_{assessment_id}.json",
                       media_type="application/json")
