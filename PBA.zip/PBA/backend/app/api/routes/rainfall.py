"""Rainfall analysis API."""

import os
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.services.rainfall_service import (
    process_rainfall_csv, process_rainfall_raster, classify_rainfall_intensity,
)

router = APIRouter()


@router.post("/{dataset_id}/analyze")
async def analyze_rainfall(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """Analyze a rainfall dataset (CSV or raster)."""
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    if not os.path.exists(dataset.file_path):
        raise HTTPException(status_code=404, detail="File not found")

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "rainfall")
    output_dir = os.path.abspath(output_dir)

    try:
        if dataset.data_type == "rainfall" and dataset.file_path.endswith(".csv"):
            result = process_rainfall_csv(dataset.file_path)
        elif dataset.data_type in ("rainfall", "raster"):
            result = process_rainfall_raster(dataset.file_path, output_dir)
        else:
            # Try CSV first, fall back to raster
            try:
                result = process_rainfall_csv(dataset.file_path)
            except Exception:
                result = process_rainfall_raster(dataset.file_path, output_dir)

        dataset.processing_status = "completed"
        from datetime import datetime, timezone
        dataset.processed_at = datetime.now(timezone.utc)

        return {"status": "completed", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/intensity/{rainfall_mm}")
async def get_intensity_class(rainfall_mm: float):
    """Classify a rainfall value into an intensity category."""
    return {
        "rainfall_mm": rainfall_mm,
        "intensity_class": classify_rainfall_intensity(rainfall_mm),
        "note": "Historical rainfall observation classification, not a weather forecast.",
    }
