"""Scenario analysis API — hypothetical rainfall scenario assessment."""

import os
import uuid
from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.models.assessment import RiskAssessment
from app.models.ml_model import ScenarioAnalysis
from app.schemas.ml import ScenarioRequest, ScenarioResponse
from app.services.overlay_service import run_scenario_analysis, DEFAULT_THRESHOLDS

router = APIRouter()


@router.post("/run", response_model=dict)
async def run_scenario(request: ScenarioRequest, db: AsyncSession = Depends(get_db)):
    """Run a hypothetical rainfall scenario analysis.

    This is clearly labelled as scenario-based susceptibility assessment,
    NOT validated future flood forecasting. It recalculates the rainfall
    component of the flood risk assessment using a user-specified
    hypothetical rainfall intensity.
    """
    # Get the baseline assessment if provided
    baseline_assessment = None
    baseline_fri = None
    baseline_classes = None
    ref_transform = None
    ref_crs = None

    if request.baseline_assessment_id:
        baseline_assessment = await db.get(RiskAssessment, request.baseline_assessment_id)
        if baseline_assessment and baseline_assessment.risk_raster_path:
            # Load baseline FRI
            from app.geospatial.raster_processing import read_raster
            from app.geospatial.spatial_analysis import classify_risk
            try:
                baseline_raster = read_raster(baseline_assessment.risk_raster_path)
                baseline_fri = baseline_raster["data"]
                ref_transform = baseline_raster["transform"]
                ref_crs = baseline_raster["crs"]
                baseline_classes = classify_risk(baseline_fri, DEFAULT_THRESHOLDS, -1.0)
            except Exception:
                pass

    # Get datasets for the study area
    datasets = (await db.execute(
        select(Dataset).where(Dataset.study_area_id == request.study_area_id)
    )).scalars().all()

    # Build layer paths
    layer_paths = {}
    for ds in datasets:
        if not os.path.exists(ds.file_path):
            continue
        name_lower = ds.name.lower()
        if ds.data_type == "raster":
            if "dem" in name_lower or "elevation" in name_lower:
                layer_paths["elevation"] = ds.file_path
            elif "slope" in name_lower:
                layer_paths["slope"] = ds.file_path
            elif "rainfall" in name_lower:
                layer_paths["rainfall"] = ds.file_path
            elif "lulc" in name_lower or "land" in name_lower:
                layer_paths["lulc"] = ds.file_path
            elif "built" in name_lower:
                layer_paths["built_up"] = ds.file_path
            elif "distance" in name_lower or "drainage" in name_lower:
                layer_paths["drainage_proximity"] = ds.file_path
        elif ds.data_type == "rainfall" and ds.file_path.endswith((".tif", ".tiff")):
            layer_paths["rainfall"] = ds.file_path

    # Use baseline weights or defaults
    weights = DEFAULT_THRESHOLDS  # placeholder
    if baseline_assessment and baseline_assessment.weights:
        weights = baseline_assessment.weights
    else:
        from app.services.overlay_service import DEFAULT_WEIGHTS
        weights = DEFAULT_WEIGHTS

    scenario_id = str(uuid.uuid4())
    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "scenarios")
    output_dir = os.path.abspath(output_dir)

    # Create scenario record
    scenario = ScenarioAnalysis(
        id=scenario_id,
        study_area_id=request.study_area_id,
        name=request.name,
        description=request.description,
        scenario_rainfall_mm=request.scenario_rainfall_mm,
        baseline_assessment_id=request.baseline_assessment_id,
        status="processing",
    )
    db.add(scenario)
    await db.flush()

    try:
        result = run_scenario_analysis(
            layer_paths=layer_paths,
            weights=weights,
            thresholds=DEFAULT_THRESHOLDS,
            scenario_rainfall_mm=request.scenario_rainfall_mm,
            output_dir=output_dir,
            assessment_id=scenario_id,
            baseline_fri=baseline_fri,
            baseline_classes=baseline_classes,
            reference_transform=ref_transform,
            reference_crs=ref_crs or "EPSG:4326",
        )

        scenario.status = "completed"
        scenario.scenario_raster_path = result["scenario_fri_path"]
        scenario.difference_raster_path = result.get("difference_path", "")
        scenario.statistics = {
            "scenario_stats": result["scenario_stats"],
            "risk_distribution": result["risk_distribution"],
        }
        scenario.changed_areas = result["changed_areas"]
        scenario.completed_at = datetime.now(timezone.utc)
        await db.flush()

        return {
            "scenario_id": scenario_id,
            "status": "completed",
            "result": result,
            "note": "This is a scenario-based susceptibility assessment, not validated future flood forecasting.",
        }
    except Exception as e:
        scenario.status = "failed"
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/", response_model=list[ScenarioResponse])
async def list_scenarios(study_area_id: Optional[str] = None, db: AsyncSession = Depends(get_db)):
    """List all scenario analyses."""
    query = select(ScenarioAnalysis).order_by(ScenarioAnalysis.created_at.desc())
    if study_area_id:
        query = query.where(ScenarioAnalysis.study_area_id == study_area_id)
    result = await db.execute(query)
    return list(result.scalars().all())


@router.get("/{scenario_id}", response_model=ScenarioResponse)
async def get_scenario(scenario_id: str, db: AsyncSession = Depends(get_db)):
    """Get a specific scenario analysis."""
    scenario = await db.get(ScenarioAnalysis, scenario_id)
    if not scenario:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return scenario
