"""Dataset management API — upload, validate, list, delete datasets."""

import os
import json
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.schemas.dataset import DatasetResponse, DatasetValidationResult, DatasetStatsResponse
from app.schemas.common import MessageResponse
from app.services.dataset_service import (
    validate_file_extension, validate_file_size, save_uploaded_file,
    create_dataset_record, update_dataset_validation, validate_dataset,
    get_datasets, get_dataset_stats,
)

router = APIRouter()


@router.get("/", response_model=list[DatasetResponse])
async def list_datasets(
    study_area_id: Optional[str] = Query(None),
    data_type: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    """List datasets, optionally filtered by study area or data type."""
    return await get_datasets(db, study_area_id, data_type)


@router.get("/stats", response_model=DatasetStatsResponse)
async def dataset_stats(db: AsyncSession = Depends(get_db)):
    """Get dataset statistics for the dashboard."""
    return await get_dataset_stats(db)


@router.post("/upload", response_model=DatasetResponse)
async def upload_dataset(
    file: UploadFile = File(...),
    name: str = Form(...),
    description: str = Form(""),
    data_type: str = Form(...),
    source: str = Form(""),
    study_area_id: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_db),
):
    """Upload a geospatial dataset file.

    Supported types: raster, vector, csv, rainfall, flood_record, satellite
    """
    # Validate extension
    is_valid_ext, ext_msg = validate_file_extension(file.filename, data_type)
    if not is_valid_ext:
        raise HTTPException(status_code=400, detail=ext_msg)

    # Read file content
    content = await file.read()
    file_size = len(content)

    # Validate size
    is_valid_size, size_msg = validate_file_size(file_size)
    if not is_valid_size:
        raise HTTPException(status_code=413, detail=size_msg)

    # Save file
    file_path = save_uploaded_file(content, file.filename, data_type)

    # Create database record
    dataset = await create_dataset_record(
        db, name, description, data_type, source,
        file_path, file.filename, file_size, study_area_id,
    )

    # Validate the dataset
    validation = validate_dataset(file_path, data_type)

    # Update validation status
    await update_dataset_validation(db, dataset.id, validation, validation.metadata)

    await db.flush()
    return await db.get(Dataset, dataset.id)


@router.get("/{dataset_id}", response_model=DatasetResponse)
async def get_dataset(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """Get a specific dataset."""
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")
    return dataset


@router.get("/{dataset_id}/validate", response_model=DatasetValidationResult)
async def validate_dataset_endpoint(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """Re-validate a dataset."""
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    if not os.path.exists(dataset.file_path):
        raise HTTPException(status_code=404, detail="Dataset file not found on disk")

    validation = validate_dataset(dataset.file_path, dataset.data_type)
    await update_dataset_validation(db, dataset_id, validation, validation.metadata)
    return validation


@router.delete("/{dataset_id}", response_model=MessageResponse)
async def delete_dataset(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """Delete a dataset and its file."""
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    # Delete file if exists
    if dataset.file_path and os.path.exists(dataset.file_path):
        os.remove(dataset.file_path)

    await db.delete(dataset)
    return MessageResponse(message="Dataset deleted", detail=dataset_id)


@router.get("/{dataset_id}/download")
async def download_dataset(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """Download a dataset file."""
    from fastapi.responses import FileResponse

    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    if not os.path.exists(dataset.file_path):
        raise HTTPException(status_code=404, detail="File not found on disk")

    return FileResponse(
        dataset.file_path,
        filename=dataset.original_filename or os.path.basename(dataset.file_path),
    )


@router.post("/generate-sample-data")
async def generate_sample_data(
    study_area_id: str = Form(None),
    db: AsyncSession = Depends(get_db),
):
    """Generate sample datasets for demonstration (clearly labelled as sample data)."""
    from app.utils.sample_data import generate_all_sample_data

    sample_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "data", "sample")
    sample_dir = os.path.abspath(sample_dir)

    paths = generate_all_sample_data(sample_dir)

    # Create dataset records for each generated file
    dataset_configs = [
        ("dem_sample.tif", "Sample DEM (Hyderabad)", "Digital Elevation Model for Hyderabad area (SAMPLE DATA)", "raster"),
        ("slope_sample.tif", "Sample Slope (Hyderabad)", "Slope raster derived from sample DEM (SAMPLE DATA)", "raster"),
        ("rainfall_sample.tif", "Sample Rainfall Raster (Hyderabad)", "Rainfall distribution raster (SAMPLE DATA)", "rainfall"),
        ("rainfall_stations_sample.csv", "Sample Rainfall Stations", "Rainfall time-series from weather stations (SAMPLE DATA)", "rainfall"),
        ("lulc_sample.tif", "Sample LULC (Hyderabad)", "Land Use/Land Cover classification (SAMPLE DATA)", "raster"),
        ("built_up_sample.tif", "Sample Built-up Density", "Built-up density raster (SAMPLE DATA)", "raster"),
        ("drainage_sample.geojson", "Sample Drainage Network", "Drainage network GeoJSON (SAMPLE DATA)", "vector"),
        ("flood_occurrence_sample.csv", "Sample Flood Occurrence Data", "Historical flood occurrence points with labels (SAMPLE DATA)", "flood_record"),
    ]

    created = []
    for filename, name, description, data_type in dataset_configs:
        file_path = os.path.join(sample_dir, filename)
        if not os.path.exists(file_path):
            continue

        file_size = os.path.getsize(file_path)

        # Validate
        validation = validate_dataset(file_path, data_type)

        dataset = await create_dataset_record(
            db, name, description, data_type, "Sample Data Generator",
            file_path, filename, file_size, study_area_id, is_sample_data=True,
        )

        await update_dataset_validation(db, dataset.id, validation, validation.metadata)
        created.append({"id": dataset.id, "name": name, "type": data_type})

    return {"message": f"Generated {len(created)} sample datasets", "datasets": created}
