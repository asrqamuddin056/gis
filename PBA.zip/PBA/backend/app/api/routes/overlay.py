"""Weighted overlay analysis API — the core flood risk engine."""

import os
import json
import uuid
from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.models.study_area import StudyArea
from app.models.assessment import RiskAssessment, RiskWeight, RiskLayer
from app.schemas.assessment import WeightedOverlayRequest, RiskAssessmentResponse, RiskWeightCreate, RiskWeightResponse
from app.services.overlay_service import (
    run_weighted_overlay, validate_weights, DEFAULT_WEIGHTS, DEFAULT_THRESHOLDS,
)

router = APIRouter()


def _find_layer_file(db_datasets, data_type, study_area_id):
    """Find a dataset file path for a given type and study area."""
    for ds in db_datasets:
        if ds.study_area_id == study_area_id or study_area_id is None:
            if ds.data_type == data_type and os.path.exists(ds.file_path):
                return ds.file_path
    return None


@router.get("/default-weights")
async def get_default_weights():
    """Return the default illustrative weight configuration."""
    return {
        "weights": DEFAULT_WEIGHTS,
        "note": "These are illustrative initial values, not scientifically established universal weights. "
                "Users should adjust them based on local conditions and domain expertise.",
    }


@router.get("/weights/{study_area_id}", response_model=list[RiskWeightResponse])
async def get_weights(study_area_id: str, db: AsyncSession = Depends(get_db)):
    """Get weight configuration for a study area."""
    result = await db.execute(
        select(RiskWeight).where(RiskWeight.study_area_id == study_area_id)
    )
    weights = result.scalars().all()
    if not weights:
        # Return defaults
        for factor, weight in DEFAULT_WEIGHTS.items():
            w = RiskWeight(
                study_area_id=study_area_id,
                factor=factor,
                weight=weight,
                label=factor.replace("_", " ").title(),
                is_enabled=True,
            )
            db.add(w)
        await db.flush()
        result = await db.execute(
            select(RiskWeight).where(RiskWeight.study_area_id == study_area_id)
        )
        weights = result.scalars().all()
    return list(weights)


@router.post("/weights", response_model=RiskWeightResponse)
async def set_weight(data: RiskWeightCreate, study_area_id: str = None, db: AsyncSession = Depends(get_db)):
    """Create or update a weight for a factor."""
    # Check if weight already exists
    existing = await db.execute(
        select(RiskWeight).where(
            RiskWeight.study_area_id == study_area_id,
            RiskWeight.factor == data.factor,
        )
    )
    weight = existing.scalars().first()
    if weight:
        weight.weight = data.weight
        weight.label = data.label
        weight.is_enabled = data.is_enabled
    else:
        weight = RiskWeight(
            study_area_id=study_area_id,
            factor=data.factor,
            weight=data.weight,
            label=data.label or data.factor.replace("_", " ").title(),
            is_enabled=data.is_enabled,
        )
        db.add(weight)
    await db.flush()
    return weight


@router.post("/run", response_model=dict)
async def run_overlay(request: WeightedOverlayRequest, db: AsyncSession = Depends(get_db)):
    """Run the weighted overlay analysis to generate a Flood Risk Index.

    This is the core analytical engine. It:
    1. Loads all available thematic layers for the study area
    2. Normalizes each to a 1-5 risk scale
    3. Applies the configured weights
    4. Computes FRI = Σ(Wi × Ri)
    5. Classifies into Low/Medium/High/Very High risk
    6. Saves outputs as GeoTIFF and GeoJSON
    """
    # Validate weights
    is_valid, msg = validate_weights(request.weights)
    if not is_valid:
        raise HTTPException(status_code=400, detail=f"Invalid weights: {msg}")

    # Get all datasets for the study area
    datasets = (await db.execute(
        select(Dataset).where(Dataset.study_area_id == request.study_area_id)
    )).scalars().all()

    if not datasets:
        raise HTTPException(status_code=400, detail="No datasets found for this study area")

    # Build layer paths from datasets
    layer_paths = {}

    # Map dataset data_types to overlay factors
    for ds in datasets:
        if not os.path.exists(ds.file_path):
            continue
        if ds.data_type == "raster":
            # Determine which factor this raster represents
            name_lower = ds.name.lower()
            if "dem" in name_lower or "elevation" in name_lower:
                layer_paths["elevation"] = ds.file_path
            elif "slope" in name_lower:
                layer_paths["slope"] = ds.file_path
            elif "rainfall" in name_lower:
                layer_paths["rainfall"] = ds.file_path
            elif "lulc" in name_lower or "land" in name_lower:
                layer_paths["lulc"] = ds.file_path
            elif "built" in name_lower or "density" in name_lower:
                layer_paths["built_up"] = ds.file_path
            elif "distance" in name_lower or "drainage" in name_lower:
                layer_paths["drainage_proximity"] = ds.file_path
        elif ds.data_type == "rainfall":
            if ds.file_path.endswith(".tif") or ds.file_path.endswith(".tiff"):
                layer_paths["rainfall"] = ds.file_path
        elif ds.data_type == "vector":
            if "drain" in ds.name.lower() or "river" in ds.name.lower():
                # Need to generate distance raster from drainage vector
                # For now, check if a distance raster already exists
                pass

    # Filter weights to only include available layers
    active_weights = {k: v for k, v in request.weights.items() if k in layer_paths}

    if not active_weights:
        raise HTTPException(
            status_code=400,
            detail="No thematic layers available. Upload DEM, rainfall, LULC, etc. datasets first, "
                   "or generate sample data."
        )

    # Create assessment record
    assessment_id = str(uuid.uuid4())
    assessment = RiskAssessment(
        id=assessment_id,
        study_area_id=request.study_area_id,
        name=request.name,
        description=request.description,
        method="weighted_overlay",
        weights=request.weights,
        thresholds=request.thresholds,
        status="processing",
    )
    db.add(assessment)
    await db.flush()

    # Run the analysis
    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "overlay")
    output_dir = os.path.abspath(output_dir)

    try:
        result = run_weighted_overlay(
            layer_paths=layer_paths,
            weights=active_weights,
            thresholds=request.thresholds,
            output_dir=output_dir,
            assessment_id=assessment_id,
        )

        # Update assessment record
        assessment.status = "completed"
        assessment.risk_raster_path = result["fri_raster_path"]
        assessment.risk_vector_path = result.get("risk_vector_path", "")
        assessment.statistics = {
            "fri_stats": result["fri_stats"],
            "risk_distribution": result["risk_distribution"],
            "high_risk_percentage": result["high_risk_percentage"],
            "area_by_category": result["area_by_category"],
            "layers_used": result["layers_used"],
            "pixel_size_m": result["pixel_size_m"],
        }
        assessment.area_by_category = result["area_by_category"]
        assessment.completed_at = datetime.now(timezone.utc)

        await db.flush()

        return {
            "assessment_id": assessment_id,
            "status": "completed",
            "result": {
                "fri_raster_path": result["fri_raster_path"],
                "risk_class_raster_path": result["risk_class_raster_path"],
                "risk_vector_path": result.get("risk_vector_path", ""),
                "fri_stats": result["fri_stats"],
                "risk_distribution": result["risk_distribution"],
                "area_by_category": result["area_by_category"],
                "high_risk_percentage": result["high_risk_percentage"],
                "weights_used": result["weights_used"],
                "layers_used": result["layers_used"],
            },
        }
    except Exception as e:
        assessment.status = "failed"
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/assessments", response_model=list[RiskAssessmentResponse])
async def list_assessments(study_area_id: Optional[str] = None, db: AsyncSession = Depends(get_db)):
    """List all risk assessments."""
    query = select(RiskAssessment).order_by(RiskAssessment.created_at.desc())
    if study_area_id:
        query = query.where(RiskAssessment.study_area_id == study_area_id)
    result = await db.execute(query)
    return list(result.scalars().all())


@router.get("/assessments/{assessment_id}", response_model=RiskAssessmentResponse)
async def get_assessment(assessment_id: str, db: AsyncSession = Depends(get_db)):
    """Get a specific risk assessment."""
    assessment = await db.get(RiskAssessment, assessment_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")
    return assessment


@router.get("/assessments/{assessment_id}/download")
async def download_result(assessment_id: str, format: str = "tif", db: AsyncSession = Depends(get_db)):
    """Download assessment output (GeoTIFF or GeoJSON)."""
    from fastapi.responses import FileResponse

    assessment = await db.get(RiskAssessment, assessment_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    if format == "tif" and assessment.risk_raster_path:
        return FileResponse(assessment.risk_raster_path, filename=os.path.basename(assessment.risk_raster_path))
    elif format == "geojson" and assessment.risk_vector_path:
        return FileResponse(assessment.risk_vector_path, filename=os.path.basename(assessment.risk_vector_path))
    else:
        raise HTTPException(status_code=400, detail=f"Format {format} not available")
