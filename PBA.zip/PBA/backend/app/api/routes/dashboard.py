"""Dashboard API — provides aggregated statistics computed from real data."""

from fastapi import APIRouter, Depends
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.study_area import StudyArea
from app.models.dataset import Dataset
from app.models.assessment import RiskAssessment
from app.models.ml_model import MLModel, ModelEvaluation
from app.schemas.assessment import DashboardStatsResponse

router = APIRouter()


@router.get("/stats", response_model=DashboardStatsResponse)
async def get_dashboard_stats(db: AsyncSession = Depends(get_db)):
    """Compute dashboard statistics from actual database records."""
    # Study areas
    total_study_areas = await db.scalar(select(func.count(StudyArea.id))) or 0

    # Datasets
    total_datasets = await db.scalar(select(func.count(Dataset.id))) or 0
    datasets_processed = await db.scalar(
        select(func.count(Dataset.id)).where(Dataset.processing_status == "completed")
    ) or 0

    # Assessments
    assessments = (await db.execute(
        select(RiskAssessment).order_by(RiskAssessment.created_at.desc())
    )).scalars().all()

    total_assessments = len(assessments)

    # Risk distribution from most recent completed assessment
    risk_distribution = {}
    high_risk_zones = 0
    very_high_risk_zones = 0
    high_risk_percentage = 0.0
    area_analysed = 0.0
    latest_date = None

    for assessment in assessments:
        if assessment.status == "completed" and assessment.statistics:
            stats = assessment.statistics if isinstance(assessment.statistics, dict) else {}
            dist = stats.get("risk_distribution", {})
            if dist:
                risk_distribution = dist
                high_risk_zones = dist.get("High", 0)
                very_high_risk_zones = dist.get("Very High", 0)
                high_risk_percentage = stats.get("high_risk_percentage", 0.0)
                area_analysed = sum(
                    v for k, v in (stats.get("area_by_category", {}) or {}).items()
                    if k != "No Data"
                )
                latest_date = assessment.completed_at or assessment.created_at
                break

    if not latest_date and assessments:
        latest_date = assessments[0].created_at

    # ML models
    ml_models = (await db.execute(select(MLModel))).scalars().all()
    ml_models_trained = sum(1 for m in ml_models if m.status == "trained")

    model_metrics = {}
    if ml_models_trained > 0:
        # Get latest evaluation
        for model in ml_models:
            if model.status == "trained":
                eval_result = await db.execute(
                    select(ModelEvaluation).where(ModelEvaluation.model_id == model.id)
                )
                eval_record = eval_result.scalars().first()
                if eval_record:
                    model_metrics = {
                        "algorithm": model.algorithm,
                        "accuracy": eval_record.accuracy,
                        "precision": eval_record.precision,
                        "recall": eval_record.recall,
                        "f1_score": eval_record.f1_score,
                        "roc_auc": eval_record.roc_auc,
                    }
                    break

    return DashboardStatsResponse(
        total_study_areas=total_study_areas,
        total_datasets=total_datasets,
        total_assessments=total_assessments,
        high_risk_zones=high_risk_zones,
        very_high_risk_zones=very_high_risk_zones,
        high_risk_percentage=high_risk_percentage,
        latest_assessment_date=latest_date.isoformat() if latest_date else None,
        datasets_processed=datasets_processed,
        risk_distribution=risk_distribution,
        area_analysed_km2=area_analysed,
        ml_models_trained=ml_models_trained,
        model_metrics=model_metrics,
    )


@router.get("/health")
async def health_check():
    """Simple health check endpoint."""
    return {"status": "ok", "service": "Flood Risk Assessment API"}
