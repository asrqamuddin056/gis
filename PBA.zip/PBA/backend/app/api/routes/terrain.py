"""Terrain (DEM) analysis API."""

import os
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.models.study_area import StudyArea
from app.services.dem_service import process_dem, get_elevation_at_point, get_slope_at_point, generate_elevation_distribution

router = APIRouter()


@router.post("/{dataset_id}/analyze")
async def analyze_dem(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """Analyze a DEM dataset — generates slope and elevation thematic layers."""
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    if dataset.data_type not in ("raster",):
        raise HTTPException(status_code=400, detail="Dataset must be a raster (DEM)")

    if not os.path.exists(dataset.file_path):
        raise HTTPException(status_code=404, detail="Dataset file not found on disk")

    study_area_id = dataset.study_area_id or "default"
    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "terrain")
    output_dir = os.path.abspath(output_dir)

    try:
        result = process_dem(dataset.file_path, output_dir, study_area_id)

        # Update dataset status
        dataset.processing_status = "completed"
        from datetime import datetime, timezone
        dataset.processed_at = datetime.now(timezone.utc)

        return {
            "status": "completed",
            "result": result,
        }
    except Exception as e:
        dataset.processing_status = "failed"
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{dataset_id}/elevation-distribution")
async def get_elevation_distribution_api(dataset_id: str, n_bins: int = Query(10, ge=5, le=50), db: AsyncSession = Depends(get_db)):
    """Get elevation distribution histogram data."""
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    if not os.path.exists(dataset.file_path):
        raise HTTPException(status_code=404, detail="File not found")

    from app.geospatial.raster_processing import read_raster
    raster = read_raster(dataset.file_path)
    distribution = generate_elevation_distribution(raster["data"], raster["nodata"], n_bins)

    return {"distribution": distribution}


@router.get("/point-query")
async def query_point(
    lon: float = Query(...),
    lat: float = Query(...),
    dem_path: Optional[str] = Query(None),
    slope_path: Optional[str] = Query(None),
):
    """Query elevation and slope at a specific point."""
    elevation = None
    slope = None

    if dem_path:
        elevation = get_elevation_at_point(dem_path, lon, lat)
    if slope_path:
        slope = get_slope_at_point(slope_path, lon, lat)

    return {
        "lon": lon,
        "lat": lat,
        "elevation": elevation,
        "slope": slope,
        "note": "Values are sampled from raster data at the nearest pixel.",
    }
