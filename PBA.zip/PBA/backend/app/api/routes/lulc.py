"""Land Use / Land Cover analysis API."""

import os
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.connection import get_db
from app.models.dataset import Dataset
from app.services.lulc_service import (
    process_lulc_raster, calculate_ndvi, calculate_ndwi, train_lulc_classifier,
)
from app.utils.sample_data import get_lulc_class_info

router = APIRouter()


@router.post("/{dataset_id}/analyze")
async def analyze_lulc(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """Analyze a LULC raster — generate class statistics and area calculations."""
    dataset = await db.get(Dataset, dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    if not os.path.exists(dataset.file_path):
        raise HTTPException(status_code=404, detail="File not found")

    study_area_id = dataset.study_area_id or "default"
    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "lulc")
    output_dir = os.path.abspath(output_dir)

    try:
        result = process_lulc_raster(dataset.file_path, output_dir, study_area_id)
        dataset.processing_status = "completed"
        from datetime import datetime, timezone
        dataset.processed_at = datetime.now(timezone.utc)
        return {"status": "completed", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/calculate-ndvi")
async def calculate_ndvi_api(
    nir_file: UploadFile = File(...),
    red_file: UploadFile = File(...),
):
    """Calculate NDVI from uploaded NIR and Red band images.

    NDVI = (NIR - Red) / (NIR + Red)
    """
    from app.services.dataset_service import save_uploaded_file

    nir_path = save_uploaded_file(await nir_file.read(), nir_file.filename, "satellite")
    red_path = save_uploaded_file(await red_file.read(), red_file.filename, "satellite")

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "indices")
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    ndvi_path = os.path.join(output_dir, "ndvi_result.tif")

    try:
        result = calculate_ndvi(nir_path, red_path, ndvi_path)
        return {"status": "completed", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/calculate-ndwi")
async def calculate_ndwi_api(
    green_file: UploadFile = File(...),
    nir_file: UploadFile = File(...),
):
    """Calculate NDWI from uploaded Green and NIR band images.

    NDWI = (Green - NIR) / (Green + NIR)
    """
    from app.services.dataset_service import save_uploaded_file

    green_path = save_uploaded_file(await green_file.read(), green_file.filename, "satellite")
    nir_path = save_uploaded_file(await nir_file.read(), nir_file.filename, "satellite")

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "indices")
    output_dir = os.path.abspath(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    ndwi_path = os.path.join(output_dir, "ndwi_result.tif")

    try:
        result = calculate_ndwi(green_path, nir_path, ndwi_path)
        return {"status": "completed", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/classes")
async def get_lulc_classes():
    """Return LULC class definitions."""
    return {"classes": get_lulc_class_info()}


@router.post("/train-classifier")
async def train_lulc_classifier_api(
    training_file: UploadFile = File(...),
    band_files: list[UploadFile] = File(...),
):
    """Train a Random Forest LULC classifier from labelled samples and satellite bands.

    Requires training samples (CSV with lat, lon, class columns) and
    satellite imagery band files (GeoTIFF).
    """
    from app.services.dataset_service import save_uploaded_file

    training_path = save_uploaded_file(await training_file.read(), training_file.filename, "csv")
    band_paths = []
    for bf in band_files:
        path = save_uploaded_file(await bf.read(), bf.filename, "satellite")
        band_paths.append(path)

    output_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "output", "lulc")
    output_dir = os.path.abspath(output_dir)

    try:
        result = train_lulc_classifier(training_path, band_paths, output_dir)
        return {"status": result["status"], "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
