"""Machine learning and scenario schemas."""

from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, Field


class MLTrainingRequest(BaseModel):
    """Request to train an ML model."""
    study_area_id: str
    dataset_id: str
    algorithm: str = "random_forest"  # random_forest, xgboost, logistic_regression
    test_size: float = Field(0.3, ge=0.1, le=0.5)
    random_state: int = 42
    hyperparameters: dict = {}


class MLModelResponse(BaseModel):
    id: str
    study_area_id: Optional[str] = None
    name: str
    algorithm: str
    hyperparameters: dict = {}
    features: dict = {}
    model_path: str = ""
    n_samples: int = 0
    n_features: int = 0
    feature_importance: dict = {}
    status: str = "pending"
    created_at: datetime
    trained_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ModelEvaluationResponse(BaseModel):
    id: str
    model_id: str
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    roc_auc: float
    confusion_matrix: dict = {}
    classification_report: dict = {}
    validation_strategy: str = ""
    created_at: datetime

    class Config:
        from_attributes = True


class ScenarioRequest(BaseModel):
    """Request for hypothetical rainfall scenario analysis."""
    study_area_id: str
    name: str = "Rainfall Scenario"
    description: str = ""
    scenario_rainfall_mm: float = Field(..., gt=0, description="Hypothetical rainfall in mm")
    baseline_assessment_id: Optional[str] = None


class ScenarioResponse(BaseModel):
    id: str
    study_area_id: str
    name: str
    description: str = ""
    scenario_rainfall_mm: float
    baseline_assessment_id: Optional[str] = None
    scenario_raster_path: str = ""
    difference_raster_path: str = ""
    statistics: dict = {}
    changed_areas: dict = {}
    status: str = "pending"
    created_at: datetime
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True
