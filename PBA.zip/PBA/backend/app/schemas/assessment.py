"""Risk assessment, weights, and layer schemas."""

from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, Field


class RiskWeightCreate(BaseModel):
    factor: str
    weight: float = Field(..., ge=0.0, le=1.0)
    label: str = ""
    description: str = ""
    is_enabled: bool = True


class RiskWeightResponse(RiskWeightCreate):
    id: str
    study_area_id: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class WeightedOverlayRequest(BaseModel):
    """Request to run weighted overlay analysis."""
    study_area_id: str
    name: str = "Flood Risk Assessment"
    description: str = ""
    weights: dict[str, float] = Field(
        default_factory=lambda: {
            "rainfall": 0.25,
            "elevation": 0.20,
            "drainage_proximity": 0.20,
            "slope": 0.15,
            "lulc": 0.15,
            "built_up": 0.05,
        }
    )
    thresholds: dict[str, float] = Field(
        default_factory=lambda: {
            "low": 1.0,
            "medium": 2.0,
            "high": 3.0,
            "very_high": 4.0,
        }
    )


class RiskAssessmentResponse(BaseModel):
    id: str
    study_area_id: str
    name: str
    description: str = ""
    method: str = "weighted_overlay"
    weights: dict = {}
    thresholds: dict = {}
    risk_raster_path: str = ""
    risk_vector_path: str = ""
    statistics: dict = {}
    area_by_category: dict = {}
    status: str = "pending"
    created_at: datetime
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class RiskLayerResponse(BaseModel):
    id: str
    layer_type: str
    name: str
    file_path: str = ""
    statistics: dict = {}
    crs: str = ""
    spatial_resolution: float = 0.0
    is_enabled: bool = True
    created_at: datetime

    class Config:
        from_attributes = True


class DashboardStatsResponse(BaseModel):
    """Dashboard statistics computed from real data."""
    total_study_areas: int = 0
    total_datasets: int = 0
    total_assessments: int = 0
    high_risk_zones: int = 0
    very_high_risk_zones: int = 0
    high_risk_percentage: float = 0.0
    latest_assessment_date: Optional[str] = None
    datasets_processed: int = 0
    risk_distribution: dict[str, int] = {}
    area_analysed_km2: float = 0.0
    ml_models_trained: int = 0
    model_metrics: dict = {}
