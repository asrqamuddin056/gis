"""Study area schemas."""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class StudyAreaBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str = ""
    location_label: str = ""
    analysis_crs: str = "32644"


class StudyAreaCreate(StudyAreaBase):
    boundary_geojson: str = ""
    bbox_min_lon: float = 0.0
    bbox_min_lat: float = 0.0
    bbox_max_lon: float = 0.0
    bbox_max_lat: float = 0.0


class StudyAreaUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    boundary_geojson: Optional[str] = None
    bbox_min_lon: Optional[float] = None
    bbox_min_lat: Optional[float] = None
    bbox_max_lon: Optional[float] = None
    bbox_max_lat: Optional[float] = None
    analysis_crs: Optional[str] = None
    location_label: Optional[str] = None


class StudyAreaResponse(StudyAreaBase):
    id: str
    boundary_geojson: str = ""
    bbox_min_lon: float = 0.0
    bbox_min_lat: float = 0.0
    bbox_max_lon: float = 0.0
    bbox_max_lat: float = 0.0
    area_km2: float = 0.0
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class CitySearchResult(BaseModel):
    """Result from geocoding a city name."""
    name: str
    country: str = ""
    lat: float
    lon: float
    bbox: Optional[list[float]] = None
