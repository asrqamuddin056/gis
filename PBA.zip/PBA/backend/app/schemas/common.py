"""Shared schema types."""

from typing import Any, Optional
from pydantic import BaseModel


class PaginatedResponse(BaseModel):
    """Generic paginated response wrapper."""
    items: list[Any]
    total: int
    page: int = 1
    page_size: int = 50


class MessageResponse(BaseModel):
    """Simple message response."""
    message: str
    detail: Optional[str] = None


class ErrorResponse(BaseModel):
    """Error response."""
    error: str
    detail: Optional[str] = None
