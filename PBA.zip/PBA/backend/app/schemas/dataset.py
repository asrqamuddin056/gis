"""Dataset schemas."""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class DatasetBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str = ""
    data_type: str = Field(..., description="raster, vector, csv, rainfall, flood_record, satellite")
    source: str = ""


class DatasetCreate(DatasetBase):
    study_area_id: Optional[str] = None
    is_sample_data: bool = False


class DatasetResponse(DatasetBase):
    id: str
    file_path: str = ""
    original_filename: str = ""
    file_size_bytes: int = 0
    crs: str = ""
    spatial_resolution: float = 0.0
    coverage_area: str = ""
    processing_status: str = "pending"
    validation_status: str = "pending"
    validation_errors: str = ""
    study_area_id: Optional[str] = None
    is_sample_data: bool = False
    uploaded_at: datetime
    processed_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class DatasetValidationResult(BaseModel):
    valid: bool
    errors: list[str] = []
    warnings: list[str] = []
    metadata: dict = {}


class DatasetStatsResponse(BaseModel):
    total_datasets: int
    by_type: dict[str, int]
    by_status: dict[str, int]
    valid_datasets: int
    invalid_datasets: int
