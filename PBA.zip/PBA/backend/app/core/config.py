"""Application configuration using environment variables."""

import os
from pathlib import Path
from typing import List, Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central configuration loaded from environment / .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Application ---
    APP_NAME: str = "Urban Flood Risk Assessment System"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    # --- Database ---
    DATABASE_URL: str = "sqlite+aiosqlite:///./data/flood_risk.db"

    # --- File storage ---
    UPLOAD_DIR: str = "./uploads"
    OUTPUT_DIR: str = "./output"
    MAX_FILE_SIZE_MB: int = 500

    # --- CORS ---
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000"

    # --- Optional: Google Earth Engine ---
    GEE_PROJECT_ID: str = ""
    GEE_SERVICE_ACCOUNT: str = ""
    GEE_PRIVATE_KEY: str = ""

    # --- Optional: PostgreSQL/PostGIS ---
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "flood_risk"
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = ""

    @property
    def cors_origin_list(self) -> List[str]:
        """Parse comma-separated CORS origins into a list."""
        return [
            origin.strip()
            for origin in self.CORS_ORIGINS.split(",")
            if origin.strip()
        ]

    @property
    def upload_path(self) -> Path:
        """Resolved upload directory path."""
        p = Path(self.UPLOAD_DIR)
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def output_path(self) -> Path:
        """Resolved output directory path."""
        p = Path(self.OUTPUT_DIR)
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def max_file_size_bytes(self) -> int:
        """Max upload size in bytes."""
        return self.MAX_FILE_SIZE_MB * 1024 * 1024


settings = Settings()

# Ensure data directory exists for SQLite
Path("./data").mkdir(parents=True, exist_ok=True)
