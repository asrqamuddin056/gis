"""Test API endpoints with httpx."""
import httpx
import json
import asyncio
import sys

BASE = "http://localhost:8000"
results = []

async def test():
    async with httpx.AsyncClient(base_url=BASE, timeout=30) as c:
        # Health
        r = await c.get("/api/v1/health")
        results.append(f"GET /api/v1/health -> {r.status_code}: {r.json()}")

        # Root
        r = await c.get("/")
        results.append(f"GET / -> {r.status_code}")

        # Dashboard stats
        r = await c.get("/api/v1/stats")
        results.append(f"GET /api/v1/stats -> {r.status_code}: {json.dumps(r.json(), indent=2)}")

        # List study areas
        r = await c.get("/api/v1/study-areas/")
        results.append(f"GET /api/v1/study-areas/ -> {r.status_code}: {len(r.json())} areas")

        # Create Hyderabad sample
        r = await c.post("/api/v1/study-areas/create-hyderabad-sample")
        results.append(f"POST create-hyderabad-sample -> {r.status_code}: {r.json()}")

        # List study areas again
        r = await c.get("/api/v1/study-areas/")
        areas = r.json()
        results.append(f"GET study-areas/ -> {r.status_code}: {len(areas)} areas")
        if areas:
            area_id = areas[0]["id"]
            results.append(f"  First area: {areas[0]['name']} (id={area_id})")

            # Generate sample data
            r = await c.post("/api/v1/datasets/generate-sample-data", data={"study_area_id": area_id})
            results.append(f"POST generate-sample-data -> {r.status_code}: {r.json()}")

            # List datasets
            r = await c.get(f"/api/v1/datasets/?study_area_id={area_id}")
            datasets = r.json()
            results.append(f"GET datasets/?study_area_id={area_id} -> {r.status_code}: {len(datasets)} datasets")
            for ds in datasets[:5]:
                results.append(f"  {ds['name']} ({ds['data_type']}) - {ds['validation_status']}")

            # Dataset stats
            r = await c.get("/api/v1/datasets/stats")
            results.append(f"GET datasets/stats -> {r.status_code}: {r.json()}")

            # Default weights
            r = await c.get("/api/v1/overlay/default-weights")
            results.append(f"GET overlay/default-weights -> {r.status_code}: {r.json()}")

            # Run overlay
            overlay_req = {
                "study_area_id": area_id,
                "name": "Test Assessment",
                "weights": {
                    "rainfall": 0.25,
                    "elevation": 0.20,
                    "drainage_proximity": 0.20,
                    "slope": 0.15,
                    "lulc": 0.15,
                    "built_up": 0.05,
                },
                "thresholds": {"low": 2.0, "medium": 3.0, "high": 4.0, "very_high": 5.0},
            }
            r = await c.post("/api/v1/overlay/run", json=overlay_req, timeout=120)
            results.append(f"POST overlay/run -> {r.status_code}")
            if r.status_code == 200:
                result = r.json()
                results.append(f"  status: {result.get('status')}")
                results.append(f"  risk_distribution: {result['result']['risk_distribution']}")
                results.append(f"  high_risk_pct: {result['result']['high_risk_percentage']}%")
                results.append(f"  area_by_category: {result['result']['area_by_category']}")
                assessment_id = result.get("assessment_id", "")

                # List assessments
                r2 = await c.get("/api/v1/overlay/assessments")
                results.append(f"GET overlay/assessments -> {r2.status_code}: {len(r2.json())} assessments")

                # Generate PDF report
                if assessment_id:
                    r3 = await c.post(f"/api/v1/reports/{assessment_id}/pdf", params={"include_ml": False}, timeout=60)
                    results.append(f"POST reports/{assessment_id}/pdf -> {r3.status_code}")
            else:
                results.append(f"  error: {r.text[:200]}")

            # LULC classes
            r = await c.get("/api/v1/lulc/classes")
            results.append(f"GET lulc/classes -> {r.status_code}: {r.json()}")

            # Satellite info
            r = await c.get("/api/v1/satellite/info")
            results.append(f"GET satellite/info -> {r.status_code}: {r.json()}")

            # Search city
            r = await c.post("/api/v1/study-areas/search-city?query=Hyderabad")
            results.append(f"POST search-city?query=Hyderabad -> {r.status_code}: {r.json()}")

            # ML train
            flood_ds = [d for d in datasets if d["data_type"] == "flood_record"]
            if flood_ds:
                ml_req = {
                    "study_area_id": area_id,
                    "dataset_id": flood_ds[0]["id"],
                    "algorithm": "random_forest",
                    "test_size": 0.3,
                    "random_state": 42,
                    "hyperparameters": {},
                }
                r = await c.post("/api/v1/ml/train", json=ml_req, timeout=120)
                results.append(f"POST ml/train -> {r.status_code}")
                if r.status_code == 200:
                    ml_result = r.json()
                    results.append(f"  status: {ml_result.get('status')}")
                    if ml_result.get("result"):
                        res = ml_result["result"]
                        results.append(f"  accuracy: {res.get('accuracy')}")
                        results.append(f"  f1_score: {res.get('f1_score')}")
                        results.append(f"  roc_auc: {res.get('roc_auc')}")
                        results.append(f"  validation: {res.get('validation_strategy')}")
                        results.append(f"  feature_importance: {res.get('feature_importance')}")
                else:
                    results.append(f"  error: {r.text[:200]}")

    # Write results
    with open("api_test_results.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(results))
    print("DONE")

asyncio.run(test())
