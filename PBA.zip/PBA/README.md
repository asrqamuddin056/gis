# Intelligent Urban Flood Risk Assessment and Prediction System

An end-to-end geospatial application for identifying, analysing, and visualising urban areas susceptible to flooding using GIS, remote sensing, machine learning, and geospatial analytics.

## Overview

This system processes multiple environmental and geographical factors — elevation, slope, rainfall, land use/land cover, drainage proximity, and built-up density — to generate a Flood Risk Index (FRI) using GIS-based Weighted Overlay Analysis. It classifies locations into Low, Medium, High, and Very High risk categories and provides an optional machine learning module for data-driven susceptibility modelling.

## Technology Stack

### Backend
- **Python 3.12** with **FastAPI** — REST API server
- **SQLAlchemy + SQLite** — database (PostgreSQL/PostGIS for production)
- **GeoPandas, Rasterio, Shapely, PyProj** — geospatial processing
- **NumPy, SciPy, Pandas** — numerical computation
- **Scikit-learn, XGBoost** — machine learning
- **ReportLab, Matplotlib** — report generation

### Frontend
- **React 18 + TypeScript** — UI framework
- **Vite** — build tool
- **Tailwind CSS** — styling
- **Recharts** — analytical charts
- **React-Leaflet** — interactive maps
- **Lucide React** — icons

## Quick Start

### Prerequisites
- Python 3.11+ (installed at `C:\Users\<user>\AppData\Local\Programs\Python\Python312\`)
- Node.js 20+ (with npm)

### Backend

```bash
cd backend

# Install Python dependencies
python -m pip install -r requirements.txt

# Create .env file (optional — defaults work for local dev)
cp .env.example .env

# Start the server
python run.py
```

The backend runs on `http://localhost:8000`. API docs available at `http://localhost:8000/docs`.

### Frontend

```bash
cd frontend

# Install npm packages
npm install

# Start dev server
npm run dev
```

The frontend runs on `http://localhost:5173`.

### Using Sample Data

1. Open the frontend at `http://localhost:5173`
2. Go to **Study Areas** → click **Hyderabad Sample**
3. Go to **Datasets** → click **Generate Sample Data** (generates 8 synthetic datasets for Hyderabad)
4. Go to **Flood Risk Assessment** → select the study area → adjust weights → click **Run Analysis**
5. Go to **Reports** → select the assessment → download PDF

## Application Modules

| # | Module | Description |
|---|--------|-------------|
| 1 | Overview | Dashboard with real statistics computed from processed datasets |
| 2 | Study Areas | Define and manage geographical study areas with city search |
| 3 | Dataset Management | Upload, validate, and manage geospatial datasets |
| 4 | Satellite Analysis | Upload satellite imagery bands, calculate NDVI/NDWI |
| 5 | Terrain Analysis | DEM processing — elevation and slope calculation |
| 6 | Rainfall Analysis | Rainfall distribution, intensity classification, temporal analysis |
| 7 | LULC Classification | Land use/land cover statistics and area calculations |
| 8 | Drainage Analysis | Drainage networks, distance buffers, proximity analysis |
| 9 | Flood Risk Assessment | Weighted Overlay Analysis — FRI = Σ(Wi × Ri) |
| 10 | Machine Learning | Random Forest / XGBoost / Logistic Regression with spatial validation |
| 11 | Scenario Analysis | Hypothetical rainfall scenario assessment |
| 12 | GIS Map Explorer | Interactive map with layer controls and point queries |
| 13 | Reports | PDF/CSV/JSON export of assessment results |
| 14 | Settings | System configuration and status |

## Weighted Overlay Analysis

The core analytical engine computes a Flood Risk Index:

```
FRI = Σ (Wi × Ri)
```

Where:
- **Wi** = Weight assigned to the i-th factor
- **Ri** = Normalised risk score (1–5) for the i-th factor

### Default Weights (Illustrative)
| Factor | Weight |
|--------|--------|
| Rainfall | 25% |
| Elevation | 20% |
| Drainage Proximity | 20% |
| Slope | 15% |
| LULC | 15% |
| Built-up Density | 5% |

**Note:** These weights are illustrative initial values, not scientifically established universal constants. Users should adjust them based on local conditions and domain expertise.

### Risk Classification
| Category | FRI Range (1–5 scale) |
|----------|----------------------|
| Low | < 2.0 |
| Medium | 2.0 – 3.0 |
| High | 3.0 – 4.0 |
| Very High | ≥ 4.0 |

## Machine Learning Module

The ML module trains models on historical flood occurrence data:

- **Algorithms:** Random Forest, XGBoost, Logistic Regression
- **Validation:** Spatially separated (west=train, east=test) to avoid spatial data leakage
- **Metrics:** Accuracy, Precision, Recall, F1-score, ROC-AUC, Confusion Matrix
- **Class imbalance:** Handled via class weights
- **Feature importance:** Computed and displayed

**Important:** The ML module requires labelled historical flood data. If no labelled data is available, the weighted overlay system remains fully functional. Do not interpret ML results as real-world predictive accuracy unless validated with sufficient real flood occurrence records.

## Sample Data

The system includes a sample data generator that creates synthetic but realistic datasets for the Hyderabad metropolitan area:

- **DEM** (200×200 GeoTIFF) with elevation gradient (380–650m)
- **Slope** raster derived from DEM
- **Rainfall** raster (20–250mm) and CSV time-series from 5 weather stations
- **LULC** raster with 5 classes (Water, Vegetation, Built-up, Agricultural, Bare soil)
- **Built-up density** raster (0–1)
- **Drainage network** GeoJSON (rivers, lakes)
- **Flood occurrence** CSV (200 points with coordinates and labels)

All sample data is clearly labelled as `SAMPLE DATA`.

## API Documentation

Once the backend is running, interactive API docs are available at:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Important Distinctions

1. **Susceptibility Assessment, not Forecasting:** This system assesses flood susceptibility based on terrain and environmental factors. It does not predict future floods unless a properly trained, validated, time-dependent prediction model has been implemented.

2. **Sample Data Mode:** When external data sources (Google Earth Engine, real satellite imagery) are unavailable, the system uses clearly labelled sample data. This is documented in the UI and API responses.

3. **Scenario Analysis:** The scenario module performs hypothetical rainfall scenario assessment — it recalculates the rainfall component using a user-specified value. This is NOT validated future flood forecasting.

## Project Structure

```
PBA/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI application
│   │   ├── core/config.py       # Configuration
│   │   ├── api/routes/          # 12 API route modules
│   │   ├── models/              # ORM models
│   │   ├── schemas/             # Pydantic schemas
│   │   ├── services/            # Business logic (9 services)
│   │   ├── geospatial/          # Raster/vector/spatial analysis
│   │   ├── database/            # Connection & session management
│   │   └── utils/               # Sample data generator
│   ├── tests/
│   ├── requirements.txt
│   ├── .env.example
│   └── run.py                   # Entry point
├── frontend/
│   ├── src/
│   │   ├── pages/               # 14 React pages
│   │   ├── layouts/             # Sidebar layout
│   │   ├── services/api.ts      # API client
│   │   ├── types/               # TypeScript types
│   │   ├── App.tsx              # Router
│   │   └── main.tsx             # Entry point
│   ├── package.json
│   └── vite.config.ts
├── data/sample/                 # Generated sample datasets
└── README.md
```

## Limitations

- Sample data is synthetic and does not represent real-world flood patterns
- ML accuracy depends on the quality and quantity of labelled flood occurrence data
- Weights are illustrative and should be validated with domain expertise
- Proximity to drainage does not prove drainage capacity or failure
- The system assesses susceptibility, not real-time flood forecasting
- Google Earth Engine integration requires separate credential setup

## License

This is an academic project for educational purposes.
