$log = "d:\PBA\frontend\npm_install.log"
$npm = "C:\Program Files\nodejs\npm.cmd"
Set-Location d:\PBA\frontend
& $npm install 2>&1 | Out-File $log -Encoding UTF8
"INSTALL_DONE" | Out-File $log -Append
